package com.lightdesk.feature.stats

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Checklist
import androidx.compose.material.icons.outlined.DeleteSweep
import androidx.compose.material.icons.outlined.EditNote
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.TouchApp
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.lightdesk.core.designsystem.component.ConfirmDialog
import com.lightdesk.core.designsystem.component.EmptyState
import com.lightdesk.core.designsystem.component.ErrorBanner
import com.lightdesk.core.designsystem.component.InfoBanner
import com.lightdesk.core.designsystem.component.LoadingView
import com.lightdesk.core.designsystem.component.PageHorizontalPadding
import com.lightdesk.core.designsystem.component.ScreenHeader
import com.lightdesk.core.designsystem.component.SecondaryButton
import com.lightdesk.core.designsystem.component.SectionCard
import com.lightdesk.core.model.FeatureKey
import kotlinx.coroutines.delay

/** 一次性提示自动消失时间。 */
private const val MESSAGE_AUTO_DISMISS_MS = 4_000L

/**
 * 使用统计页纯 UI：只负责渲染 [StatsUiState]，不直接访问仓储。
 * 所有异常都已由 ViewModel 转为提示文案，页面不会因异常崩溃。
 */
@Composable
internal fun StatsScreen(
    uiState: StatsUiState,
    onOpenSettings: () -> Unit,
    onReset: () -> Unit,
    onDismissMessage: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var showResetConfirm by remember { mutableStateOf(false) }

    // 成功/失败提示展示一段时间后自动消失，避免长期占用版面
    LaunchedEffect(uiState.message) {
        if (uiState.message != null) {
            delay(MESSAGE_AUTO_DISMISS_MS)
            onDismissMessage()
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        ScreenHeader(
            title = "使用统计",
            subtitle = "了解自己最常用的功能",
            actions = {
                IconButton(onClick = onOpenSettings) {
                    Icon(
                        imageVector = Icons.Outlined.Settings,
                        contentDescription = "打开设置",
                        tint = MaterialTheme.colorScheme.onBackground,
                    )
                }
            },
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = PageHorizontalPadding)
                .padding(bottom = 28.dp),
        ) {
            if (uiState.loading) {
                LoadingView(text = "正在读取使用统计…")
                return@Column
            }

            OverviewCard(totalCount = StatsPresentation.totalCount(uiState.stats))
            Spacer(modifier = Modifier.height(16.dp))

            uiState.message?.let { message ->
                if (message.isError) {
                    ErrorBanner(
                        message = message.text,
                        actionLabel = "知道了",
                        onAction = onDismissMessage,
                    )
                } else {
                    InfoBanner(
                        message = message.text,
                        actionLabel = "知道了",
                        onAction = onDismissMessage,
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            if (!StatsPresentation.hasAnyUsage(uiState.stats)) {
                EmptyState(
                    title = "还没有使用记录",
                    description = "使用备忘录、课表、天气、待办或桌面悬浮球后，" +
                        "这里会自动统计次数与最近使用时间。",
                    icon = Icons.Outlined.BarChart,
                )
            } else {
                StatsPresentation.buildRows(uiState.stats).forEach { row ->
                    FeatureUsageCard(row = row)
                    Spacer(modifier = Modifier.height(12.dp))
                }

                Spacer(modifier = Modifier.height(4.dp))
                SecondaryButton(
                    text = if (uiState.resetting) "重置中…" else "重置统计",
                    onClick = { showResetConfirm = true },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !uiState.resetting,
                    icon = Icons.Outlined.DeleteSweep,
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "重置会清空所有功能的使用次数与最近使用时间，操作不可恢复。",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }

    if (showResetConfirm) {
        ConfirmDialog(
            title = "重置使用统计？",
            message = "将清空备忘录、课表、天气、待办、悬浮球的全部使用次数与最近使用时间，且无法恢复。",
            confirmText = "重置",
            dismissText = "取消",
            destructive = true,
            onConfirm = {
                showResetConfirm = false
                onReset()
            },
            onDismiss = { showResetConfirm = false },
        )
    }
}

/** 总览卡片：所有功能累计使用次数。 */
@Composable
private fun OverviewCard(totalCount: Long) {
    val primary = MaterialTheme.colorScheme.primary
    SectionCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "总使用次数",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "$totalCount",
                    style = MaterialTheme.typography.displaySmall,
                    color = primary,
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "次功能页面打开记录",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .background(color = primary.copy(alpha = 0.12f), shape = CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = Icons.Outlined.BarChart,
                    contentDescription = null,
                    tint = primary,
                    modifier = Modifier.size(26.dp),
                )
            }
        }
    }
}

/** 单个功能的使用统计卡片。 */
@Composable
private fun FeatureUsageCard(row: FeatureUsageRow) {
    val primary = MaterialTheme.colorScheme.primary
    SectionCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(color = primary.copy(alpha = 0.12f), shape = CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = featureIcon(row.feature),
                    contentDescription = null,
                    tint = primary,
                    modifier = Modifier.size(20.dp),
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = StatsPresentation.featureName(row.feature),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    Text(
                        text = "${row.count} 次",
                        style = MaterialTheme.typography.titleMedium,
                        color = primary,
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "最近使用：${row.lastUsedText}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(modifier = Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { row.relativeProgress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(CircleShape),
                    color = primary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                    strokeCap = StrokeCap.Round,
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "占总使用 ${row.percentOfTotal}%",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

/** 功能图标；图标统一来自 Material Icons，保证与底部导航一致。 */
private fun featureIcon(feature: FeatureKey): ImageVector = when (feature) {
    FeatureKey.MEMO -> Icons.Outlined.EditNote
    FeatureKey.TIMETABLE -> Icons.Outlined.CalendarMonth
    FeatureKey.WEATHER -> Icons.Outlined.WbSunny
    FeatureKey.TODO -> Icons.Outlined.Checklist
    FeatureKey.FLOATING_BALL -> Icons.Outlined.TouchApp
}
