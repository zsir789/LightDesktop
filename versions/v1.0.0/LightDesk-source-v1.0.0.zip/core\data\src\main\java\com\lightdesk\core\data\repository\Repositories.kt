package com.lightdesk.core.data.repository

import com.lightdesk.core.common.AppResult
import com.lightdesk.core.model.AppSettings
import com.lightdesk.core.model.CourseTable
import com.lightdesk.core.model.FeatureKey
import com.lightdesk.core.model.Memo
import com.lightdesk.core.model.Todo
import com.lightdesk.core.model.UsageStats
import com.lightdesk.core.model.WeatherSnapshot
import kotlinx.coroutines.flow.Flow

/**
 * 仓储接口层：功能模块只依赖这些接口，不感知具体存储实现（当前为 JSON 文件）。
 *
 * 扩展方式：新增一种存储（Room / 服务端同步）时，实现同样的接口并在组装层替换即可，
 * 功能模块代码无需改动。
 */

interface MemoRepository {
    fun observeMemos(): Flow<List<Memo>>
    suspend fun upsert(memo: Memo): AppResult<Unit>
    suspend fun delete(id: String): AppResult<Unit>
    suspend fun get(id: String): Memo?
}

interface TodoRepository {
    fun observeTodos(): Flow<List<Todo>>
    suspend fun upsert(todo: Todo): AppResult<Unit>
    suspend fun delete(id: String): AppResult<Unit>
    suspend fun get(id: String): Todo?
}

interface CourseRepository {
    fun observeTable(): Flow<CourseTable?>
    suspend fun replace(table: CourseTable): AppResult<Unit>
    suspend fun clear(): AppResult<Unit>
}

interface UsageRepository {
    fun observeStats(): Flow<UsageStats>
    suspend fun record(feature: FeatureKey, at: Long): AppResult<Unit>
    suspend fun reset(): AppResult<Unit>
}

interface SettingsRepository {
    fun observeSettings(): Flow<AppSettings>
    suspend fun current(): AppSettings
    suspend fun update(transform: (AppSettings) -> AppSettings): AppResult<Unit>
}

interface WeatherRepository {
    fun observeCache(): Flow<WeatherSnapshot?>
    suspend fun cached(): WeatherSnapshot?
    suspend fun save(snapshot: WeatherSnapshot): AppResult<Unit>
    suspend fun clear(): AppResult<Unit>
}
