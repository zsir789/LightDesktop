package com.lightdesk.feature.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Checklist
import androidx.compose.material.icons.outlined.EditNote
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.lightdesk.core.common.TimeFormat
import com.lightdesk.core.designsystem.component.CenteredHint
import com.lightdesk.core.designsystem.component.EmptyState
import com.lightdesk.core.designsystem.component.ErrorBanner
import com.lightdesk.core.designsystem.component.LoadingView
import com.lightdesk.core.designsystem.component.PageHorizontalPadding
import com.lightdesk.core.designsystem.component.SecondaryButton
import com.lightdesk.core.designsystem.component.SectionCard
import com.lightdesk.core.designsystem.component.SectionTitle
import com.lightdesk.core.designsystem.component.TagPill
import com.lightdesk.core.designsystem.component.TextAction
import com.lightdesk.core.designsystem.theme.LocalStatusColors

/**
 * 首页内容区：问候头部 + 今日课程 + 今日待办 + 快捷入口。
 *
 * 页面本身不处理导航，全部通过回调交给 [HomeRoute]。
 */
@Composable
internal fun HomeScreen(
    state: HomeUiState,
    onRefresh: () -> Unit,
    onOpenNotes: () -> Unit,
    onOpenTimetable: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = PageHorizontalPadding),
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        Spacer(modifier = Modifier.height(8.dp))
        GreetingHeader(state = state, onRefresh = onRefresh)

        state.error?.let { message ->
            ErrorBanner(message = message, onAction = onRefresh)
        }

        if (state.loading) {
            LoadingView()
        } else {
            TodayCoursesSection(state = state, onOpenTimetable = onOpenTimetable)
            TodayTodosSection(state = state, onOpenNotes = onOpenNotes)
            QuickActionsSection(onOpenNotes = onOpenNotes, onOpenTimetable = onOpenTimetable)
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun GreetingHeader(state: HomeUiState, onRefresh: () -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = state.greeting,
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground,
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = state.dateLabel,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                state.weekNumber?.let { week ->
                    Spacer(modifier = Modifier.width(8.dp))
                    TagPill(text = "第 $week 周")
                }
            }
        }
        TextAction(text = "刷新", onClick = onRefresh)
    }
}

@Composable
private fun TodayCoursesSection(state: HomeUiState, onOpenTimetable: () -> Unit) {
    val highlightedId = state.highlightedCourseId
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SectionTitle(
            text = "今日课程",
            trailing = {
                if (state.hasTimetable) {
                    TextAction(text = "查看课表", onClick = onOpenTimetable)
                }
            },
        )
        SectionCard {
            when {
                !state.hasTimetable -> EmptyState(
                    title = "还没有导入课表",
                    description = "导入课表后，这里会显示今天的课程安排",
                    icon = Icons.Outlined.CalendarMonth,
                    actionLabel = "去导入课表",
                    onAction = onOpenTimetable,
                )

                state.courses.isEmpty() -> CenteredHint(text = "今天没有课")

                else -> state.courses.forEachIndexed { index, course ->
                    if (index > 0) {
                        HorizontalDivider(
                            modifier = Modifier.padding(vertical = 8.dp),
                            color = MaterialTheme.colorScheme.outlineVariant,
                        )
                    }
                    CourseRow(course = course, highlighted = course.course.id == highlightedId)
                }
            }
        }
    }
}

@Composable
private fun CourseRow(course: TodayCourse, highlighted: Boolean) {
    val item = course.course
    val accent = MaterialTheme.colorScheme.primary
    val meta = listOfNotNull(
        item.location.takeIf { it.isNotBlank() },
        item.teacher.takeIf { it.isNotBlank() },
    ).joinToString(" · ")

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = if (highlighted) accent.copy(alpha = 0.08f) else Color.Transparent,
        shape = MaterialTheme.shapes.medium,
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = TimeFormat.minutesToClock(item.startMinutes),
                    style = MaterialTheme.typography.labelLarge,
                    color = if (highlighted) accent else MaterialTheme.colorScheme.onSurface,
                )
                Text(
                    text = TimeFormat.minutesToClock(item.endMinutes),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.bodyLarge,
                    color = if (highlighted) accent else MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (meta.isNotEmpty()) {
                    Text(
                        text = meta,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            when (course.status) {
                CourseStatus.ONGOING -> {
                    Spacer(modifier = Modifier.width(8.dp))
                    TagPill(text = "进行中", color = accent)
                }

                CourseStatus.UPCOMING -> {
                    Spacer(modifier = Modifier.width(8.dp))
                    TagPill(text = "即将开始", color = LocalStatusColors.current.info)
                }

                CourseStatus.FINISHED -> Unit
            }
        }
    }
}

@Composable
private fun TodayTodosSection(state: HomeUiState, onOpenNotes: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SectionTitle(
            text = "今日待办",
            trailing = {
                if (state.todos.isNotEmpty()) {
                    TextAction(text = "查看全部", onClick = onOpenNotes)
                }
            },
        )
        SectionCard {
            if (state.todos.isEmpty()) {
                EmptyState(
                    title = "今天没有待办",
                    description = "把今天要做的事记下来，到点前不会漏",
                    icon = Icons.Outlined.Checklist,
                    actionLabel = "去添加",
                    onAction = onOpenNotes,
                )
            } else {
                state.todos.forEachIndexed { index, todo ->
                    if (index > 0) {
                        HorizontalDivider(
                            modifier = Modifier.padding(vertical = 4.dp),
                            color = MaterialTheme.colorScheme.outlineVariant,
                        )
                    }
                    TodoRow(todo = todo, now = state.now, onClick = onOpenNotes)
                }
                if (state.pendingTodoCount > 0) {
                    HorizontalDivider(
                        modifier = Modifier.padding(top = 12.dp),
                        color = MaterialTheme.colorScheme.outlineVariant,
                    )
                    PendingTodoFooter(count = state.pendingTodoCount, onClick = onOpenNotes)
                }
            }
        }
    }
}

@Composable
private fun TodoRow(todo: TodayTodo, now: Long, onClick: () -> Unit) {
    val item = todo.item
    val countdownColor = when {
        todo.overdue -> LocalStatusColors.current.danger
        todo.urgent -> LocalStatusColors.current.warning
        else -> MaterialTheme.colorScheme.primary
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Icon(
            imageVector = Icons.Outlined.Schedule,
            contentDescription = null,
            tint = countdownColor,
            modifier = Modifier
                .padding(top = 2.dp)
                .size(18.dp),
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = item.title.ifBlank { "未命名待办" },
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            item.deadline?.let { deadline ->
                Text(
                    text = "截止 ${TimeFormat.timestampToDateTimeText(deadline)} · " +
                        TimeFormat.deadlineHint(deadline, now),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = todo.countdownText,
            style = MaterialTheme.typography.labelLarge.copy(fontFamily = FontFamily.Monospace),
            color = countdownColor,
        )
    }
}

@Composable
private fun PendingTodoFooter(count: Int, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(top = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = "全部未完成待办 $count 项",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f),
        )
        Text(
            text = "去查看",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary,
        )
    }
}

@Composable
private fun QuickActionsSection(onOpenNotes: () -> Unit, onOpenTimetable: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SectionTitle(text = "快捷入口")
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            SecondaryButton(
                text = "打开备忘",
                onClick = onOpenNotes,
                modifier = Modifier.weight(1f),
                icon = Icons.Outlined.EditNote,
            )
            SecondaryButton(
                text = "查看课表",
                onClick = onOpenTimetable,
                modifier = Modifier.weight(1f),
                icon = Icons.Outlined.CalendarMonth,
            )
        }
    }
}
