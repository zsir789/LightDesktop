package com.lightdesk.feature.memo

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.lightdesk.core.common.AppError
import com.lightdesk.core.common.AppResult
import com.lightdesk.core.common.ErrorCode
import com.lightdesk.core.common.TimeProvider
import com.lightdesk.core.data.repository.MemoRepository
import com.lightdesk.core.model.Memo
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** 一次性提示消息（带自增 id，避免重复弹出同一条）。 */
data class MemoUiMessage(val id: Long, val text: String)

/** 编辑弹窗的表单状态。[editingId] 为 null 表示新增。 */
data class MemoEditorState(
    val editingId: String? = null,
    val title: String = "",
    val content: String = "",
    val pinned: Boolean = false,
    val titleError: String? = null,
) {
    val isEditing: Boolean get() = editingId != null
}

/** 备忘录页面完整 UI 状态。 */
data class MemoUiState(
    val loading: Boolean = true,
    val memos: List<Memo> = emptyList(),
    val query: String = "",
    val filter: MemoFilter = MemoFilter.ALL,
    val loadError: String? = null,
    val editor: MemoEditorState? = null,
    val saving: Boolean = false,
    val pendingDelete: Memo? = null,
    val message: MemoUiMessage? = null,
)

/**
 * 备忘录页面的状态持有者：只依赖 [MemoRepository] 与 [TimeProvider]，
 * 所有可能失败的仓储调用都在此转换为 [AppResult] 并转成 UI 提示，不会让异常穿透到 Compose。
 */
class MemoViewModel(
    private val repository: MemoRepository,
    private val timeProvider: TimeProvider,
) : ViewModel() {

    private val _uiState = MutableStateFlow(MemoUiState())
    val uiState: StateFlow<MemoUiState> = _uiState.asStateFlow()

    private var observerJob: Job? = null
    private var messageSeq = 0L

    init {
        observeMemos()
    }

    private fun observeMemos() {
        observerJob?.cancel()
        observerJob = viewModelScope.launch {
            repository.observeMemos()
                .catch { throwable ->
                    if (throwable is CancellationException) throw throwable
                    _uiState.update {
                        it.copy(
                            loading = false,
                            loadError = "备忘录加载失败：${throwable.message ?: "未知错误"}",
                        )
                    }
                }
                .collect { memos ->
                    _uiState.update { state ->
                        state.copy(memos = memos, loading = false, loadError = null)
                    }
                }
        }
    }

    /** 读取失败后的重试入口。 */
    fun retryLoad() {
        _uiState.update { it.copy(loading = true, loadError = null) }
        observeMemos()
    }

    fun onQueryChange(query: String) {
        _uiState.update { it.copy(query = query) }
    }

    fun onFilterChange(filter: MemoFilter) {
        _uiState.update { it.copy(filter = filter) }
    }

    fun clearFilters() {
        _uiState.update { it.copy(query = "", filter = MemoFilter.ALL) }
    }

    fun startCreate() {
        _uiState.update { it.copy(editor = MemoEditorState()) }
    }

    fun startEdit(memo: Memo) {
        _uiState.update {
            it.copy(
                editor = MemoEditorState(
                    editingId = memo.id,
                    title = memo.title,
                    content = memo.content,
                    pinned = memo.pinned,
                ),
            )
        }
    }

    fun dismissEditor() {
        if (_uiState.value.saving) return
        _uiState.update { it.copy(editor = null) }
    }

    fun onEditorTitleChange(title: String) {
        updateEditor { it.copy(title = title, titleError = null) }
    }

    fun onEditorContentChange(content: String) {
        updateEditor { it.copy(content = content) }
    }

    fun onEditorPinnedChange(pinned: Boolean) {
        updateEditor { it.copy(pinned = pinned) }
    }

    fun save() {
        val state = _uiState.value
        val editor = state.editor ?: return
        if (state.saving) return

        val titleError = validateMemoTitle(editor.title)
        if (titleError != null) {
            updateEditor { it.copy(titleError = titleError) }
            return
        }

        val now = timeProvider.now()
        val existing = editor.editingId?.let { id -> state.memos.firstOrNull { it.id == id } }
        val memo = buildMemo(
            existing = existing,
            editingId = editor.editingId,
            title = editor.title,
            content = editor.content,
            pinned = editor.pinned,
            now = now,
        )
        _uiState.update { it.copy(saving = true) }
        viewModelScope.launch {
            when (val result = upsert(memo)) {
                is AppResult.Success -> {
                    val message = pushMessage(if (editor.isEditing) "备忘已更新" else "备忘已保存")
                    _uiState.update {
                        it.copy(saving = false, editor = null, message = message)
                    }
                }

                is AppResult.Failure -> {
                    val message = pushMessage("保存失败：${result.error.message}")
                    _uiState.update { it.copy(saving = false, message = message) }
                }
            }
        }
    }

    fun toggleDone(memo: Memo) {
        val now = timeProvider.now()
        viewModelScope.launch {
            when (val result = upsert(memo.copy(done = !memo.done, updatedAt = now))) {
                is AppResult.Success -> Unit
                is AppResult.Failure -> publishMessage("更新失败：${result.error.message}")
            }
        }
    }

    fun togglePinned(memo: Memo) {
        val now = timeProvider.now()
        viewModelScope.launch {
            when (val result = upsert(memo.copy(pinned = !memo.pinned, updatedAt = now))) {
                is AppResult.Success -> Unit
                is AppResult.Failure -> publishMessage("更新失败：${result.error.message}")
            }
        }
    }

    fun requestDelete(memo: Memo) {
        _uiState.update { it.copy(pendingDelete = memo) }
    }

    fun dismissDelete() {
        _uiState.update { it.copy(pendingDelete = null) }
    }

    fun confirmDelete() {
        val target = _uiState.value.pendingDelete ?: return
        _uiState.update { it.copy(pendingDelete = null) }
        viewModelScope.launch {
            when (val result = delete(target.id)) {
                is AppResult.Success -> publishMessage("已删除「${target.title}」")
                is AppResult.Failure -> publishMessage("删除失败：${result.error.message}")
            }
        }
    }

    /** 消费提示消息，避免配置变化后重复弹出。 */
    fun consumeMessage(id: Long) {
        _uiState.update { state ->
            if (state.message?.id == id) state.copy(message = null) else state
        }
    }

    private fun updateEditor(transform: (MemoEditorState) -> MemoEditorState) {
        _uiState.update { state ->
            val editor = state.editor ?: return@update state
            state.copy(editor = transform(editor))
        }
    }

    private fun pushMessage(text: String): MemoUiMessage {
        messageSeq += 1
        return MemoUiMessage(id = messageSeq, text = text)
    }

    private fun publishMessage(text: String) {
        val message = pushMessage(text)
        _uiState.update { it.copy(message = message) }
    }

    private suspend fun upsert(memo: Memo): AppResult<Unit> = try {
        repository.upsert(memo)
    } catch (cancellation: CancellationException) {
        throw cancellation
    } catch (throwable: Throwable) {
        AppResult.Failure(AppError.fromThrowable(throwable, ErrorCode.STORAGE))
    }

    private suspend fun delete(id: String): AppResult<Unit> = try {
        repository.delete(id)
    } catch (cancellation: CancellationException) {
        throw cancellation
    } catch (throwable: Throwable) {
        AppResult.Failure(AppError.fromThrowable(throwable, ErrorCode.STORAGE))
    }
}
