package com.lightdesk.feature.timetable

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.lightdesk.core.common.AppResult
import com.lightdesk.core.common.TimeProvider
import com.lightdesk.core.data.repository.CourseRepository
import com.lightdesk.core.model.Course
import com.lightdesk.core.model.CourseTable
import com.lightdesk.feature.timetable.data.IcsParseResult
import com.lightdesk.feature.timetable.data.IcsParser
import java.time.Instant
import java.time.ZoneId
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** 课表页面状态。 */
data class TimetableUiState(
    val isLoading: Boolean = true,
    val importing: Boolean = false,
    val table: CourseTable? = null,
    val errorMessage: String? = null,
    val infoMessage: String? = null,
    val clearConfirmVisible: Boolean = false,
    val selectedCourse: Course? = null,
    val todayWeekday: Int = 1,
)

/**
 * 课表 ViewModel：负责读取/保存课表、导入 .ics、清空与弹窗状态管理。
 * 只依赖 core 中的接口与工具，不感知具体页面。
 */
class TimetableViewModel(
    private val repository: CourseRepository,
    private val timeProvider: TimeProvider,
    private val parser: IcsParser = IcsParser(),
) : ViewModel() {

    private val _uiState = MutableStateFlow(TimetableUiState())
    val uiState: StateFlow<TimetableUiState> = _uiState.asStateFlow()

    init {
        refreshToday()
        viewModelScope.launch {
            repository.observeTable()
                .catch { throwable ->
                    _uiState.update { state ->
                        state.copy(
                            isLoading = false,
                            errorMessage = "读取本地课表失败：${throwable.message ?: "未知错误"}",
                        )
                    }
                }
                .collect { table ->
                    _uiState.update { state -> state.copy(table = table, isLoading = false) }
                }
        }
    }

    /** 导入 .ics 文本：解析在后台线程完成，成功后通过仓储持久化。 */
    fun importIcs(fileName: String, content: String) {
        if (_uiState.value.importing) return
        viewModelScope.launch {
            _uiState.update {
                it.copy(importing = true, errorMessage = null, infoMessage = null)
            }

            val parseResult = withContext(Dispatchers.Default) { parser.parse(content) }
            when (parseResult) {
                is IcsParseResult.Failure -> _uiState.update {
                    it.copy(importing = false, errorMessage = parseResult.message)
                }

                is IcsParseResult.Success -> persist(fileName, parseResult)
            }
        }
    }

    /** 文件读取失败（无权限/被删除/为空等）时由页面回调。 */
    fun onFileReadError(message: String) {
        _uiState.update { it.copy(importing = false, errorMessage = message) }
    }

    private suspend fun persist(fileName: String, parseResult: IcsParseResult.Success) {
        val displayName = fileName.substringBeforeLast('.', fileName).trim()
            .ifBlank { DEFAULT_TABLE_NAME }
        val table = CourseTable(
            name = displayName,
            sourceFile = fileName,
            sourceType = "ICS",
            importedAt = timeProvider.now(),
            courses = parseResult.courses,
        )
        val saveError = (repository.replace(table) as? AppResult.Failure)?.error
        if (saveError == null) {
            val warningHint = if (parseResult.warnings.isEmpty()) {
                ""
            } else {
                "；${parseResult.warnings.size} 条提示，部分事件可能未导入"
            }
            _uiState.update {
                it.copy(
                    importing = false,
                    infoMessage = "已导入 ${parseResult.courses.size} 门课程$warningHint",
                )
            }
        } else {
            _uiState.update {
                it.copy(
                    importing = false,
                    errorMessage = "保存课表失败：${saveError.message}",
                )
            }
        }
    }

    fun requestClear() {
        if (_uiState.value.table == null) return
        _uiState.update { it.copy(clearConfirmVisible = true) }
    }

    fun dismissClear() {
        _uiState.update { it.copy(clearConfirmVisible = false) }
    }

    fun clearTable() {
        if (_uiState.value.importing) return
        viewModelScope.launch {
            _uiState.update {
                it.copy(clearConfirmVisible = false, importing = true, errorMessage = null)
            }
            val clearError = (repository.clear() as? AppResult.Failure)?.error
            if (clearError == null) {
                _uiState.update {
                    it.copy(importing = false, infoMessage = "课表已清空")
                }
            } else {
                _uiState.update {
                    it.copy(importing = false, errorMessage = "清空课表失败：${clearError.message}")
                }
            }
        }
    }

    fun selectCourse(course: Course) {
        _uiState.update { it.copy(selectedCourse = course) }
    }

    fun dismissCourseDetail() {
        _uiState.update { it.copy(selectedCourse = null) }
    }

    fun dismissInfoMessage() {
        _uiState.update { it.copy(infoMessage = null) }
    }

    /** 页面回到前台时刷新“今天”高亮。 */
    fun refreshToday() {
        val today = Instant.ofEpochMilli(timeProvider.now())
            .atZone(ZoneId.systemDefault())
            .dayOfWeek
            .value
        _uiState.update { it.copy(todayWeekday = today) }
    }

    private companion object {
        const val DEFAULT_TABLE_NAME = "我的课表"
    }
}
