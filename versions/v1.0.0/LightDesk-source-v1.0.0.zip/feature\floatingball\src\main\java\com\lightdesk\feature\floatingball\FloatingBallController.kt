package com.lightdesk.feature.floatingball

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.lightdesk.core.common.AppLogger

/**
 * 悬浮球统一控制器：权限检查、启停服务、唤起主应用。
 *
 * 功能模块（如设置页）只与它交互，不直接操作 Service / WindowManager，
 * 方便后续替换悬浮球实现（例如改成系统级快捷入口）。
 */
object FloatingBallController {

    private const val TAG = "FloatingBallController"

    /** 启动来源标记，主应用据此记录“悬浮球”使用次数。 */
    const val EXTRA_LAUNCH_SOURCE = "com.lightdesk.extra.LAUNCH_SOURCE"
    const val SOURCE_FLOATING_BALL = "floating_ball"

    /** 是否已获得“显示在其他应用上层”权限。 */
    fun canDrawOverlays(context: Context): Boolean = Settings.canDrawOverlays(context)

    /** 跳转系统悬浮窗权限设置页。 */
    fun overlayPermissionIntent(context: Context): Intent =
        Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}"),
        )

    /**
     * 启动悬浮球服务；未授权时返回 false，由调用方引导授权。
     *
     * @param sizeDp 悬浮球直径（dp），来自 [com.lightdesk.core.model.AppSettings.floatingBallSizeDp]；
     *   服务内部会再次夹取到合理范围。
     */
    fun start(
        context: Context,
        sizeDp: Int = FloatingBallService.DEFAULT_SIZE_DP,
    ): Boolean {
        if (!canDrawOverlays(context)) return false
        return try {
            val intent = Intent(context, FloatingBallService::class.java)
                .putExtra(FloatingBallService.EXTRA_BALL_SIZE_DP, sizeDp)
            ContextCompat.startForegroundService(context, intent)
            true
        } catch (throwable: Throwable) {
            // 例如 Android 12+ 后台启动前台服务受限、系统禁止悬浮窗等
            AppLogger.e(TAG, "启动悬浮球服务失败", throwable)
            false
        }
    }

    /** 停止悬浮球服务；失败只记录日志（例如服务已不存在）。 */
    fun stop(context: Context) {
        runCatching {
            context.stopService(Intent(context, FloatingBallService::class.java))
        }.onFailure { AppLogger.w(TAG, "停止悬浮球服务失败", it) }
    }

    /** 服务是否正在运行。 */
    fun isRunning(): Boolean = FloatingBallService.isRunning.value

    /** 唤起主应用，并携带来源标记。 */
    fun mainAppIntent(context: Context): Intent? {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)
            ?: return null
        return launchIntent.apply {
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP,
            )
            putExtra(EXTRA_LAUNCH_SOURCE, SOURCE_FLOATING_BALL)
        }
    }

    /** 打开主应用；失败（如无启动入口）只记录日志，不影响悬浮球本身。 */
    internal fun launchMainApp(context: Context) {
        val intent = mainAppIntent(context)
        if (intent == null) {
            AppLogger.w(TAG, "未找到主应用启动入口，无法唤起轻桌面")
            return
        }
        runCatching { context.startActivity(intent) }
            .onFailure { AppLogger.e(TAG, "唤起主应用失败", it) }
    }
}
