@file:OptIn(ExperimentalMaterial3Api::class)

package com.lightdesk.feature.todo

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Checklist
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.lightdesk.core.common.TimeFormat
import com.lightdesk.core.designsystem.component.ConfirmDialog
import com.lightdesk.core.designsystem.component.EmptyState
import com.lightdesk.core.designsystem.component.ErrorBanner
import com.lightdesk.core.designsystem.component.LoadingView
import com.lightdesk.core.designsystem.component.PageHorizontalPadding
import com.lightdesk.core.designsystem.component.PrimaryButton
import com.lightdesk.core.designsystem.component.ScreenHeader
import com.lightdesk.core.designsystem.component.SecondaryButton
import com.lightdesk.core.designsystem.component.SectionCard
import com.lightdesk.core.designsystem.component.SettingValueRow
import com.lightdesk.core.designsystem.component.TagPill
import com.lightdesk.core.designsystem.component.TextAction
import com.lightdesk.core.designsystem.theme.LocalStatusColors
import com.lightdesk.core.model.Todo
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

/** 待办页面的用户动作集合，由 Route 从 ViewModel 绑定。 */
data class TodoActions(
    val onCreate: () -> Unit = {},
    val onEdit: (Todo) -> Unit = {},
    val onToggleDone: (Todo) -> Unit = {},
    val onRequestDelete: (Todo) -> Unit = {},
    val onDismissDelete: () -> Unit = {},
    val onConfirmDelete: () -> Unit = {},
    val onDismissEditor: () -> Unit = {},
    val onEditorTitleChange: (String) -> Unit = {},
    val onEditorNoteChange: (String) -> Unit = {},
    val onEditorSetNoDeadline: () -> Unit = {},
    val onEditorQuickDate: (Int) -> Unit = {},
    val onEditorDateSelected: (Long) -> Unit = {},
    val onEditorTimeSelected: (Int, Int) -> Unit = { _, _ -> },
    val onSave: () -> Unit = {},
    val onMessageShown: (Long) -> Unit = {},
    val onRetry: () -> Unit = {},
)

/**
 * 待办倒计时主界面：列表 + 实时倒计时 + 新增/编辑弹窗 + 删除确认。
 *
 * [now] 由 Route 每秒刷新；[warningMinutes] 来自全局设置，决定“临近截止”的橙色阈值。
 */
@Composable
fun TodoScreen(
    state: TodoUiState,
    now: Long,
    warningMinutes: Int,
    actions: TodoActions,
    modifier: Modifier = Modifier,
) {
    val snackbarHostState = remember { SnackbarHostState() }
    val message = state.message
    LaunchedEffect(message) {
        if (message != null) {
            snackbarHostState.showSnackbar(message.text)
            actions.onMessageShown(message.id)
        }
    }

    val sortedTodos = remember(state.todos) { sortTodos(state.todos) }
    val today = todayEpochDay(now)
    val pendingCount = state.todos.count { !it.done }
    val overdueCount = state.todos.count { it.isOverdue(now) }
    val loadError = state.loadError
    val showLoadFailedPlaceholder = loadError != null && state.todos.isEmpty()
    val subtitle = when {
        state.loading -> "正在加载…"
        showLoadFailedPlaceholder -> "加载失败"
        overdueCount > 0 -> "未完成 $pendingCount 项 · 已超时 $overdueCount 项"
        else -> "未完成 $pendingCount 项"
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            ScreenHeader(
                title = "待办倒计时",
                subtitle = subtitle,
                actions = {
                    TextAction(text = "新建", onClick = actions.onCreate)
                },
            )

            val bannerMessage = loadError
            if (bannerMessage != null && state.todos.isNotEmpty()) {
                ErrorBanner(
                    message = bannerMessage,
                    modifier = Modifier.padding(horizontal = PageHorizontalPadding),
                    onAction = actions.onRetry,
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            Box(modifier = Modifier.weight(1f)) {
                when {
                    state.loading -> LoadingView(modifier = Modifier.align(Alignment.TopCenter))
                    showLoadFailedPlaceholder -> EmptyState(
                        title = "待办加载失败",
                        description = loadError,
                        icon = Icons.Outlined.ErrorOutline,
                        actionLabel = "重试",
                        onAction = actions.onRetry,
                    )

                    state.todos.isEmpty() -> EmptyState(
                        title = "还没有待办",
                        description = "加一个倒计时待办，别错过重要的事",
                        icon = Icons.Outlined.Checklist,
                        actionLabel = "新建待办",
                        onAction = actions.onCreate,
                    )

                    else -> LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(
                            start = PageHorizontalPadding,
                            end = PageHorizontalPadding,
                            top = 4.dp,
                            bottom = 24.dp,
                        ),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        items(items = sortedTodos, key = { it.id }) { todo ->
                            TodoCard(
                                todo = todo,
                                now = now,
                                warningMinutes = warningMinutes,
                                onEdit = { actions.onEdit(todo) },
                                onToggleDone = { actions.onToggleDone(todo) },
                                onDelete = { actions.onRequestDelete(todo) },
                            )
                        }
                    }
                }
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(horizontal = PageHorizontalPadding, vertical = 12.dp),
        )

        state.editor?.let { editor ->
            TodoEditorDialog(
                editor = editor,
                saving = state.saving,
                today = today,
                onTitleChange = actions.onEditorTitleChange,
                onNoteChange = actions.onEditorNoteChange,
                onSetNoDeadline = actions.onEditorSetNoDeadline,
                onQuickDate = actions.onEditorQuickDate,
                onDateSelected = actions.onEditorDateSelected,
                onTimeSelected = actions.onEditorTimeSelected,
                onSave = actions.onSave,
                onDismiss = actions.onDismissEditor,
            )
        }

        state.pendingDelete?.let { todo ->
            ConfirmDialog(
                title = "删除待办",
                message = "确定要删除「${todo.title}」吗？删除后无法恢复。",
                onConfirm = actions.onConfirmDelete,
                onDismiss = actions.onDismissDelete,
                confirmText = "删除",
                destructive = true,
            )
        }
    }
}

@Composable
private fun TodoCard(
    todo: Todo,
    now: Long,
    warningMinutes: Int,
    onEdit: () -> Unit,
    onToggleDone: () -> Unit,
    onDelete: () -> Unit,
) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val status = LocalStatusColors.current
    val urgency = urgencyOf(todo, now, warningMinutes)
    val deadline = todo.deadline

    SectionCard(
        modifier = Modifier.clickable(onClick = onEdit),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
    ) {
        Row(verticalAlignment = Alignment.Top) {
            Checkbox(checked = todo.done, onCheckedChange = { onToggleDone() })
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = todo.title.ifBlank { "无标题" },
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    textDecoration = if (todo.done) TextDecoration.LineThrough else null,
                )
                if (todo.note.isNotBlank()) {
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = todo.note,
                        style = MaterialTheme.typography.bodyMedium,
                        color = muted,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Outlined.Schedule,
                        contentDescription = null,
                        tint = muted,
                        modifier = Modifier.size(14.dp),
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (deadline == null) {
                            "无截止时间"
                        } else {
                            TimeFormat.timestampToDateTimeText(deadline)
                        },
                        style = MaterialTheme.typography.labelMedium,
                        color = muted,
                    )
                    if (deadline != null) {
                        Spacer(modifier = Modifier.width(8.dp))
                        when (urgency) {
                            TodoUrgency.OVERDUE -> TagPill(text = "已超时", color = status.danger)
                            TodoUrgency.WARNING -> TagPill(text = "即将截止", color = status.warning)
                            TodoUrgency.DONE -> TagPill(text = "已完成", color = status.success)
                            else -> Unit
                        }
                    }
                }
                if (deadline != null && !todo.done) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = TimeFormat.countdownText(deadline - now),
                        style = MaterialTheme.typography.titleMedium,
                        color = when (urgency) {
                            TodoUrgency.OVERDUE -> status.danger
                            TodoUrgency.WARNING -> status.warning
                            else -> MaterialTheme.colorScheme.onSurface
                        },
                    )
                }
            }
            IconButton(onClick = onDelete) {
                Icon(
                    imageVector = Icons.Outlined.DeleteOutline,
                    contentDescription = "删除",
                    tint = status.danger,
                    modifier = Modifier.size(18.dp),
                )
            }
        }
    }
}

@Composable
private fun TodoEditorDialog(
    editor: TodoEditorState,
    saving: Boolean,
    today: Long,
    onTitleChange: (String) -> Unit,
    onNoteChange: (String) -> Unit,
    onSetNoDeadline: () -> Unit,
    onQuickDate: (Int) -> Unit,
    onDateSelected: (Long) -> Unit,
    onTimeSelected: (Int, Int) -> Unit,
    onSave: () -> Unit,
    onDismiss: () -> Unit,
) {
    var showDatePicker by remember { mutableStateOf(false) }
    var showTimePicker by remember { mutableStateOf(false) }
    val muted = MaterialTheme.colorScheme.onSurfaceVariant

    Dialog(
        onDismissRequest = { if (!saving) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background,
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .systemBarsPadding()
                    .imePadding()
                    .padding(horizontal = PageHorizontalPadding),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = if (editor.isEditing) "编辑待办" else "新建待办",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier.weight(1f),
                    )
                    IconButton(onClick = onDismiss, enabled = !saving) {
                        Icon(
                            imageVector = Icons.Outlined.Close,
                            contentDescription = "关闭",
                            tint = muted,
                        )
                    }
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                ) {
                    val titleError = editor.titleError
                    OutlinedTextField(
                        value = editor.title,
                        onValueChange = onTitleChange,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text(text = "标题") },
                        placeholder = { Text(text = "要完成什么事？") },
                        singleLine = true,
                        isError = titleError != null,
                        supportingText = if (titleError != null) {
                            { Text(text = titleError) }
                        } else {
                            null
                        },
                        shape = MaterialTheme.shapes.medium,
                    )

                    OutlinedTextField(
                        value = editor.note,
                        onValueChange = onNoteChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        label = { Text(text = "备注") },
                        placeholder = { Text(text = "补充说明（可选）") },
                        minLines = 2,
                        maxLines = 4,
                        shape = MaterialTheme.shapes.medium,
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "截止时间",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = editor.dateEpochDay == null,
                            onClick = onSetNoDeadline,
                            label = { Text(text = "无截止") },
                        )
                        FilterChip(
                            selected = editor.dateEpochDay == today,
                            onClick = { onQuickDate(0) },
                            label = { Text(text = "今天") },
                        )
                        FilterChip(
                            selected = editor.dateEpochDay == today + 1,
                            onClick = { onQuickDate(1) },
                            label = { Text(text = "明天") },
                        )
                    }

                    SettingValueRow(
                        label = "日期",
                        value = editor.dateEpochDay?.let { formatDateLabel(it) } ?: "未设置",
                        onClick = { showDatePicker = true },
                    )
                    SettingValueRow(
                        label = "时间",
                        value = TimeFormat.minutesToClock(editor.hour * 60 + editor.minute),
                        onClick = { showTimePicker = true },
                    )

                    val deadline = editor.dateEpochDay?.let {
                        combineDateAndTime(it, editor.hour, editor.minute)
                    }
                    if (deadline != null) {
                        Text(
                            text = "将于 ${TimeFormat.timestampToDateTimeText(deadline)} 截止",
                            style = MaterialTheme.typography.labelMedium,
                            color = muted,
                            modifier = Modifier.padding(top = 4.dp),
                        )
                    } else {
                        Text(
                            text = "未设置截止时间，不会显示倒计时",
                            style = MaterialTheme.typography.labelMedium,
                            color = muted,
                            modifier = Modifier.padding(top = 4.dp),
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp, bottom = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    SecondaryButton(
                        text = "取消",
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        enabled = !saving,
                    )
                    PrimaryButton(
                        text = "保存",
                        onClick = onSave,
                        modifier = Modifier.weight(1f),
                        loading = saving,
                    )
                }
            }
        }

        if (showDatePicker) {
            DeadlineDatePickerDialog(
                initialEpochDay = editor.dateEpochDay,
                onDismiss = { showDatePicker = false },
                onConfirm = { epochDay ->
                    showDatePicker = false
                    onDateSelected(epochDay)
                },
            )
        }
        if (showTimePicker) {
            DeadlineTimePickerDialog(
                initialHour = editor.hour,
                initialMinute = editor.minute,
                onDismiss = { showTimePicker = false },
                onConfirm = { hour, minute ->
                    showTimePicker = false
                    onTimeSelected(hour, minute)
                },
            )
        }
    }
}

@Composable
private fun DeadlineDatePickerDialog(
    initialEpochDay: Long?,
    onDismiss: () -> Unit,
    onConfirm: (Long) -> Unit,
) {
    val initialSelectedMillis = remember(initialEpochDay) {
        initialEpochDay?.let {
            LocalDate.ofEpochDay(it).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
        }
    }
    val datePickerState = rememberDatePickerState(initialSelectedDateMillis = initialSelectedMillis)
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextAction(
                text = "确定",
                onClick = {
                    val selected = datePickerState.selectedDateMillis
                    if (selected != null) {
                        val epochDay = Instant.ofEpochMilli(selected)
                            .atZone(ZoneOffset.UTC)
                            .toLocalDate()
                            .toEpochDay()
                        onConfirm(epochDay)
                    } else {
                        onDismiss()
                    }
                },
            )
        },
        dismissButton = {
            TextAction(
                text = "取消",
                onClick = onDismiss,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        },
    ) {
        DatePicker(state = datePickerState)
    }
}

@Composable
private fun DeadlineTimePickerDialog(
    initialHour: Int,
    initialMinute: Int,
    onDismiss: () -> Unit,
    onConfirm: (Int, Int) -> Unit,
) {
    val timePickerState = rememberTimePickerState(
        initialHour = initialHour,
        initialMinute = initialMinute,
        is24Hour = true,
    )
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(
            shape = MaterialTheme.shapes.large,
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.padding(24.dp),
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    text = "选择时间",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Spacer(modifier = Modifier.height(8.dp))
                TimePicker(state = timePickerState)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                ) {
                    TextAction(
                        text = "取消",
                        onClick = onDismiss,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    TextAction(
                        text = "确定",
                        onClick = { onConfirm(timePickerState.hour, timePickerState.minute) },
                    )
                }
            }
        }
    }
}
