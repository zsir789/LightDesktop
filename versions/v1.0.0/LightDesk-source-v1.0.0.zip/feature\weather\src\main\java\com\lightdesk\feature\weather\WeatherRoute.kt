package com.lightdesk.feature.weather

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lightdesk.core.common.simpleViewModelFactory
import com.lightdesk.core.data.UsageTracker
import com.lightdesk.core.data.repository.SettingsRepository
import com.lightdesk.core.data.repository.WeatherRepository
import com.lightdesk.core.model.FeatureKey

/**
 * 天气功能入口：Open-Meteo 联网获取 + 本地缓存降级。
 * 只依赖 core 中的仓储接口与工具，具体逻辑在 [WeatherViewModel] 与 [WeatherScreen] 中。
 */
@Composable
fun WeatherRoute(
    cacheRepository: WeatherRepository,
    settingsRepository: SettingsRepository,
    usageTracker: UsageTracker,
    modifier: Modifier = Modifier,
) {
    LaunchedEffect(Unit) {
        usageTracker.track(FeatureKey.WEATHER)
    }

    val viewModel: WeatherViewModel = viewModel(
        factory = simpleViewModelFactory { WeatherViewModel(cacheRepository, settingsRepository) },
    )
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    WeatherScreen(
        state = state,
        onRefresh = viewModel::refresh,
        modifier = modifier,
    )
}
