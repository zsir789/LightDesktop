package com.lightdesk.app.di

import android.content.Context
import com.lightdesk.core.common.DefaultDispatcherProvider
import com.lightdesk.core.common.DispatcherProvider
import com.lightdesk.core.common.SystemTimeProvider
import com.lightdesk.core.common.TimeProvider
import com.lightdesk.core.data.UsageTracker
import com.lightdesk.core.data.repository.CourseRepository
import com.lightdesk.core.data.repository.JsonCourseRepository
import com.lightdesk.core.data.repository.JsonMemoRepository
import com.lightdesk.core.data.repository.JsonSettingsRepository
import com.lightdesk.core.data.repository.JsonTodoRepository
import com.lightdesk.core.data.repository.JsonUsageRepository
import com.lightdesk.core.data.repository.JsonWeatherRepository
import com.lightdesk.core.data.repository.MemoRepository
import com.lightdesk.core.data.repository.SettingsRepository
import com.lightdesk.core.data.repository.TodoRepository
import com.lightdesk.core.data.repository.UsageRepository
import com.lightdesk.core.data.repository.WeatherRepository
import com.lightdesk.core.data.store.CourseTableStore
import com.lightdesk.core.data.store.JsonFileStore
import com.lightdesk.core.data.store.MemoStore
import com.lightdesk.core.data.store.SettingsStore
import com.lightdesk.core.data.store.TodoStore
import com.lightdesk.core.data.store.UsageStatsStore
import com.lightdesk.core.data.store.WeatherCacheStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.serialization.KSerializer
import java.io.File

/**
 * 手动依赖注入容器（组装层）。
 *
 * 特点：
 * 1. 所有仓储/服务在此单点创建，功能模块只依赖接口；
 * 2. 新增功能时在此登记依赖，不影响既有模块；
 * 3. 后续如需接入 Hilt/Koin，只需替换本容器，功能模块零改动。
 */
class AppContainer(context: Context) {

    private val baseDir = File(context.filesDir, "lightdesk")

    val appScope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    val timeProvider: TimeProvider = SystemTimeProvider()
    val dispatchers: DispatcherProvider = DefaultDispatcherProvider()

    private fun <T> store(
        fileName: String,
        serializer: KSerializer<T>,
        defaultValue: () -> T,
    ): JsonFileStore<T> = JsonFileStore(
        file = File(baseDir, fileName),
        serializer = serializer,
        defaultValue = defaultValue,
        ioDispatcher = dispatchers.io,
    )

    val settingsRepository: SettingsRepository = JsonSettingsRepository(
        store("settings.json", SettingsStore.serializer()) { SettingsStore() },
    )

    val memoRepository: MemoRepository = JsonMemoRepository(
        store("memos.json", MemoStore.serializer()) { MemoStore() },
    )

    val todoRepository: TodoRepository = JsonTodoRepository(
        store("todos.json", TodoStore.serializer()) { TodoStore() },
    )

    val courseRepository: CourseRepository = JsonCourseRepository(
        store("courses.json", CourseTableStore.serializer()) { CourseTableStore() },
    )

    val usageRepository: UsageRepository = JsonUsageRepository(
        store("usage_stats.json", UsageStatsStore.serializer()) { UsageStatsStore() },
    )

    val weatherRepository: WeatherRepository = JsonWeatherRepository(
        store("weather_cache.json", WeatherCacheStore.serializer()) { WeatherCacheStore() },
    )

    val usageTracker: UsageTracker = UsageTracker(
        repository = usageRepository,
        scope = appScope,
        timeProvider = timeProvider,
    )
}
