package com.lightdesk.feature.stats

import com.lightdesk.core.common.TimeFormat
import com.lightdesk.core.model.FeatureKey
import com.lightdesk.core.model.UsageStat
import com.lightdesk.core.model.UsageStats
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** 统计页展示逻辑的 JVM 单元测试（纯逻辑，不依赖 Android）。 */
class StatsPresentationTest {

    @Test
    fun `featureName covers all feature keys`() {
        val names = FeatureKey.entries.map { StatsPresentation.featureName(it) }
        assertEquals(listOf("备忘录", "课表", "天气", "悬浮球", "待办"), names)
    }

    @Test
    fun `displayOrder contains every feature key exactly once`() {
        assertEquals(FeatureKey.entries.size, StatsPresentation.displayOrder.size)
        assertEquals(FeatureKey.entries.toSet(), StatsPresentation.displayOrder.toSet())
    }

    @Test
    fun `lastUsedText returns placeholder for never used`() {
        assertEquals(StatsPresentation.NO_RECORD_TEXT, StatsPresentation.lastUsedText(0L))
        assertEquals(StatsPresentation.NO_RECORD_TEXT, StatsPresentation.lastUsedText(-1L))
    }

    @Test
    fun `lastUsedText formats real timestamp with TimeFormat`() {
        val timestamp = 1_729_500_000_000L
        assertEquals(
            TimeFormat.timestampToDateTimeText(timestamp),
            StatsPresentation.lastUsedText(timestamp),
        )
    }

    @Test
    fun `relativeProgress normalizes by max count`() {
        assertEquals(0f, StatsPresentation.relativeProgress(0L, 10L), 0.0001f)
        assertEquals(0.5f, StatsPresentation.relativeProgress(5L, 10L), 0.0001f)
        assertEquals(1f, StatsPresentation.relativeProgress(10L, 10L), 0.0001f)
        // 脏数据（count 大于 max）不允许进度条超过 100%
        assertEquals(1f, StatsPresentation.relativeProgress(20L, 10L), 0.0001f)
    }

    @Test
    fun `relativeProgress is zero when no usage yet`() {
        assertEquals(0f, StatsPresentation.relativeProgress(0L, 0L), 0.0001f)
    }

    @Test
    fun `percentOfTotal rounds and clamps`() {
        assertEquals(0, StatsPresentation.percentOfTotal(0L, 10L))
        assertEquals(0, StatsPresentation.percentOfTotal(5L, 0L))
        assertEquals(50, StatsPresentation.percentOfTotal(5L, 10L))
        assertEquals(33, StatsPresentation.percentOfTotal(1L, 3L))
        assertEquals(100, StatsPresentation.percentOfTotal(10L, 10L))
        assertEquals(100, StatsPresentation.percentOfTotal(20L, 10L))
    }

    @Test
    fun `hasAnyUsage is false for empty and all zero stats`() {
        assertFalse(StatsPresentation.hasAnyUsage(UsageStats()))
        assertFalse(
            StatsPresentation.hasAnyUsage(
                UsageStats(
                    listOf(
                        UsageStat(FeatureKey.MEMO, 0, 0),
                        UsageStat(FeatureKey.TODO, 0, 0),
                    ),
                ),
            ),
        )
        assertTrue(
            StatsPresentation.hasAnyUsage(
                UsageStats(listOf(UsageStat(FeatureKey.WEATHER, 1, 1_700_000_000_000L))),
            ),
        )
    }

    @Test
    fun `totalCount never returns negative value`() {
        assertEquals(0L, StatsPresentation.totalCount(UsageStats()))
        assertEquals(6L, StatsPresentation.totalCount(UsageStats(listOf(UsageStat(FeatureKey.MEMO, 6, 1L)))))
        assertEquals(0L, StatsPresentation.totalCount(UsageStats(listOf(UsageStat(FeatureKey.MEMO, -3, 1L)))))
    }

    @Test
    fun `buildRows keeps fixed order and fills missing features with zero`() {
        val stats = UsageStats(
            items = listOf(
                UsageStat(feature = FeatureKey.WEATHER, count = 8, lastUsedAt = 1_700_000_000_000L),
                UsageStat(feature = FeatureKey.MEMO, count = 4, lastUsedAt = 1_700_000_100_000L),
            ),
        )

        val rows = StatsPresentation.buildRows(stats)

        assertEquals(StatsPresentation.displayOrder, rows.map { it.feature })
        assertEquals(5, rows.size)

        val memo = rows.first { it.feature == FeatureKey.MEMO }
        assertEquals(4L, memo.count)
        assertEquals(0.5f, memo.relativeProgress, 0.0001f)
        assertEquals(TimeFormat.timestampToDateTimeText(1_700_000_100_000L), memo.lastUsedText)

        val weather = rows.first { it.feature == FeatureKey.WEATHER }
        assertEquals(8L, weather.count)
        assertEquals(1f, weather.relativeProgress, 0.0001f)

        val todo = rows.first { it.feature == FeatureKey.TODO }
        assertEquals(0L, todo.count)
        assertEquals(StatsPresentation.NO_RECORD_TEXT, todo.lastUsedText)
        assertEquals(0f, todo.relativeProgress, 0.0001f)
        assertEquals(0, todo.percentOfTotal)
    }

    @Test
    fun `buildRows percentOfTotal uses total across all features`() {
        val stats = UsageStats(
            items = listOf(
                UsageStat(FeatureKey.MEMO, 3, 0L),
                UsageStat(FeatureKey.TODO, 7, 0L),
            ),
        )

        val rows = StatsPresentation.buildRows(stats)

        assertEquals(30, rows.first { it.feature == FeatureKey.MEMO }.percentOfTotal)
        assertEquals(70, rows.first { it.feature == FeatureKey.TODO }.percentOfTotal)
    }
}
