package com.lightdesk.feature.stats

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lightdesk.core.common.simpleViewModelFactory
import com.lightdesk.core.data.repository.UsageRepository

/**
 * 使用统计页对外唯一入口。
 *
 * 数据完全来自 [UsageRepository]，页面本身不记录使用次数；
 * [onOpenSettings] 由应用层注入，用于打开设置页（右上角入口）。
 */
@Composable
fun StatsRoute(
    usageRepository: UsageRepository,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val viewModel: StatsViewModel = viewModel(
        factory = simpleViewModelFactory<StatsViewModel> { StatsViewModel(usageRepository) },
    )
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    StatsScreen(
        uiState = uiState,
        onOpenSettings = onOpenSettings,
        onReset = viewModel::reset,
        onDismissMessage = viewModel::dismissMessage,
        modifier = modifier,
    )
}
