package com.lightdesk.core.model

import kotlinx.serialization.Serializable

/** 主题模式。 */
@Serializable
enum class ThemeMode {
    SYSTEM,
    LIGHT,
    DARK,
}

/**
 * 全局设置。所有“可调参数”集中在此，避免散落在代码中形成硬编码；
 * 新增设置项时只需追加字段并提供默认值，旧版本数据可平滑兼容。
 */
@Serializable
data class AppSettings(
    /** 悬浮球开关（持久化，开机后可恢复）。 */
    val floatingBallEnabled: Boolean = false,
    /** 悬浮球直径（dp），预留扩展点。 */
    val floatingBallSizeDp: Int = 56,
    /** 天气城市名称。 */
    val weatherCity: String = "北京",
    val weatherLatitude: Double = 39.9042,
    val weatherLongitude: Double = 116.4074,
    /** 待办“临近截止”的预警阈值（分钟），默认 24 小时。 */
    val countdownWarningMinutes: Int = 24 * 60,
    /** 课表是否以周一为一周起点（预留，当前默认周一）。 */
    val weekStartMonday: Boolean = true,
    /** 主题模式。 */
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    /** 是否记录使用统计（预留开关）。 */
    val usageStatsEnabled: Boolean = true,
)
