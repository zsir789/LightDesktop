package com.lightdesk.feature.floatingball

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.TextView
import androidx.compose.ui.graphics.toArgb
import androidx.core.app.NotificationCompat
import com.lightdesk.core.common.AppLogger
import com.lightdesk.core.designsystem.theme.LightDeskColors
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.hypot
import kotlin.math.roundToInt

/**
 * 桌面悬浮球前台服务。
 *
 * 职责：
 * 1. 通过 WindowManager 添加一个可拖动的圆形按钮（TYPE_APPLICATION_OVERLAY）；
 * 2. 轻点唤起主应用，拖动时跟随手指，松手自动吸附到屏幕左右边缘；
 * 3. 以前台服务方式运行（specialUse 类型），避免被系统回收；所有窗口操作均做异常兜底。
 *
 * 说明：服务本身不读取业务数据，点击行为通过 Intent 交给主应用处理（主应用据此记录使用次数），
 * 保持悬浮球与业务数据层解耦。
 */
class FloatingBallService : Service() {

    companion object {
        private const val TAG = "FloatingBallService"
        private const val CHANNEL_ID = "floating_ball"
        private const val CHANNEL_NAME = "悬浮球"
        private const val NOTIFICATION_ID = 1001
        private const val CLICK_THRESHOLD_MS = 300L
        private const val SNAP_ANIMATION_MS = 180L
        private const val EDGE_MARGIN_DP = 12

        /** 默认悬浮球直径（dp），与 [com.lightdesk.core.model.AppSettings.floatingBallSizeDp] 默认值一致。 */
        const val DEFAULT_SIZE_DP = 56

        /** 启动服务时传入悬浮球直径（dp）的 Intent extra。 */
        const val EXTRA_BALL_SIZE_DP = "com.lightdesk.extra.BALL_SIZE_DP"

        private val _isRunning = MutableStateFlow(false)

        /** 服务运行状态；设置页据此展示“运行中/未运行”。 */
        val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()
    }

    private lateinit var windowManager: WindowManager
    private var ballView: View? = null
    private var layoutParams: WindowManager.LayoutParams? = null
    private var snapAnimator: ValueAnimator? = null

    private var screenWidth: Int = 0
    private var screenHeight: Int = 0
    private var ballSizePx: Int = 0
    private var edgeMarginPx: Int = 0
    private var touchSlop: Int = 0

    private var downRawX = 0f
    private var downRawY = 0f
    private var dragStartX = 0
    private var dragStartY = 0
    private var downAt = 0L
    private var dragging = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        try {
            windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            touchSlop = ViewConfiguration.get(this).scaledTouchSlop
            edgeMarginPx = dpToPx(EDGE_MARGIN_DP.toFloat())
        } catch (throwable: Throwable) {
            AppLogger.e(TAG, "悬浮球服务初始化失败", throwable)
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!::windowManager.isInitialized) {
            stopSelf()
            return START_NOT_STICKY
        }
        // 前台服务必须在启动后尽快 startForeground；失败（如后台启动限制）时直接停止，避免系统超时崩溃
        if (!startForegroundSafely()) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (ballView == null) {
            val requestedSizeDp = intent?.getIntExtra(EXTRA_BALL_SIZE_DP, DEFAULT_SIZE_DP)
                ?: DEFAULT_SIZE_DP
            if (!addBallView(requestedSizeDp)) {
                stopSelf()
                return START_NOT_STICKY
            }
        }
        _isRunning.value = true
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyScreenBoundsAfterConfigChange()
    }

    override fun onDestroy() {
        _isRunning.value = false
        snapAnimator?.cancel()
        snapAnimator = null
        removeBallView()
        runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
        super.onDestroy()
    }

    // region 前台通知

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java) ?: return
        val channel = NotificationChannel(
            CHANNEL_ID,
            CHANNEL_NAME,
            NotificationManager.IMPORTANCE_LOW,
        ).apply {
            description = "保持悬浮球在后台运行"
            setShowBadge(false)
        }
        runCatching { manager.createNotificationChannel(channel) }
    }

    private fun buildNotification(): Notification {
        val contentIntent = FloatingBallController.mainAppIntent(this)?.let { launchIntent ->
            PendingIntent.getActivity(
                this,
                0,
                launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_floating_ball)
            .setContentTitle("轻桌面悬浮球运行中")
            .setContentText("点击返回轻桌面，可在设置中关闭悬浮球")
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setOngoing(true)
            .setShowWhen(false)
            .setSilent(true)
            .apply { contentIntent?.let { setContentIntent(it) } }
            .build()
    }

    private fun startForegroundSafely(): Boolean {
        return try {
            createNotificationChannel()
            val notification = buildNotification()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE,
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            true
        } catch (throwable: Throwable) {
            AppLogger.e(TAG, "启动前台服务失败", throwable)
            false
        }
    }

    // endregion

    // region 悬浮球视图

    private fun updateScreenSize() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val bounds = windowManager.currentWindowMetrics.bounds
                screenWidth = bounds.width()
                screenHeight = bounds.height()
            } else {
                val metrics = DisplayMetrics()
                @Suppress("DEPRECATION")
                windowManager.defaultDisplay.getMetrics(metrics)
                screenWidth = metrics.widthPixels
                screenHeight = metrics.heightPixels
            }
        } catch (throwable: Throwable) {
            AppLogger.w(TAG, "获取屏幕尺寸失败，使用资源尺寸兜底", throwable)
            val metrics = resources.displayMetrics
            screenWidth = metrics.widthPixels
            screenHeight = metrics.heightPixels
        }
    }

    private fun createBallView(): View {
        val density = resources.displayMetrics.density
        val background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(LightDeskColors.Primary.toArgb())
            setStroke(
                (1.5f * density).roundToInt(),
                LightDeskColors.OnPrimary.copy(alpha = 0.28f).toArgb(),
            )
        }
        return TextView(this).apply {
            text = "轻"
            gravity = Gravity.CENTER
            setTextColor(LightDeskColors.OnPrimary.toArgb())
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            this.background = background
            elevation = 12f * density
            contentDescription = "轻桌面悬浮球，点击打开应用"
            setOnTouchListener(makeDragTouchListener())
        }
    }

    private fun addBallView(requestedSizeDp: Int): Boolean {
        if (ballView != null) return true
        if (!FloatingBallController.canDrawOverlays(this)) {
            AppLogger.w(TAG, "缺少“显示在其他应用上层”权限，无法添加悬浮球")
            return false
        }
        return try {
            updateScreenSize()
            ballSizePx = dpToPx(FloatingBallGeometry.clampSizeDp(requestedSizeDp).toFloat())
            val view = createBallView()
            val params = WindowManager.LayoutParams(
                ballSizePx,
                ballSizePx,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT,
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = FloatingBallGeometry.initialX(screenWidth, ballSizePx, edgeMarginPx)
                y = FloatingBallGeometry.initialY(screenHeight, ballSizePx)
            }
            windowManager.addView(view, params)
            ballView = view
            layoutParams = params
            true
        } catch (throwable: Throwable) {
            AppLogger.e(TAG, "添加悬浮球失败", throwable)
            removeBallView()
            false
        }
    }

    private fun removeBallView() {
        snapAnimator?.cancel()
        snapAnimator = null
        val view = ballView ?: return
        ballView = null
        layoutParams = null
        runCatching { windowManager.removeView(view) }
            .onFailure { AppLogger.w(TAG, "移除悬浮球失败", it) }
    }

    /** 屏幕旋转/尺寸变化后重新夹取位置，避免悬浮球跑到屏幕外。 */
    private fun applyScreenBoundsAfterConfigChange() {
        val view = ballView ?: return
        val params = layoutParams ?: return
        try {
            updateScreenSize()
            params.x = FloatingBallGeometry.edgeSnapTargetX(
                currentX = params.x,
                screenWidth = screenWidth,
                ballSize = ballSizePx,
                margin = edgeMarginPx,
            )
            params.y = FloatingBallGeometry.clampY(params.y, screenHeight, ballSizePx)
            windowManager.updateViewLayout(view, params)
        } catch (throwable: Throwable) {
            AppLogger.w(TAG, "屏幕尺寸变化后更新悬浮球位置失败", throwable)
        }
    }

    // endregion

    // region 手势

    private fun makeDragTouchListener(): View.OnTouchListener {
        return View.OnTouchListener { _, event ->
            val params = layoutParams ?: return@OnTouchListener false
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragStartX = params.x
                    dragStartY = params.y
                    downRawX = event.rawX
                    downRawY = event.rawY
                    downAt = SystemClock.uptimeMillis()
                    dragging = false
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    if (!dragging) {
                        val moved = hypot(
                            (event.rawX - downRawX).toDouble(),
                            (event.rawY - downRawY).toDouble(),
                        )
                        dragging = moved > touchSlop
                    }
                    if (dragging) {
                        params.x = FloatingBallGeometry.clampX(
                            x = dragStartX + (event.rawX - downRawX).roundToInt(),
                            screenWidth = screenWidth,
                            ballSize = ballSizePx,
                        )
                        params.y = FloatingBallGeometry.clampY(
                            y = dragStartY + (event.rawY - downRawY).roundToInt(),
                            screenHeight = screenHeight,
                            ballSize = ballSizePx,
                        )
                        runCatching { windowManager.updateViewLayout(ballView, params) }
                    }
                    true
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val elapsed = SystemClock.uptimeMillis() - downAt
                    val clicked = !dragging &&
                        event.actionMasked == MotionEvent.ACTION_UP &&
                        elapsed <= CLICK_THRESHOLD_MS
                    dragging = false
                    if (clicked) {
                        FloatingBallController.launchMainApp(this@FloatingBallService)
                    } else {
                        snapToEdge()
                    }
                    true
                }

                else -> false
            }
        }
    }

    /** 松手后吸附到最近的左右边缘；动画期间取消上一次动画，避免位置抖动。 */
    private fun snapToEdge() {
        val view = ballView ?: return
        val params = layoutParams ?: return
        snapAnimator?.cancel()
        val targetX = FloatingBallGeometry.edgeSnapTargetX(
            currentX = params.x,
            screenWidth = screenWidth,
            ballSize = ballSizePx,
            margin = edgeMarginPx,
        )
        if (params.x == targetX) return
        val animator = ValueAnimator.ofInt(params.x, targetX).apply {
            duration = SNAP_ANIMATION_MS
            addUpdateListener { animation ->
                val currentParams = layoutParams ?: return@addUpdateListener
                currentParams.x = animation.animatedValue as Int
                runCatching { windowManager.updateViewLayout(view, currentParams) }
            }
        }
        snapAnimator = animator
        runCatching { animator.start() }
            .onFailure { AppLogger.w(TAG, "边缘吸附动画执行失败", it) }
    }

    // endregion

    private fun dpToPx(dp: Float): Int = (dp * resources.displayMetrics.density).roundToInt()
}
