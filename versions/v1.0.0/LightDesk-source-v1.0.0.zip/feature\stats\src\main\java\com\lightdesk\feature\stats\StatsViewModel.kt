package com.lightdesk.feature.stats

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.lightdesk.core.common.AppLogger
import com.lightdesk.core.common.AppResult
import com.lightdesk.core.data.repository.UsageRepository
import com.lightdesk.core.model.UsageStats
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * 使用统计页状态。
 *
 * @param loading 首次数据尚未到达时为 true
 * @param stats 仓储返回的原始统计数据
 * @param resetting 重置请求进行中（按钮展示 loading，防止重复点击）
 * @param message 一次性提示（重置成功/失败），展示后由页面调用 [StatsViewModel.dismissMessage] 清除
 */
data class StatsUiState(
    val loading: Boolean = true,
    val stats: UsageStats = UsageStats(),
    val resetting: Boolean = false,
    val message: StatsMessage? = null,
)

/** 统计页一次性提示。 */
data class StatsMessage(
    val text: String,
    val isError: Boolean,
)

/**
 * 统计页 ViewModel：只读取 [UsageRepository] 的数据，自身不记录使用次数。
 * 数据流使用 WhileSubscribed，页面不可见时自动停止收集。
 */
class StatsViewModel(
    private val usageRepository: UsageRepository,
) : ViewModel() {

    private data class ActionState(
        val resetting: Boolean = false,
        val message: StatsMessage? = null,
    )

    private val actionState = MutableStateFlow(ActionState())

    val uiState: StateFlow<StatsUiState> = combine(
        usageRepository.observeStats().catch { throwable ->
            // 仓储读取异常不允许崩溃，降级为空统计并记录日志
            AppLogger.e(TAG, "读取使用统计失败", throwable)
            emit(UsageStats())
        },
        actionState,
    ) { stats, action ->
        StatsUiState(
            loading = false,
            stats = stats,
            resetting = action.resetting,
            message = action.message,
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS),
        initialValue = StatsUiState(),
    )

    /** 重置全部使用统计；失败时通过 [StatsUiState.message] 提示用户。 */
    fun reset() {
        if (actionState.value.resetting) return
        actionState.update { it.copy(resetting = true) }
        viewModelScope.launch {
            val message = try {
                when (val result = usageRepository.reset()) {
                    is AppResult.Success -> StatsMessage("使用统计已重置", isError = false)
                    is AppResult.Failure -> StatsMessage(
                        text = "重置失败：${result.error.message}",
                        isError = true,
                    )
                }
            } catch (cancellation: CancellationException) {
                throw cancellation
            } catch (throwable: Throwable) {
                AppLogger.e(TAG, "重置使用统计失败", throwable)
                StatsMessage("重置失败，请稍后重试", isError = true)
            }
            actionState.update { it.copy(resetting = false, message = message) }
        }
    }

    /** 用户已看到提示（或自动消失），清除一次性消息。 */
    fun dismissMessage() {
        actionState.update { it.copy(message = null) }
    }

    private companion object {
        const val TAG = "StatsViewModel"
        const val STOP_TIMEOUT_MS = 5_000L
    }
}
