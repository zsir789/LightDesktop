package com.lightdesk.core.model

import kotlinx.serialization.Serializable

/**
 * 备忘录：支持标题、正文、完成标记、置顶与时间戳。
 * 所有字段均有默认值，后续新增字段可兼容旧数据（JSON 解析忽略未知字段）。
 */
@Serializable
data class Memo(
    val id: String,
    val title: String,
    val content: String = "",
    val done: Boolean = false,
    val pinned: Boolean = false,
    val createdAt: Long = 0L,
    val updatedAt: Long = 0L,
) {
    val preview: String
        get() = content.lineSequence().firstOrNull { it.isNotBlank() }.orEmpty()
}
