package com.lightdesk.feature.timetable.data

import com.lightdesk.core.model.Course
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.temporal.ChronoUnit
import java.time.temporal.TemporalAdjusters

/**
 * WakeUp 导出的 iCalendar（.ics）课表解析器。
 *
 * 纯 Kotlin 实现（只依赖 java.time），不依赖 Android，可直接在 JVM 单元测试中调用。
 *
 * 支持范围：
 * - 行折叠（CRLF + 空格/制表符续行）、BOM、CRLF/CR/LF 混用；
 * - 一个 VCALENDAR 中的多个 VEVENT，忽略 VALARM 等嵌套组件；
 * - DTSTART/DTEND 的 `TZID=...`、`Z` 结尾 UTC、无时区浮动时间、`VALUE=DATE` 全天事件；
 * - RRULE：`FREQ=WEEKLY` + `INTERVAL` + `BYDAY` + `UNTIL`/`COUNT`；
 * - `EXDATE`（单个属性多值、带 TZID 或 UTC 均可）；
 * - 同一门课多次出现（重复规则展开 / 每周一个 VEVENT）合并为一条课程 + 周次列表。
 *
 * 对无法识别的数据不会抛异常，而是返回 [IcsParseResult.Failure] 或收集到 warnings 中。
 */
class IcsParser(
    private val displayZone: ZoneId = ZoneId.systemDefault(),
) {

    fun parse(content: String): IcsParseResult {
        if (content.isBlank()) return IcsParseResult.Failure(EMPTY_FILE_MESSAGE)

        val lines = unfoldLines(content)
        if (lines.isEmpty()) return IcsParseResult.Failure(EMPTY_FILE_MESSAGE)

        val eventBlocks = collectEventComponents(lines)
        if (eventBlocks.isEmpty()) {
            return IcsParseResult.Failure("不是有效的 iCalendar 文件：未找到课表事件（VEVENT）")
        }

        val warnings = mutableListOf<String>()
        val events = eventBlocks.mapNotNull { properties -> parseEvent(properties, warnings) }
        if (events.isEmpty()) {
            return IcsParseResult.Failure("课表事件缺少可识别的时间信息，无法导入")
        }

        val occurrences = mutableListOf<Occurrence>()
        events.forEach { event -> occurrences += expandOccurrences(event, warnings) }
        if (occurrences.isEmpty()) {
            return IcsParseResult.Failure("重复规则与排除日期把所有课程都排除了，未生成任何课程")
        }

        val anchorMonday = occurrences
            .minOf { it.start.toLocalDate() }
            .with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val courses = mergeCourses(occurrences, anchorMonday)
        if (courses.isEmpty()) {
            return IcsParseResult.Failure("未能从课表事件中识别出课程")
        }

        return IcsParseResult.Success(
            courses = courses,
            eventCount = eventBlocks.size,
            warnings = warnings.distinct(),
        )
    }

    // ---------------------------------------------------------------------
    // 文本预处理
    // ---------------------------------------------------------------------

    /** 去掉 BOM、统一换行符，并按 RFC 5545 展开折叠行。 */
    private fun unfoldLines(content: String): List<String> {
        val normalized = content
            .removePrefix("\uFEFF")
            .replace("\r\n", "\n")
            .replace('\r', '\n')
        val logicalLines = mutableListOf<String>()
        normalized.split('\n').forEach { rawLine ->
            val isContinuation = rawLine.isNotEmpty() && (rawLine[0] == ' ' || rawLine[0] == '\t')
            if (isContinuation) {
                if (logicalLines.isEmpty()) {
                    logicalLines += rawLine.substring(1)
                } else {
                    val lastIndex = logicalLines.lastIndex
                    logicalLines[lastIndex] = logicalLines[lastIndex] + rawLine.substring(1)
                }
            } else {
                logicalLines += rawLine
            }
        }
        return logicalLines.filter { it.isNotBlank() }
    }

    /** 解析 BEGIN/END 组件树，取出所有 VEVENT 自身（不含 VALARM 等子组件）的属性。 */
    private fun collectEventComponents(lines: List<String>): List<List<IcsProperty>> {
        val events = mutableListOf<List<IcsProperty>>()
        var depth = 0
        var eventDepth = -1
        var current = mutableListOf<IcsProperty>()

        lines.forEach { line ->
            val property = parsePropertyLine(line) ?: return@forEach
            when (property.name) {
                "BEGIN" -> {
                    depth++
                    val component = property.value.trim().uppercase()
                    if (component == "VEVENT" && eventDepth < 0) {
                        eventDepth = depth
                        current = mutableListOf()
                    }
                }

                "END" -> {
                    val component = property.value.trim().uppercase()
                    if (component == "VEVENT" && eventDepth == depth) {
                        events += current
                        eventDepth = -1
                    }
                    depth = (depth - 1).coerceAtLeast(0)
                }

                else -> {
                    if (eventDepth > 0 && depth == eventDepth) {
                        current += property
                    }
                }
            }
        }
        return events
    }

    private fun parsePropertyLine(line: String): IcsProperty? {
        val separator = findValueSeparator(line)
        if (separator <= 0) return null
        val head = line.substring(0, separator)
        val value = line.substring(separator + 1)
        val segments = splitOutsideQuotes(head, ';')
        val name = segments.firstOrNull()?.trim()?.uppercase().orEmpty()
        if (name.isEmpty()) return null

        val params = mutableMapOf<String, MutableList<String>>()
        segments.drop(1).forEach { segment ->
            val equalsIndex = segment.indexOf('=')
            if (equalsIndex <= 0) return@forEach
            val key = segment.substring(0, equalsIndex).trim().uppercase()
            val rawValue = segment.substring(equalsIndex + 1).trim()
            val values = splitOutsideQuotes(rawValue, ',').map { it.trim().trim('"') }
            params.getOrPut(key) { mutableListOf() } += values
        }
        return IcsProperty(name = name, params = params, value = value)
    }

    private fun findValueSeparator(line: String): Int {
        var inQuotes = false
        line.forEachIndexed { index, char ->
            when {
                char == '"' -> inQuotes = !inQuotes
                char == ':' && !inQuotes -> return index
            }
        }
        return -1
    }

    private fun splitOutsideQuotes(text: String, delimiter: Char): List<String> {
        val result = mutableListOf<String>()
        val builder = StringBuilder()
        var inQuotes = false
        text.forEach { char ->
            when {
                char == '"' -> {
                    inQuotes = !inQuotes
                    builder.append(char)
                }

                char == delimiter && !inQuotes -> {
                    result += builder.toString()
                    builder.clear()
                }

                else -> builder.append(char)
            }
        }
        result += builder.toString()
        return result
    }

    // ---------------------------------------------------------------------
    // VEVENT -> 中间模型
    // ---------------------------------------------------------------------

    private fun parseEvent(properties: List<IcsProperty>, warnings: MutableList<String>): CourseEvent? {
        val rawSummary = unescapeText(properties.firstOrNull { it.name == "SUMMARY" }?.value.orEmpty()).trim()
        val titleForMessage = rawSummary.ifBlank { "未命名课程" }

        val startProperty = properties.firstOrNull { it.name == "DTSTART" }
        if (startProperty == null) {
            warnings += "事件「$titleForMessage」缺少 DTSTART，已跳过"
            return null
        }
        val start = parseDateTimeValue(startProperty.value, startProperty.params)
        if (start == null) {
            warnings += "事件「$titleForMessage」的起始时间无法识别，已跳过"
            return null
        }

        var title = rawSummary
        var location = unescapeText(
            properties.firstOrNull { it.name == "LOCATION" }?.value.orEmpty(),
        ).trim()
        if (location.isBlank()) {
            // WakeUp 的部分版本会把教室放在 SUMMARY 的 “课程@教室” 里。
            val atIndex = rawSummary.indexOf('@')
            if (atIndex in 1 until rawSummary.lastIndex) {
                title = rawSummary.substring(0, atIndex).trim()
                location = rawSummary.substring(atIndex + 1).trim()
            }
        }
        if (title.isBlank()) title = "未命名课程"

        val description = unescapeText(
            properties.firstOrNull { it.name == "DESCRIPTION" }?.value.orEmpty(),
        ).trim()
        val teacherMatch = TEACHER_PATTERN.find(description)
        val teacher = teacherMatch?.groupValues?.getOrNull(1)?.trim().orEmpty()
        val note = if (teacherMatch != null) {
            description.removeRange(teacherMatch.range).trim()
        } else {
            description
        }
        val endProperty = properties.firstOrNull { it.name == "DTEND" }
        val end = endProperty?.let { parseDateTimeValue(it.value, it.params) }
        val rule = properties.firstOrNull { it.name == "RRULE" }?.let { parseRecurrenceRule(it) }
        val excludedDates = parseExcludedDates(properties)

        return CourseEvent(
            title = title,
            teacher = teacher,
            location = location,
            note = note,
            start = start,
            end = end,
            rule = rule,
            exDates = excludedDates,
        )
    }

    private fun unescapeText(value: String): String {
        val builder = StringBuilder(value.length)
        var index = 0
        while (index < value.length) {
            val char = value[index]
            if (char == '\\' && index + 1 < value.length) {
                when (val next = value[index + 1]) {
                    'n', 'N' -> {
                        builder.append('\n')
                        index += 2
                    }

                    '\\', ',', ';' -> {
                        builder.append(next)
                        index += 2
                    }

                    else -> {
                        builder.append(char)
                        index += 1
                    }
                }
            } else {
                builder.append(char)
                index += 1
            }
        }
        return builder.toString()
    }

    // ---------------------------------------------------------------------
    // 时间解析（TZID / UTC / 浮动 / VALUE=DATE）
    // ---------------------------------------------------------------------

    private fun parseDateTimeValue(
        rawValue: String,
        params: Map<String, List<String>>,
    ): WallTime? {
        val raw = rawValue.trim().trim('"')
        if (raw.isEmpty()) return null

        val dateOnly = params["VALUE"]?.firstOrNull()?.equals("DATE", ignoreCase = true) == true ||
            (raw.length == 8 && raw.all { it.isDigit() })

        if (raw.endsWith("Z", ignoreCase = true)) {
            val wall = parseBasicDateTime(raw.dropLast(1)) ?: return null
            return WallTime(wall = wall, zone = ZoneOffset.UTC, dateOnly = dateOnly)
        }

        val wall = parseBasicDateTime(raw) ?: return null
        val tzid = params["TZID"]?.firstOrNull()?.trim()?.trim('"')?.takeIf { it.isNotEmpty() }
        val zone = tzid?.let { runCatching { ZoneId.of(it) }.getOrNull() }
        return WallTime(wall = wall, zone = zone, dateOnly = dateOnly)
    }

    /** 解析 `yyyyMMdd` / `yyyyMMdd'T'HHmm` / `yyyyMMdd'T'HHmmss` 形式。 */
    private fun parseBasicDateTime(text: String): LocalDateTime? {
        if (text.length < 8) return null
        val datePart = text.substring(0, 8)
        if (!datePart.all { it.isDigit() }) return null
        val date = runCatching {
            LocalDate.of(
                datePart.substring(0, 4).toInt(),
                datePart.substring(4, 6).toInt(),
                datePart.substring(6, 8).toInt(),
            )
        }.getOrNull() ?: return null

        if (text.length == 8) return date.atStartOfDay()
        if (text[8] != 'T') return null

        val timePart = text.substring(9)
        if (timePart.length != 4 && timePart.length != 6) return null
        if (!timePart.all { it.isDigit() }) return null
        val hour = timePart.substring(0, 2).toInt()
        val minute = timePart.substring(2, 4).toInt()
        val second = if (timePart.length == 6) timePart.substring(4, 6).toInt() else 0
        if (hour > 23 || minute > 59 || second > 59) return null
        return date.atTime(hour, minute, second)
    }

    private fun instantOf(wall: LocalDateTime, zone: ZoneId?): Instant =
        if (zone == null) wall.atZone(displayZone).toInstant() else wall.atZone(zone).toInstant()

    private fun displayOf(wall: LocalDateTime, zone: ZoneId?): LocalDateTime =
        if (zone == null) wall else wall.atZone(zone).withZoneSameInstant(displayZone).toLocalDateTime()

    // ---------------------------------------------------------------------
    // RRULE / EXDATE
    // ---------------------------------------------------------------------

    private fun parseRecurrenceRule(property: IcsProperty): RecurrenceRule? {
        val parts = mutableMapOf<String, String>()
        property.value.split(';').forEach { segment ->
            val equalsIndex = segment.indexOf('=')
            if (equalsIndex > 0) {
                parts[segment.substring(0, equalsIndex).trim().uppercase()] =
                    segment.substring(equalsIndex + 1).trim()
            }
        }
        val frequency = parts["FREQ"]?.uppercase() ?: return null
        val interval = parts["INTERVAL"]?.toIntOrNull()?.coerceAtLeast(1) ?: 1
        val byDays = parts["BYDAY"]
            ?.split(',')
            ?.mapNotNull { token ->
                val code = token.trim().takeLast(2).uppercase()
                WEEKDAY_CODES[code]
            }
            .orEmpty()
            .distinct()
            .sorted()
        val count = parts["COUNT"]?.toIntOrNull()?.takeIf { it > 0 }
        val until = parts["UNTIL"]?.let { parseUntil(it) }
        return RecurrenceRule(
            frequency = frequency,
            interval = interval,
            byDays = byDays,
            until = until,
            count = count,
        )
    }

    private fun parseUntil(text: String): Instant? {
        val raw = text.trim().trim('"')
        if (raw.isEmpty()) return null
        if (raw.endsWith("Z", ignoreCase = true)) {
            val wall = parseBasicDateTime(raw.dropLast(1)) ?: return null
            return wall.toInstant(ZoneOffset.UTC)
        }
        val wall = parseBasicDateTime(raw) ?: return null
        return if (raw.length == 8) {
            // UNTIL 为日期时，包含当天全部时间。
            wall.toLocalDate().plusDays(1).atStartOfDay(displayZone).toInstant().minusNanos(1)
        } else {
            wall.atZone(displayZone).toInstant()
        }
    }

    private fun parseExcludedDates(properties: List<IcsProperty>): Set<LocalDate> {
        val excluded = mutableSetOf<LocalDate>()
        for (property in properties) {
            if (property.name != "EXDATE") continue
            for (item in property.value.split(',')) {
                val wall = parseDateTimeValue(item.trim(), property.params) ?: continue
                excluded += displayOf(wall.wall, wall.zone).toLocalDate()
            }
        }
        return excluded
    }

    // ---------------------------------------------------------------------
    // 重复展开与课程合并
    // ---------------------------------------------------------------------

    private fun expandOccurrences(
        event: CourseEvent,
        warnings: MutableList<String>,
    ): List<Occurrence> {
        val startDisplay = displayOf(event.start.wall, event.start.zone)
        val durationMinutes = resolveDurationMinutes(event, startDisplay)
        val starts: List<LocalDateTime> = when {
            event.rule == null -> listOf(startDisplay)

            event.rule.frequency != "WEEKLY" -> {
                warnings += "事件「${event.title}」的重复规则 FREQ=${event.rule.frequency} 暂不支持，仅保留首次出现"
                listOf(startDisplay)
            }

            else -> expandWeekly(event, warnings)
        }
        return starts.map { occurrenceStart ->
            Occurrence(
                title = event.title,
                teacher = event.teacher,
                location = event.location,
                note = event.note,
                start = occurrenceStart,
                durationMinutes = durationMinutes,
                dateOnly = event.start.dateOnly,
            )
        }
    }

    private fun expandWeekly(event: CourseEvent, warnings: MutableList<String>): List<LocalDateTime> {
        val rule = event.rule ?: return emptyList()
        val wallStart = event.start.wall
        val zone = event.start.zone
        val weekdays = rule.byDays.ifEmpty { listOf(wallStart.dayOfWeek.value) }
        val baseMonday = wallStart.toLocalDate().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))

        val result = mutableListOf<LocalDateTime>()
        var emitted = 0
        var weekIndex = 0

        loop@ while (weekIndex < MAX_WEEKS) {
            val monday = baseMonday.plusWeeks(weekIndex.toLong() * rule.interval)
            for (weekday in weekdays) {
                val wallDate = monday.plusDays((weekday - 1).toLong())
                val wallDateTime = LocalDateTime.of(wallDate, wallStart.toLocalTime())
                if (wallDateTime.isBefore(wallStart)) continue

                val occurrenceInstant = instantOf(wallDateTime, zone)
                if (rule.until != null && occurrenceInstant.isAfter(rule.until)) break@loop
                if (rule.count != null && emitted >= rule.count) break@loop
                emitted++

                val displayStart = displayOf(wallDateTime, zone)
                if (displayStart.toLocalDate() in event.exDates) continue

                result += displayStart
                if (result.size >= MAX_OCCURRENCES_PER_EVENT) {
                    warnings += "事件「${event.title}」出现次数过多，仅保留前 $MAX_OCCURRENCES_PER_EVENT 次"
                    break@loop
                }
            }
            weekIndex++
        }
        return result
    }

    private fun resolveDurationMinutes(event: CourseEvent, startDisplay: LocalDateTime): Int {
        if (event.start.dateOnly) return MINUTES_PER_DAY
        val end = event.end ?: return DEFAULT_EVENT_DURATION_MINUTES
        val endDisplay = displayOf(end.wall, end.zone)
        val startMinuteOfDay = startDisplay.toLocalTime().toSecondOfDay() / 60
        val endMinuteOfDay = endDisplay.toLocalTime().toSecondOfDay() / 60
        val sameDate = endDisplay.toLocalDate() == startDisplay.toLocalDate()
        val duration = if (sameDate) endMinuteOfDay - startMinuteOfDay else MINUTES_PER_DAY - startMinuteOfDay
        return if (duration > 0) duration.coerceAtMost(MINUTES_PER_DAY) else DEFAULT_EVENT_DURATION_MINUTES
    }

    private fun mergeCourses(
        occurrences: List<Occurrence>,
        anchorMonday: LocalDate,
    ): List<Course> {
        val groups = LinkedHashMap<String, CourseGroup>()
        occurrences.forEach { occurrence ->
            val weekday = occurrence.start.dayOfWeek.value
            val startMinutes = occurrence.start.toLocalTime().toSecondDayMinute()
            val endMinutes = if (occurrence.dateOnly) {
                MINUTES_PER_DAY
            } else {
                (startMinutes + occurrence.durationMinutes).coerceAtMost(MINUTES_PER_DAY)
            }
            val key = listOf(
                occurrence.title,
                occurrence.teacher,
                occurrence.location,
                weekday.toString(),
                startMinutes.toString(),
                endMinutes.toString(),
            ).joinToString(KEY_SEPARATOR)

            val group = groups.getOrPut(key) {
                CourseGroup(
                    title = occurrence.title,
                    teacher = occurrence.teacher,
                    location = occurrence.location,
                    note = occurrence.note,
                    weekday = weekday,
                    startMinutes = startMinutes,
                    endMinutes = endMinutes,
                )
            }
            val weekNumber = (ChronoUnit.DAYS.between(anchorMonday, occurrence.start.toLocalDate()).toInt() / 7 + 1)
            if (weekNumber in 1..MAX_WEEK_NUMBER) {
                group.weeks += weekNumber
            }
        }

        val usedIds = mutableSetOf<String>()
        return groups.values
            .sortedWith(compareBy({ it.weekday }, { it.startMinutes }, { it.title }))
            .map { group ->
                val titleKey = "${group.title}|${group.teacher}|${group.location}"
                val colorSeed = titleKey.hashCode() and 0x7FFFFFFF
                var id = "ics-$colorSeed"
                var suffix = 1
                while (!usedIds.add(id)) {
                    id = "ics-$colorSeed-${suffix++}"
                }
                Course(
                    id = id,
                    title = group.title,
                    teacher = group.teacher,
                    location = group.location,
                    weekday = group.weekday,
                    startMinutes = group.startMinutes,
                    endMinutes = group.endMinutes,
                    weeks = group.weeks.toList(),
                    note = group.note,
                    colorSeed = colorSeed,
                )
            }
    }

    private fun java.time.LocalTime.toSecondDayMinute(): Int = toSecondOfDay() / 60

    // ---------------------------------------------------------------------
    // 内部数据结构
    // ---------------------------------------------------------------------

    private data class IcsProperty(
        val name: String,
        val params: Map<String, List<String>>,
        val value: String,
    )

    private data class WallTime(
        val wall: LocalDateTime,
        val zone: ZoneId?,
        val dateOnly: Boolean,
    )

    private data class RecurrenceRule(
        val frequency: String,
        val interval: Int,
        val byDays: List<Int>,
        val until: Instant?,
        val count: Int?,
    )

    private data class CourseEvent(
        val title: String,
        val teacher: String,
        val location: String,
        val note: String,
        val start: WallTime,
        val end: WallTime?,
        val rule: RecurrenceRule?,
        val exDates: Set<LocalDate>,
    )

    private data class Occurrence(
        val title: String,
        val teacher: String,
        val location: String,
        val note: String,
        val start: LocalDateTime,
        val durationMinutes: Int,
        val dateOnly: Boolean,
    )

    private class CourseGroup(
        val title: String,
        val teacher: String,
        val location: String,
        val note: String,
        val weekday: Int,
        val startMinutes: Int,
        val endMinutes: Int,
    ) {
        val weeks: java.util.SortedSet<Int> = sortedSetOf()
    }

    companion object {
        /** 单个事件最多展开的出现次数，避免异常 RRULE 造成卡顿。 */
        const val MAX_OCCURRENCES_PER_EVENT = 400

        /** 重复规则最多向后展开的教学周数（无 UNTIL 时兜底）。 */
        const val MAX_WEEKS = 60

        /** 周次上限，超出范围的日期（多半是不同学期的旧数据）直接忽略。 */
        const val MAX_WEEK_NUMBER = 60

        /** 事件缺少 DTEND 时使用的默认时长（分钟）。 */
        const val DEFAULT_EVENT_DURATION_MINUTES = 60

        private const val MINUTES_PER_DAY = 24 * 60
        private const val EMPTY_FILE_MESSAGE = "文件内容为空，无法导入课表"
        private const val KEY_SEPARATOR = "\u0001"

        private val TEACHER_PATTERN = Regex("""(?:授课教师|任课教师|教师|老师)\s*[:：]\s*([^\n\r]+)""")

        private val WEEKDAY_CODES = mapOf(
            "MO" to 1,
            "TU" to 2,
            "WE" to 3,
            "TH" to 4,
            "FR" to 5,
            "SA" to 6,
            "SU" to 7,
        )
    }
}

/** ICS 解析结果：失败时给出可直接展示的中文错误信息，不抛异常。 */
sealed interface IcsParseResult {
    data class Success(
        val courses: List<Course>,
        val eventCount: Int,
        val warnings: List<String>,
    ) : IcsParseResult

    data class Failure(val message: String) : IcsParseResult
}
