package com.lightdesk.feature.todo

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.lightdesk.core.common.AppError
import com.lightdesk.core.common.AppResult
import com.lightdesk.core.common.ErrorCode
import com.lightdesk.core.common.TimeProvider
import com.lightdesk.core.data.repository.TodoRepository
import com.lightdesk.core.model.Todo
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.ZoneId

/** 一次性提示消息（带自增 id，避免重复弹出同一条）。 */
data class TodoUiMessage(val id: Long, val text: String)

/**
 * 编辑弹窗表单状态。
 *
 * 截止时间拆成“日期 + 时分”两个字段，交给 DatePicker / TimePicker 分别修改，
 * [dateEpochDay] 为 null 表示“无截止时间”。保存时才组合成时间戳。
 */
data class TodoEditorState(
    val editingId: String? = null,
    val title: String = "",
    val note: String = "",
    val dateEpochDay: Long? = null,
    val hour: Int = DEFAULT_DEADLINE_HOUR,
    val minute: Int = 0,
    val titleError: String? = null,
) {
    val isEditing: Boolean get() = editingId != null

    /** 组合出用于持久化的截止时间戳；没有选择日期时为 null。 */
    fun deadlineMillis(zoneId: ZoneId): Long? =
        dateEpochDay?.let { combineDateAndTime(it, hour, minute, zoneId) }
}

/** 待办页面完整 UI 状态。 */
data class TodoUiState(
    val loading: Boolean = true,
    val todos: List<Todo> = emptyList(),
    val loadError: String? = null,
    val editor: TodoEditorState? = null,
    val saving: Boolean = false,
    val pendingDelete: Todo? = null,
    val message: TodoUiMessage? = null,
)

/**
 * 待办页面状态持有者：负责仓储读写、编辑表单与一次性提示。
 * 倒计时刷新由 UI 侧通过 [TimeProvider] 每秒驱动，不放在 ViewModel 里，页面不可见时自动停止。
 */
class TodoViewModel(
    private val repository: TodoRepository,
    private val timeProvider: TimeProvider,
    private val zoneId: ZoneId = ZoneId.systemDefault(),
) : ViewModel() {

    private val _uiState = MutableStateFlow(TodoUiState())
    val uiState: StateFlow<TodoUiState> = _uiState.asStateFlow()

    private var observerJob: Job? = null
    private var messageSeq = 0L

    init {
        observeTodos()
    }

    private fun observeTodos() {
        observerJob?.cancel()
        observerJob = viewModelScope.launch {
            repository.observeTodos()
                .catch { throwable ->
                    if (throwable is CancellationException) throw throwable
                    _uiState.update {
                        it.copy(
                            loading = false,
                            loadError = "待办加载失败：${throwable.message ?: "未知错误"}",
                        )
                    }
                }
                .collect { todos ->
                    _uiState.update { state ->
                        state.copy(todos = todos, loading = false, loadError = null)
                    }
                }
        }
    }

    fun retryLoad() {
        _uiState.update { it.copy(loading = true, loadError = null) }
        observeTodos()
    }

    fun startCreate() {
        _uiState.update { it.copy(editor = TodoEditorState()) }
    }

    fun startEdit(todo: Todo) {
        _uiState.update { it.copy(editor = todoEditorState(todo, zoneId)) }
    }

    fun dismissEditor() {
        if (_uiState.value.saving) return
        _uiState.update { it.copy(editor = null) }
    }

    fun onEditorTitleChange(title: String) {
        updateEditor { it.copy(title = title, titleError = null) }
    }

    fun onEditorNoteChange(note: String) {
        updateEditor { it.copy(note = note) }
    }

    /** 快捷项“无截止时间”。 */
    fun onEditorSetNoDeadline() {
        updateEditor { it.copy(dateEpochDay = null) }
    }

    /** 快捷项“今天/明天”：[daysFromToday] 为 0 表示今天、1 表示明天。 */
    fun onEditorQuickDate(daysFromToday: Int) {
        val target = todayEpochDay(timeProvider.now(), zoneId) + daysFromToday
        updateEditor { it.copy(dateEpochDay = target) }
    }

    /** DatePicker 选择结果。 */
    fun onEditorDateSelected(dateEpochDay: Long) {
        updateEditor { it.copy(dateEpochDay = dateEpochDay) }
    }

    /**
     * TimePicker 选择结果：若尚未选择日期，默认落在“今天”，
     * 避免用户只改时间却因为没有日期而保存不出截止时间。
     */
    fun onEditorTimeSelected(hour: Int, minute: Int) {
        val today = todayEpochDay(timeProvider.now(), zoneId)
        updateEditor {
            it.copy(
                dateEpochDay = it.dateEpochDay ?: today,
                hour = hour.coerceIn(0, 23),
                minute = minute.coerceIn(0, 59),
            )
        }
    }

    fun save() {
        val state = _uiState.value
        val editor = state.editor ?: return
        if (state.saving) return

        val titleError = validateTodoTitle(editor.title)
        if (titleError != null) {
            updateEditor { it.copy(titleError = titleError) }
            return
        }

        val now = timeProvider.now()
        val existing = editor.editingId?.let { id -> state.todos.firstOrNull { it.id == id } }
        val todo = buildTodo(
            existing = existing,
            editingId = editor.editingId,
            title = editor.title,
            note = editor.note,
            deadline = editor.deadlineMillis(zoneId),
            now = now,
        )
        _uiState.update { it.copy(saving = true) }
        viewModelScope.launch {
            when (val result = upsert(todo)) {
                is AppResult.Success -> {
                    val message = pushMessage(if (editor.isEditing) "待办已更新" else "待办已添加")
                    _uiState.update {
                        it.copy(saving = false, editor = null, message = message)
                    }
                }

                is AppResult.Failure -> {
                    val message = pushMessage("保存失败：${result.error.message}")
                    _uiState.update { it.copy(saving = false, message = message) }
                }
            }
        }
    }

    fun toggleDone(todo: Todo) {
        val now = timeProvider.now()
        val target = todo.copy(
            done = !todo.done,
            completedAt = if (todo.done) null else now,
        )
        viewModelScope.launch {
            when (val result = upsert(target)) {
                is AppResult.Success -> Unit
                is AppResult.Failure -> publishMessage("更新失败：${result.error.message}")
            }
        }
    }

    fun requestDelete(todo: Todo) {
        _uiState.update { it.copy(pendingDelete = todo) }
    }

    fun dismissDelete() {
        _uiState.update { it.copy(pendingDelete = null) }
    }

    fun confirmDelete() {
        val target = _uiState.value.pendingDelete ?: return
        _uiState.update { it.copy(pendingDelete = null) }
        viewModelScope.launch {
            when (val result = delete(target.id)) {
                is AppResult.Success -> publishMessage("已删除「${target.title}」")
                is AppResult.Failure -> publishMessage("删除失败：${result.error.message}")
            }
        }
    }

    fun consumeMessage(id: Long) {
        _uiState.update { state ->
            if (state.message?.id == id) state.copy(message = null) else state
        }
    }

    private fun updateEditor(transform: (TodoEditorState) -> TodoEditorState) {
        _uiState.update { state ->
            val editor = state.editor ?: return@update state
            state.copy(editor = transform(editor))
        }
    }

    private fun pushMessage(text: String): TodoUiMessage {
        messageSeq += 1
        return TodoUiMessage(id = messageSeq, text = text)
    }

    private fun publishMessage(text: String) {
        val message = pushMessage(text)
        _uiState.update { it.copy(message = message) }
    }

    private suspend fun upsert(todo: Todo): AppResult<Unit> = try {
        repository.upsert(todo)
    } catch (cancellation: CancellationException) {
        throw cancellation
    } catch (throwable: Throwable) {
        AppResult.Failure(AppError.fromThrowable(throwable, ErrorCode.STORAGE))
    }

    private suspend fun delete(id: String): AppResult<Unit> = try {
        repository.delete(id)
    } catch (cancellation: CancellationException) {
        throw cancellation
    } catch (throwable: Throwable) {
        AppResult.Failure(AppError.fromThrowable(throwable, ErrorCode.STORAGE))
    }
}
