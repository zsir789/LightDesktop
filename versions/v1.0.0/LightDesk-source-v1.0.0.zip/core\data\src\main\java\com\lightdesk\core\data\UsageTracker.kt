package com.lightdesk.core.data

import com.lightdesk.core.common.AppLogger
import com.lightdesk.core.common.Logger
import com.lightdesk.core.common.TimeProvider
import com.lightdesk.core.data.repository.UsageRepository
import com.lightdesk.core.model.FeatureKey
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/**
 * 使用次数统计入口：功能模块只需调用 [track]，不关心持久化细节。
 *
 * 记录失败不应影响主流程，因此这里做兜底捕获（异常不会抛给 UI）。
 */
class UsageTracker(
    private val repository: UsageRepository,
    private val scope: CoroutineScope,
    private val timeProvider: TimeProvider,
    private val logger: Logger = AppLogger,
) {
    fun track(feature: FeatureKey) {
        scope.launch {
            runCatching {
                repository.record(feature, timeProvider.now())
            }.onFailure {
                logger.w("UsageTracker", "记录使用统计失败: $feature", it)
            }
        }
    }
}
