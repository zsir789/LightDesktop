pluginManagement {
    repositories {
        // 国内镜像优先，保证依赖下载稳定；同时保留官方仓库作为回退
        maven("https://maven.aliyun.com/repository/google")
        maven("https://maven.aliyun.com/repository/gradle-plugin")
        maven("https://maven.aliyun.com/repository/central")
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        maven("https://maven.aliyun.com/repository/google")
        maven("https://maven.aliyun.com/repository/central")
        google()
        mavenCentral()
    }
}

rootProject.name = "LightDesk"

// :app 为壳工程：负责应用装配、导航、主题与生命周期
include(":app")

// 核心能力模块（与业务无关，可被任意功能模块复用）
include(":core:common")
include(":core:model")
include(":core:data")
include(":core:designsystem")

// 功能模块（彼此解耦，仅依赖 core 层）
include(":feature:memo")
include(":feature:timetable")
include(":feature:weather")
include(":feature:todo")
include(":feature:stats")
include(":feature:floatingball")
