package com.lightdesk.feature.memo

import com.lightdesk.core.model.Memo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MemoLogicTest {

    private fun memo(
        id: String,
        title: String,
        content: String = "",
        done: Boolean = false,
        pinned: Boolean = false,
        createdAt: Long = 0L,
        updatedAt: Long = 0L,
    ) = Memo(
        id = id,
        title = title,
        content = content,
        done = done,
        pinned = pinned,
        createdAt = createdAt,
        updatedAt = updatedAt,
    )

    @Test
    fun `搜索同时匹配标题与正文且忽略大小写`() {
        val target = memo(id = "1", title = "Shopping List", content = "牛奶和面包")
        assertTrue(matchesMemoQuery(target, "shopping"))
        assertTrue(matchesMemoQuery(target, "面包"))
        assertTrue(matchesMemoQuery(target, "  牛奶  "))
        assertFalse(matchesMemoQuery(target, "咖啡"))
        assertTrue(matchesMemoQuery(target, "   "))
    }

    @Test
    fun `按完成状态筛选`() {
        val memos = listOf(
            memo(id = "1", title = "未完成 A"),
            memo(id = "2", title = "已完成 B", done = true),
            memo(id = "3", title = "未完成 C"),
        )
        assertEquals(listOf("1", "3"), filterMemos(memos, "", MemoFilter.ACTIVE).map { it.id })
        assertEquals(listOf("2"), filterMemos(memos, "", MemoFilter.DONE).map { it.id })
        assertEquals(3, filterMemos(memos, "", MemoFilter.ALL).size)
    }

    @Test
    fun `搜索与筛选可组合`() {
        val memos = listOf(
            memo(id = "1", title = "会议记录", content = "项目周会"),
            memo(id = "2", title = "会议记录（完成）", done = true),
            memo(id = "3", title = "购物清单"),
        )
        val result = filterMemos(memos, "会议", MemoFilter.ACTIVE).map { it.id }
        assertEquals(listOf("1"), result)
    }

    @Test
    fun `排序规则为置顶优先再按更新时间倒序`() {
        val memos = listOf(
            memo(id = "a", title = "普通新", updatedAt = 300L),
            memo(id = "b", title = "普通旧", updatedAt = 100L),
            memo(id = "c", title = "置顶旧", pinned = true, updatedAt = 50L),
            memo(id = "d", title = "置顶新", pinned = true, updatedAt = 200L),
        )
        assertEquals(listOf("d", "c", "a", "b"), sortMemos(memos).map { it.id })
    }

    @Test
    fun `列表展示顺序为筛选后排序`() {
        val memos = listOf(
            memo(id = "1", title = "苹果", updatedAt = 10L),
            memo(id = "2", title = "香蕉", done = true, updatedAt = 20L),
            memo(id = "3", title = "苹果汁", pinned = true, updatedAt = 5L),
        )
        val visible = visibleMemos(memos, "苹果", MemoFilter.ALL)
        assertEquals(listOf("3", "1"), visible.map { it.id })
    }

    @Test
    fun `标题校验拒绝空标题与超长标题`() {
        assertEquals("标题不能为空", validateMemoTitle(""))
        assertEquals("标题不能为空", validateMemoTitle("   "))
        assertNull(validateMemoTitle("正常标题"))
        assertNull(validateMemoTitle("a".repeat(MEMO_TITLE_MAX_LENGTH)))
        assertEquals(
            "标题不能超过 $MEMO_TITLE_MAX_LENGTH 个字符",
            validateMemoTitle("a".repeat(MEMO_TITLE_MAX_LENGTH + 1)),
        )
    }

    @Test
    fun `新增备忘生成 id 并写入时间戳`() {
        val memo = buildMemo(
            existing = null,
            editingId = null,
            title = "  标题  ",
            content = "正文\n",
            pinned = true,
            now = 1_000L,
            idGenerator = { "generated-id" },
        )
        assertEquals("generated-id", memo.id)
        assertEquals("标题", memo.title)
        assertEquals("正文", memo.content)
        assertTrue(memo.pinned)
        assertFalse(memo.done)
        assertEquals(1_000L, memo.createdAt)
        assertEquals(1_000L, memo.updatedAt)
    }

    @Test
    fun `编辑备忘保留原 id 创建时间与完成状态`() {
        val existing = memo(
            id = "keep-id",
            title = "旧标题",
            content = "旧正文",
            done = true,
            createdAt = 500L,
            updatedAt = 600L,
        )
        val updated = buildMemo(
            existing = existing,
            editingId = existing.id,
            title = "新标题",
            content = "新正文",
            pinned = true,
            now = 900L,
            idGenerator = { "should-not-be-used" },
        )
        assertEquals("keep-id", updated.id)
        assertTrue(updated.done)
        assertTrue(updated.pinned)
        assertEquals(500L, updated.createdAt)
        assertEquals(900L, updated.updatedAt)
        assertEquals("新标题", updated.title)
    }

    @Test
    fun `编辑目标已被删除时仍能按编辑 id 保存`() {
        val updated = buildMemo(
            existing = null,
            editingId = "editing-id",
            title = "标题",
            content = "",
            pinned = false,
            now = 700L,
            idGenerator = { "unused" },
        )
        assertEquals("editing-id", updated.id)
        assertEquals(700L, updated.createdAt)
    }
}
