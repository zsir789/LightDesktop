package com.lightdesk.app.boot

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.lightdesk.app.LightDeskApplication
import com.lightdesk.core.common.AppLogger
import com.lightdesk.feature.floatingball.FloatingBallController
import kotlinx.coroutines.launch

/**
 * 开机自启：若用户在设置中开启了悬浮球，开机后自动恢复悬浮球服务。
 * 失败时只记录日志，不影响开机流程。
 */
class FloatingBallBootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val application = context.applicationContext as? LightDeskApplication ?: return
        val pendingResult = goAsync()
        application.container.appScope.launch {
            try {
                val settings = application.container.settingsRepository.current()
                if (settings.floatingBallEnabled &&
                    FloatingBallController.canDrawOverlays(context)
                ) {
                    FloatingBallController.start(context)
                }
            } catch (throwable: Throwable) {
                AppLogger.e(TAG, "开机恢复悬浮球失败", throwable)
            } finally {
                pendingResult.finish()
            }
        }
    }

    private companion object {
        const val TAG = "FloatingBallBootReceiver"
    }
}
