package com.lightdesk.core.designsystem.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/** 语义化状态色：供“已完成/临近截止/异常”等场景使用，自动适配深浅色。 */
data class StatusColors(
    val success: Color,
    val warning: Color,
    val danger: Color,
    val info: Color,
    val muted: Color,
)

val LocalStatusColors = staticCompositionLocalOf {
    StatusColors(
        success = LightDeskColors.Success,
        warning = LightDeskColors.Warning,
        danger = LightDeskColors.Danger,
        info = LightDeskColors.Info,
        muted = LightDeskColors.LightOnSurfaceVariant,
    )
}

private val LightColorScheme = lightColorScheme(
    primary = LightDeskColors.Primary,
    onPrimary = LightDeskColors.OnPrimary,
    primaryContainer = Color(0xFFE3E8FF),
    onPrimaryContainer = Color(0xFF1B2A78),
    secondary = LightDeskColors.Secondary,
    onSecondary = LightDeskColors.OnSecondary,
    secondaryContainer = Color(0xFFD6F7F0),
    onSecondaryContainer = Color(0xFF0B4D41),
    tertiary = Color(0xFF8B5CF6),
    onTertiary = Color.White,
    background = LightDeskColors.LightBackground,
    onBackground = LightDeskColors.LightOnBackground,
    surface = LightDeskColors.LightSurface,
    onSurface = LightDeskColors.LightOnBackground,
    surfaceVariant = LightDeskColors.LightSurfaceVariant,
    onSurfaceVariant = LightDeskColors.LightOnSurfaceVariant,
    outline = LightDeskColors.LightOutline,
    outlineVariant = Color(0xFFE8EBF2),
    error = LightDeskColors.Danger,
    onError = Color.White,
    errorContainer = Color(0xFFFDE7E8),
    onErrorContainer = Color(0xFF7A1316),
)

private val DarkColorScheme = darkColorScheme(
    primary = LightDeskColors.PrimaryDark,
    onPrimary = Color(0xFF10142A),
    primaryContainer = Color(0xFF2A3768),
    onPrimaryContainer = Color(0xFFDCE2FF),
    secondary = LightDeskColors.SecondaryDark,
    onSecondary = Color(0xFF04221C),
    secondaryContainer = Color(0xFF0E4F45),
    onSecondaryContainer = Color(0xFFC9F7EE),
    tertiary = Color(0xFFB79CFF),
    onTertiary = Color(0xFF1D1140),
    background = LightDeskColors.DarkBackground,
    onBackground = LightDeskColors.DarkOnBackground,
    surface = LightDeskColors.DarkSurface,
    onSurface = LightDeskColors.DarkOnBackground,
    surfaceVariant = LightDeskColors.DarkSurfaceVariant,
    onSurfaceVariant = LightDeskColors.DarkOnSurfaceVariant,
    outline = LightDeskColors.DarkOutline,
    outlineVariant = Color(0xFF262B36),
    error = LightDeskColors.DangerDark,
    onError = Color(0xFF2A0507),
    errorContainer = Color(0xFF4A1418),
    onErrorContainer = Color(0xFFFFDADB),
)

/**
 * 应用唯一主题入口。功能模块统一使用 [LightDeskTheme]，
 * 不直接创建 MaterialTheme，保证后续换肤只改这一处。
 */
@Composable
fun LightDeskTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val statusColors = if (darkTheme) {
        StatusColors(
            success = LightDeskColors.SuccessDark,
            warning = LightDeskColors.WarningDark,
            danger = LightDeskColors.DangerDark,
            info = LightDeskColors.PrimaryDark,
            muted = LightDeskColors.DarkOnSurfaceVariant,
        )
    } else {
        StatusColors(
            success = LightDeskColors.Success,
            warning = LightDeskColors.Warning,
            danger = LightDeskColors.Danger,
            info = LightDeskColors.Primary,
            muted = LightDeskColors.LightOnSurfaceVariant,
        )
    }

    CompositionLocalProvider(LocalStatusColors provides statusColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = LightDeskTypography,
            shapes = LightDeskShapes,
            content = content,
        )
    }
}
