package com.lightdesk.core.model

import kotlinx.serialization.Serializable

/**
 * 需要统计使用次数的功能。新增功能时在此追加枚举值即可，
 * 统计页会自动适配（统计页通过 values() 遍历渲染）。
 */
@Serializable
enum class FeatureKey {
    MEMO,
    TIMETABLE,
    WEATHER,
    FLOATING_BALL,
    TODO,
}

@Serializable
data class UsageStat(
    val feature: FeatureKey,
    val count: Long = 0L,
    val lastUsedAt: Long = 0L,
)

/** 使用次数统计。以列表存储，兼容未知枚举值与后续新增功能。 */
@Serializable
data class UsageStats(
    val items: List<UsageStat> = emptyList(),
) {
    fun countOf(feature: FeatureKey): Long =
        items.firstOrNull { it.feature == feature }?.count ?: 0L

    fun lastUsedAt(feature: FeatureKey): Long =
        items.firstOrNull { it.feature == feature }?.lastUsedAt ?: 0L

    fun totalCount(): Long = items.sumOf { it.count }
}
