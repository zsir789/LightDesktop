# 开发契约（团队协作基线）

本文件是各功能模块的开发约定。**修改本文件需 Lead 同意**。

## 0. 环境与构建

- JDK 21：`D:\dsh_develop\_tools\jdk21`，Android SDK：`D:\dsh_develop\_tools\android-sdk`（`local.properties` 已配置）。
- Gradle Wrapper 位于项目根目录；PowerShell 构建示例：

```powershell
$env:JAVA_HOME='D:\dsh_develop\_tools\jdk21'
$env:ANDROID_HOME='D:\dsh_develop\_tools\android-sdk'
$env:Path="$env:JAVA_HOME\bin;$env:Path"
cd D:\dsh_develop\dsh_desktop_master
.\gradlew.bat :feature:memo:compileDebugKotlin --console=plain
```

- 依赖源已在 `settings.gradle.kts` 配好阿里云镜像，**不要**修改仓库配置。
- 只编译自己负责的模块做自查，最终整包由 Lead 负责；**不要**运行 `clean`，不要结束别人的 Gradle 进程。
- 如果构建报 `Daemon`/锁相关错误，等待 30 秒重试；连续失败请告知 Lead。

## 1. 文件所有权（严格不越界）

| 负责人 | 可写目录 |
| --- | --- |
| memo-todo | `feature/memo/**`、`feature/todo/**` |
| timetable-weather | `feature/timetable/**`、`feature/weather/**` |
| stats-floatingball | `feature/stats/**`、`feature/floatingball/**` |
| Lead | 其余全部（`:app`、`core/**`、Gradle 配置、docs、README、签名/打包） |

功能模块的 `build.gradle.kts` 与 `AndroidManifest.xml` 由 Lead 维护；若需要新增依赖或权限，
先在任务里说明，由 Lead 修改（或经 Lead 明确同意后自行修改）。**绝对不要修改模块之外的任何文件。**

## 2. 通用编码规范

- Kotlin + Jetpack Compose（Material3）+ 协程；单 Activity 架构，页面以 `@Composable` 路由函数暴露。
- UI 文案使用中文；字符串直接写在 Compose 里即可；颜色/圆角/字体必须来自设计系统（禁止硬编码色值）。
- 状态：`ViewModel` + `StateFlow`，UI 用 `collectAsStateWithLifecycle()` 收集；一次性的动作使用 `rememberCoroutineScope`。
- 依赖注入：只通过构造函数接收 `core:data` 的 Repository 接口与 `core:common` 工具，**不要在功能模块内 new 仓储**。
- 异常处理：所有可能失败的调用（仓储写、网络、文件解析）必须捕获并转成可见的 UI 提示（Snackbar/InfoBanner/ErrorBanner）；
  不允许出现未捕获异常导致崩溃。
- 使用统计：页面首次进入时调用一次 `usageTracker.track(FeatureKey.XXX)`（放在 `LaunchedEffect(Unit)` 中）。
- 不新增权限、不新增三方依赖（除非任务明确说明）。
- 国际化、深色模式适配：颜色用 `MaterialTheme.colorScheme` / `LocalStatusColors`，不要写死黑白。

## 3. 已实现的核心接口（只读，按此调用）

### 3.1 结果类型（`com.lightdesk.core.common`）

```kotlin
sealed interface AppResult<out T> {
    data class Success<T>(val value: T) : AppResult<T>
    data class Failure(val error: AppError) : AppResult<Nothing>
}
enum class ErrorCode { NETWORK, TIMEOUT, PARSE, STORAGE, PERMISSION, INVALID_INPUT, NOT_FOUND, UNKNOWN }
data class AppError(val code: ErrorCode, val message: String, val cause: Throwable? = null)

fun <T> AppResult<T>.getOrNull(): T?
inline fun <T> AppResult<T>.onSuccess(action: (T) -> Unit): AppResult<T>
inline fun <T> AppResult<T>.onFailure(action: (AppError) -> Unit): AppResult<T>
inline fun <T> attempt(code: ErrorCode = ErrorCode.UNKNOWN, block: () -> T): AppResult<T>
```

### 3.2 工具（`com.lightdesk.core.common`）

```kotlin
interface TimeProvider { fun now(): Long }            // 禁止用 System.currentTimeMillis()，用 timeProvider.now()
object TimeFormat {
    fun weekdayLabel(weekday: Int): String            // 1..7 -> 周一..周日
    fun minutesToClock(minutesOfDay: Int): String     // 485 -> "08:05"
    fun timestampToDateTimeText(timestamp: Long): String
    fun timestampToFullText(timestamp: Long): String
    fun countdownText(remainingMillis: Long): String  // "2天 03:12:09" / "已超时 00:12:03"
    fun deadlineHint(deadline: Long, now: Long): String
}
inline fun <reified VM : ViewModel> simpleViewModelFactory(crossinline create: () -> VM): ViewModelProvider.Factory
```

### 3.3 数据模型（`com.lightdesk.core.model`）

```kotlin
data class Memo(id, title, content, done, pinned, createdAt, updatedAt)
data class Todo(id, title, note, deadline: Long?, done, completedAt: Long?, remindBeforeMinutes: Int?, createdAt) {
    fun isOverdue(now: Long): Boolean
}
data class Course(id, title, teacher, location, weekday /*1..7*/, startMinutes, endMinutes, weeks, note, colorSeed)
data class CourseTable(name, sourceFile, sourceType, importedAt, courses: List<Course>)
data class WeatherSnapshot(city, latitude, longitude, temperature, apparentTemperature, humidity,
                           windSpeed, weatherCode, condition, updatedAt, daily: List<DailyForecast>, source)
data class DailyForecast(date, weatherCode, condition, tempMax, tempMin, precipitationProbability)
enum class FeatureKey { MEMO, TIMETABLE, WEATHER, FLOATING_BALL, TODO }
data class UsageStats(items: List<UsageStat>) { fun countOf(key): Long; fun lastUsedAt(key): Long; fun totalCount(): Long }
data class UsageStat(feature, count, lastUsedAt)
data class AppSettings(floatingBallEnabled, floatingBallSizeDp, weatherCity, weatherLatitude, weatherLongitude,
                       countdownWarningMinutes, weekStartMonday, themeMode, usageStatsEnabled)
enum class ThemeMode { SYSTEM, LIGHT, DARK }
```

### 3.4 仓储（`com.lightdesk.core.data.repository`）

```kotlin
interface MemoRepository {
    fun observeMemos(): Flow<List<Memo>>
    suspend fun upsert(memo: Memo): AppResult<Unit>
    suspend fun delete(id: String): AppResult<Unit>
    suspend fun get(id: String): Memo?
}
interface TodoRepository {
    fun observeTodos(): Flow<List<Todo>>
    suspend fun upsert(todo: Todo): AppResult<Unit>
    suspend fun delete(id: String): AppResult<Unit>
    suspend fun get(id: String): Todo?
}
interface CourseRepository {
    fun observeTable(): Flow<CourseTable?>
    suspend fun replace(table: CourseTable): AppResult<Unit>
    suspend fun clear(): AppResult<Unit>
}
interface UsageRepository {
    fun observeStats(): Flow<UsageStats>
    suspend fun record(feature: FeatureKey, at: Long): AppResult<Unit>
    suspend fun reset(): AppResult<Unit>
}
interface SettingsRepository {
    fun observeSettings(): Flow<AppSettings>
    suspend fun current(): AppSettings
    suspend fun update(transform: (AppSettings) -> AppSettings): AppResult<Unit>
}
interface WeatherRepository {
    fun observeCache(): Flow<WeatherSnapshot?>
    suspend fun cached(): WeatherSnapshot?
    suspend fun save(snapshot: WeatherSnapshot): AppResult<Unit>
    suspend fun clear(): AppResult<Unit>
}
```

`UsageTracker`（`com.lightdesk.core.data.UsageTracker`）：`fun track(feature: FeatureKey)`，异步、自带异常兜底。

## 4. 设计系统（`com.lightdesk.core.designsystem`）

主题：`LightDeskTheme { ... }`（app 已包裹，功能模块直接使用 Material3 组件即可）。

通用组件：

```kotlin
ScreenHeader(title, modifier, subtitle, actions)      // 页面标题区
SectionCard(modifier, contentPadding) { ... }         // 白底圆角卡片
SectionTitle(text, modifier, trailing)
EmptyState(title, modifier, description, icon, actionLabel, onAction)
LoadingView(modifier, text)
ErrorBanner(message, modifier, actionLabel, onAction)
InfoBanner(message, modifier, actionLabel, onAction)
ConfirmDialog(title, message, onConfirm, onDismiss, confirmText, dismissText, destructive)
PrimaryButton(text, onClick, modifier, enabled, loading, icon)
SecondaryButton(text, onClick, modifier, enabled, icon)
SettingSwitchRow(title, checked, onCheckedChange, modifier, description, enabled)
SettingValueRow(label, value, modifier, onClick)
TagPill(text, modifier, color)
TextAction(text, onClick, modifier, color, enabled)
val PageHorizontalPadding: Dp
val LocalStatusColors.current: StatusColors   // success / warning / danger / info / muted
```

图标：`compose-material-icons-extended` 已提供，直接 `Icons.Outlined.Xxx`。

## 5. 模块内推荐结构

```
feature/xxx/
├─ XxxRoute.kt          # 对外唯一入口：@Composable fun XxxRoute(...)
├─ XxxViewModel.kt      # UiState + 动作（可选，但推荐）
├─ XxxScreen.kt         # 纯 UI
├─ data/                # 仅该功能使用的解析器/网络客户端（不得依赖其它 feature）
└─ src/test/            # JVM 单元测试（纯逻辑，不依赖 Android）
```

## 6. 验收标准

1. `.\gradlew.bat :feature:<name>:assembleDebug` 通过（Lead 会跑整包）。
2. 页面可用：加载态、空态、错误态齐全；操作有反馈；深色模式可读。
3. 数据持久化：重启应用后数据仍在（由 Repository 保证，需实际调用而非本地变量）。
4. 使用统计：进入该功能页会 `track` 对应 `FeatureKey`。
5. 无硬编码 API 地址/密钥/魔法值；无未处理异常；无 TODO 占位。
6. 纯逻辑（解析、排序、倒计时计算等）有 JVM 单元测试，`.\gradlew.bat :feature:<name>:testDebugUnitTest` 通过。
