package com.lightdesk.feature.todo

import com.lightdesk.core.model.Todo
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.UUID

/** 标题长度上限，与编辑弹窗的输入校验保持一致。 */
const val TODO_TITLE_MAX_LENGTH: Int = 80

/** 新增待办时默认的截止时刻（仅当用户选择了日期但未调整时间时使用）。 */
const val DEFAULT_DEADLINE_HOUR: Int = 18

/** 待办紧急度：决定倒计时文案的颜色与标签。 */
enum class TodoUrgency {
    DONE,
    OVERDUE,
    WARNING,
    NORMAL,
    NO_DEADLINE,
}

/**
 * 判断紧急度：
 * - 已完成 -> [TodoUrgency.DONE]
 * - 无截止时间 -> [TodoUrgency.NO_DEADLINE]
 * - 已过截止时间 -> [TodoUrgency.OVERDUE]
 * - 剩余时间不超过设置阈值（分钟） -> [TodoUrgency.WARNING]
 * - 其余 -> [TodoUrgency.NORMAL]
 */
fun urgencyOf(todo: Todo, now: Long, warningMinutes: Int): TodoUrgency {
    if (todo.done) return TodoUrgency.DONE
    val deadline = todo.deadline ?: return TodoUrgency.NO_DEADLINE
    val remaining = deadline - now
    val warningMillis = warningMinutes.coerceAtLeast(0) * 60_000L
    return when {
        remaining < 0L -> TodoUrgency.OVERDUE
        remaining <= warningMillis -> TodoUrgency.WARNING
        else -> TodoUrgency.NORMAL
    }
}

/**
 * 排序规则：
 * 1. 未完成在前、已完成在后；
 * 2. 未完成按截止时间升序，无截止时间的排在有截止时间之后；
 * 3. 已完成按完成时间倒序（最近完成的靠前），id 兜底保证稳定。
 */
fun sortTodos(todos: List<Todo>): List<Todo> = todos.sortedWith(
    compareBy<Todo> { if (it.done) 1 else 0 }
        .thenBy { if (it.done) 0L else it.deadline ?: Long.MAX_VALUE }
        .thenByDescending { if (it.done) it.completedAt ?: Long.MIN_VALUE else Long.MIN_VALUE }
        .thenBy { it.id },
)

/** 截止时间所在日期（epochDay，按给定时区计算）。 */
fun deadlineDateEpochDay(deadline: Long, zoneId: ZoneId = ZoneId.systemDefault()): Long =
    Instant.ofEpochMilli(deadline).atZone(zoneId).toLocalDate().toEpochDay()

/** 截止时间的小时（按给定时区计算）。 */
fun deadlineHour(deadline: Long, zoneId: ZoneId = ZoneId.systemDefault()): Int =
    Instant.ofEpochMilli(deadline).atZone(zoneId).toLocalTime().hour

/** 截止时间的分钟（按给定时区计算）。 */
fun deadlineMinute(deadline: Long, zoneId: ZoneId = ZoneId.systemDefault()): Int =
    Instant.ofEpochMilli(deadline).atZone(zoneId).toLocalTime().minute

/** 日期（epochDay）+ 时分 -> 时间戳；用于把 DatePicker / TimePicker 的结果组合成截止时间。 */
fun combineDateAndTime(
    dateEpochDay: Long,
    hour: Int,
    minute: Int,
    zoneId: ZoneId = ZoneId.systemDefault(),
): Long = LocalDate.ofEpochDay(dateEpochDay)
    .atTime(hour.coerceIn(0, 23), minute.coerceIn(0, 59))
    .atZone(zoneId)
    .toInstant()
    .toEpochMilli()

/** 某个时间戳所在日期（epochDay，按给定时区计算）。 */
fun todayEpochDay(now: Long, zoneId: ZoneId = ZoneId.systemDefault()): Long =
    Instant.ofEpochMilli(now).atZone(zoneId).toLocalDate().toEpochDay()

private val dateLabelFormatter = DateTimeFormatter.ofPattern("M月d日")

/** 编辑器里的日期展示文案，如 "10月19日"。 */
fun formatDateLabel(dateEpochDay: Long): String =
    dateLabelFormatter.format(LocalDate.ofEpochDay(dateEpochDay))

/** 标题校验；返回 null 表示通过，否则返回可直接展示的错误文案。 */
fun validateTodoTitle(title: String): String? {
    val trimmed = title.trim()
    return when {
        trimmed.isEmpty() -> "标题不能为空"
        trimmed.length > TODO_TITLE_MAX_LENGTH -> "标题不能超过 $TODO_TITLE_MAX_LENGTH 个字符"
        else -> null
    }
}

/** 从已有待办构造编辑表单状态；新增时传 null。 */
fun todoEditorState(todo: Todo?, zoneId: ZoneId = ZoneId.systemDefault()): TodoEditorState {
    val deadline = todo?.deadline
    return TodoEditorState(
        editingId = todo?.id,
        title = todo?.title.orEmpty(),
        note = todo?.note.orEmpty(),
        dateEpochDay = deadline?.let { deadlineDateEpochDay(it, zoneId) },
        hour = deadline?.let { deadlineHour(it, zoneId) } ?: DEFAULT_DEADLINE_HOUR,
        minute = deadline?.let { deadlineMinute(it, zoneId) } ?: 0,
    )
}

/**
 * 根据编辑框内容构建实体：新增时生成 id 与创建时间，编辑时保留原 id / 创建时间 / 完成状态等字段。
 */
fun buildTodo(
    existing: Todo?,
    editingId: String?,
    title: String,
    note: String,
    deadline: Long?,
    now: Long,
    idGenerator: () -> String = { UUID.randomUUID().toString() },
): Todo {
    val id = editingId ?: existing?.id ?: idGenerator()
    return Todo(
        id = id,
        title = title.trim(),
        note = note.trimEnd(),
        deadline = deadline,
        done = existing?.done ?: false,
        completedAt = existing?.completedAt,
        remindBeforeMinutes = existing?.remindBeforeMinutes,
        createdAt = existing?.createdAt ?: now,
    )
}
