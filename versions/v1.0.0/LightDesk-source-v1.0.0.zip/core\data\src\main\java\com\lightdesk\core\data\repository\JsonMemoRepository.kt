package com.lightdesk.core.data.repository

import com.lightdesk.core.common.AppResult
import com.lightdesk.core.common.map
import com.lightdesk.core.data.store.JsonFileStore
import com.lightdesk.core.data.store.MemoStore
import com.lightdesk.core.model.Memo
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class JsonMemoRepository(
    private val store: JsonFileStore<MemoStore>,
) : MemoRepository {

    private val state = MutableStateFlow<List<Memo>>(emptyList())
    private val loadMutex = Mutex()
    private val writeMutex = Mutex()

    @Volatile
    private var loaded = false

    override fun observeMemos(): Flow<List<Memo>> = state.onStart { ensureLoaded() }

    override suspend fun upsert(memo: Memo): AppResult<Unit> = writeMutex.withLock {
        ensureLoaded()
        val items = state.value.toMutableList()
        val index = items.indexOfFirst { it.id == memo.id }
        if (index >= 0) items[index] = memo else items.add(memo)
        persist(items.toList())
    }

    override suspend fun delete(id: String): AppResult<Unit> = writeMutex.withLock {
        ensureLoaded()
        val items = state.value.filterNot { it.id == id }
        persist(items)
    }

    override suspend fun get(id: String): Memo? {
        ensureLoaded()
        return state.value.firstOrNull { it.id == id }
    }

    private suspend fun persist(items: List<Memo>): AppResult<Unit> =
        store.write(MemoStore(items = items)).map { state.value = items }

    private suspend fun ensureLoaded() {
        if (loaded) return
        loadMutex.withLock {
            if (!loaded) {
                state.value = store.read().items
                loaded = true
            }
        }
    }
}
