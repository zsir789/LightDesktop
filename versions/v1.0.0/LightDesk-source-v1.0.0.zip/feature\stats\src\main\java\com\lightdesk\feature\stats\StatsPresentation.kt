package com.lightdesk.feature.stats

import com.lightdesk.core.common.TimeFormat
import com.lightdesk.core.model.FeatureKey
import com.lightdesk.core.model.UsageStats
import kotlin.math.roundToInt

/**
 * 单个功能在统计页中的展示数据。
 *
 * 纯数据对象，不依赖 Android / Compose，便于直接写 JVM 单元测试。
 */
data class FeatureUsageRow(
    val feature: FeatureKey,
    val count: Long,
    /** 最近使用时间文案；从未使用时为 [StatsPresentation.NO_RECORD_TEXT]。 */
    val lastUsedText: String,
    /** 相对使用次数最高功能的进度（0f..1f），用于进度条。 */
    val relativeProgress: Float,
    /** 占总使用次数的百分比（0..100）。 */
    val percentOfTotal: Int,
)

/**
 * 统计页展示逻辑：把 [UsageStats] 转换为可直接渲染的行数据。
 *
 * 页面只负责渲染，所有计算集中在这里，保证可测试、可复用。
 */
object StatsPresentation {

    const val NO_RECORD_TEXT = "暂无记录"

    /** 展示顺序：与底部导航顺序保持一致，最后是悬浮球。 */
    val displayOrder: List<FeatureKey> = listOf(
        FeatureKey.MEMO,
        FeatureKey.TIMETABLE,
        FeatureKey.WEATHER,
        FeatureKey.TODO,
        FeatureKey.FLOATING_BALL,
    )

    /** 功能中文名。 */
    fun featureName(feature: FeatureKey): String = when (feature) {
        FeatureKey.MEMO -> "备忘录"
        FeatureKey.TIMETABLE -> "课表"
        FeatureKey.WEATHER -> "天气"
        FeatureKey.FLOATING_BALL -> "悬浮球"
        FeatureKey.TODO -> "待办"
    }

    /** 最近使用时间文案；0 或异常时间戳都安全降级为“暂无记录”。 */
    fun lastUsedText(lastUsedAt: Long): String {
        if (lastUsedAt <= 0L) return NO_RECORD_TEXT
        return try {
            TimeFormat.timestampToDateTimeText(lastUsedAt)
        } catch (throwable: Throwable) {
            // 理论上时间戳已由仓储保证合法，这里仅做展示层兜底，避免格式化异常导致页面崩溃
            NO_RECORD_TEXT
        }
    }

    /** 进度条比例：以使用次数最多的功能为 100%。 */
    fun relativeProgress(count: Long, maxCount: Long): Float {
        if (count <= 0L || maxCount <= 0L) return 0f
        return (count.toDouble() / maxCount.toDouble()).coerceIn(0.0, 1.0).toFloat()
    }

    /** 占总使用次数的百分比（四舍五入）。 */
    fun percentOfTotal(count: Long, totalCount: Long): Int {
        if (count <= 0L || totalCount <= 0L) return 0
        return ((count.toDouble() * 100.0) / totalCount.toDouble())
            .roundToInt()
            .coerceIn(0, 100)
    }

    /** 是否已经产生过任意使用记录（用于空状态判断）。 */
    fun hasAnyUsage(stats: UsageStats): Boolean = stats.items.any { it.count > 0L }

    /** 总使用次数（负数脏数据按 0 处理，保证展示不出现 "-1 次"）。 */
    fun totalCount(stats: UsageStats): Long = stats.totalCount().coerceAtLeast(0L)

    /** 生成统计行（顺序固定，未记录的功能也返回 0 次行）。 */
    fun buildRows(stats: UsageStats): List<FeatureUsageRow> {
        val total = totalCount(stats)
        val maxCount = displayOrder.maxOfOrNull { stats.countOf(it) } ?: 0L
        return displayOrder.map { feature ->
            val count = stats.countOf(feature).coerceAtLeast(0L)
            FeatureUsageRow(
                feature = feature,
                count = count,
                lastUsedText = lastUsedText(stats.lastUsedAt(feature)),
                relativeProgress = relativeProgress(count, maxCount),
                percentOfTotal = percentOfTotal(count, total),
            )
        }
    }
}
