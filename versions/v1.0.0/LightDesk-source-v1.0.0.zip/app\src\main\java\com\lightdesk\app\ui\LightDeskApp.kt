package com.lightdesk.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Checklist
import androidx.compose.material.icons.outlined.EditNote
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.lightdesk.app.di.AppContainer
import com.lightdesk.app.ui.settings.SettingsScreen
import com.lightdesk.feature.memo.MemoRoute
import com.lightdesk.feature.stats.StatsRoute
import com.lightdesk.feature.timetable.TimetableRoute
import com.lightdesk.feature.todo.TodoRoute
import com.lightdesk.feature.weather.WeatherRoute

/** 一级页面（底部导航项）。新增模块时在此追加即可。 */
enum class TopLevelDestination(
    val route: String,
    val label: String,
    val icon: ImageVector,
) {
    MEMO("memo", "备忘录", Icons.Outlined.EditNote),
    TIMETABLE("timetable", "课表", Icons.Outlined.CalendarMonth),
    WEATHER("weather", "天气", Icons.Outlined.WbSunny),
    TODO("todo", "待办", Icons.Outlined.Checklist),
    STATS("stats", "统计", Icons.Outlined.BarChart),
}

const val SETTINGS_ROUTE = "settings"

/**
 * 应用主界面：Scaffold + 底部导航 + NavHost。
 * 各功能页只接收仓储接口与工具，不感知彼此，便于独立开发与替换。
 */
@Composable
fun LightDeskApp(container: AppContainer) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (currentRoute != SETTINGS_ROUTE) {
                BottomBar(
                    currentRoute = currentRoute,
                    onSelect = { destination ->
                        navController.navigate(destination.route) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                )
            }
        },
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = TopLevelDestination.MEMO.route,
            modifier = Modifier.padding(innerPadding),
        ) {
            composable(TopLevelDestination.MEMO.route) {
                MemoRoute(
                    repository = container.memoRepository,
                    usageTracker = container.usageTracker,
                    timeProvider = container.timeProvider,
                )
            }
            composable(TopLevelDestination.TIMETABLE.route) {
                TimetableRoute(
                    repository = container.courseRepository,
                    usageTracker = container.usageTracker,
                    timeProvider = container.timeProvider,
                )
            }
            composable(TopLevelDestination.WEATHER.route) {
                WeatherRoute(
                    cacheRepository = container.weatherRepository,
                    settingsRepository = container.settingsRepository,
                    usageTracker = container.usageTracker,
                )
            }
            composable(TopLevelDestination.TODO.route) {
                TodoRoute(
                    repository = container.todoRepository,
                    settingsRepository = container.settingsRepository,
                    usageTracker = container.usageTracker,
                    timeProvider = container.timeProvider,
                )
            }
            composable(TopLevelDestination.STATS.route) {
                StatsRoute(
                    usageRepository = container.usageRepository,
                    onOpenSettings = { navController.navigate(SETTINGS_ROUTE) },
                )
            }
            composable(SETTINGS_ROUTE) {
                SettingsScreen(
                    container = container,
                    onBack = { navController.popBackStack() },
                )
            }
        }
    }
}

@Composable
private fun BottomBar(
    currentRoute: String?,
    onSelect: (TopLevelDestination) -> Unit,
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 12.dp,
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TopLevelDestination.entries.forEach { destination ->
                BottomBarItem(
                    destination = destination,
                    selected = currentRoute == destination.route,
                    onClick = { onSelect(destination) },
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }
}

@Composable
private fun BottomBarItem(
    destination: TopLevelDestination,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val activeColor = MaterialTheme.colorScheme.primary
    val inactiveColor = MaterialTheme.colorScheme.onSurfaceVariant
    val tint = if (selected) activeColor else inactiveColor

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(if (selected) activeColor.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface)
                .padding(horizontal = 14.dp, vertical = 4.dp),
        ) {
            Icon(
                imageVector = destination.icon,
                contentDescription = destination.label,
                tint = tint,
                modifier = Modifier.size(22.dp),
            )
        }
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = destination.label,
            style = MaterialTheme.typography.labelSmall,
            color = tint,
        )
    }
}
