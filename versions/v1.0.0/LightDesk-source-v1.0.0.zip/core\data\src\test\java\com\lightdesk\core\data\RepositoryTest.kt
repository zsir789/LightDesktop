package com.lightdesk.core.data

import com.lightdesk.core.common.NoOpLogger
import com.lightdesk.core.common.isSuccess
import com.lightdesk.core.data.repository.JsonMemoRepository
import com.lightdesk.core.data.repository.JsonSettingsRepository
import com.lightdesk.core.data.repository.JsonUsageRepository
import com.lightdesk.core.data.store.JsonFileStore
import com.lightdesk.core.data.store.MemoStore
import com.lightdesk.core.data.store.SettingsStore
import com.lightdesk.core.data.store.UsageStatsStore
import com.lightdesk.core.model.FeatureKey
import com.lightdesk.core.model.Memo
import com.lightdesk.core.model.ThemeMode
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.File
import java.nio.file.Files

@OptIn(ExperimentalCoroutinesApi::class)
class RepositoryTest {

    private lateinit var dir: File
    private val dispatcher = UnconfinedTestDispatcher()

    @Before
    fun setUp() {
        dir = Files.createTempDirectory("lightdesk-repo-test").toFile()
    }

    @After
    fun tearDown() {
        dir.deleteRecursively()
    }

    @Test
    fun `备忘录仓储写入后可跨实例读取且支持删除`() = runTest {
        val file = File(dir, "memos.json")
        fun repo() = JsonMemoRepository(
            JsonFileStore(file, MemoStore.serializer(), { MemoStore() }, NoOpLogger, dispatcher),
        )

        val first = repo()
        val memo = Memo(id = "m1", title = "周报", content = "周五前", createdAt = 1, updatedAt = 1)
        assertTrue(first.upsert(memo).isSuccess)
        assertTrue(first.upsert(memo.copy(title = "周报（已更新）", updatedAt = 2)).isSuccess)

        val second = repo()
        val loaded = second.observeMemos().first()
        assertEquals(1, loaded.size)
        assertEquals("周报（已更新）", loaded.first().title)

        assertTrue(second.delete("m1").isSuccess)
        assertTrue(repo().observeMemos().first().isEmpty())
    }

    @Test
    fun `使用统计按功能累加并支持重置`() = runTest {
        val file = File(dir, "usage_stats.json")
        fun repo() = JsonUsageRepository(
            JsonFileStore(file, UsageStatsStore.serializer(), { UsageStatsStore() }, NoOpLogger, dispatcher),
        )

        val repository = repo()
        assertTrue(repository.record(FeatureKey.MEMO, 1000L).isSuccess)
        assertTrue(repository.record(FeatureKey.MEMO, 2000L).isSuccess)
        assertTrue(repository.record(FeatureKey.WEATHER, 3000L).isSuccess)

        val stats = repository.observeStats().first()
        assertEquals(2L, stats.countOf(FeatureKey.MEMO))
        assertEquals(2000L, stats.lastUsedAt(FeatureKey.MEMO))
        assertEquals(1L, stats.countOf(FeatureKey.WEATHER))
        assertEquals(3L, stats.totalCount())

        assertTrue(repository.reset().isSuccess)
        assertEquals(0L, repository.observeStats().first().totalCount())
    }

    @Test
    fun `设置变更持久化到磁盘`() = runTest {
        val file = File(dir, "settings.json")
        fun repo() = JsonSettingsRepository(
            JsonFileStore(file, SettingsStore.serializer(), { SettingsStore() }, NoOpLogger, dispatcher),
        )

        val repository = repo()
        assertTrue(
            repository.update {
                it.copy(themeMode = ThemeMode.DARK, countdownWarningMinutes = 60)
            }.isSuccess,
        )

        val reloaded = repo().current()
        assertEquals(ThemeMode.DARK, reloaded.themeMode)
        assertEquals(60, reloaded.countdownWarningMinutes)
        assertEquals("北京", reloaded.weatherCity)
    }
}
