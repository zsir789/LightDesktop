package com.lightdesk.core.data.store

import com.lightdesk.core.model.AppSettings
import com.lightdesk.core.model.CourseTable
import com.lightdesk.core.model.Memo
import com.lightdesk.core.model.Todo
import com.lightdesk.core.model.UsageStats
import com.lightdesk.core.model.WeatherSnapshot
import kotlinx.serialization.Serializable

/**
 * 持久化包装类型。
 *
 * 包一层对象而不是直接存数组/可空对象，可以在未来平滑加入 schemaVersion、
 * 迁移逻辑等字段，而不破坏已安装用户的本地数据。
 */

@Serializable
data class MemoStore(
    val schemaVersion: Int = SCHEMA_VERSION,
    val items: List<Memo> = emptyList(),
)

@Serializable
data class TodoStore(
    val schemaVersion: Int = SCHEMA_VERSION,
    val items: List<Todo> = emptyList(),
)

@Serializable
data class CourseTableStore(
    val schemaVersion: Int = SCHEMA_VERSION,
    val table: CourseTable? = null,
)

@Serializable
data class UsageStatsStore(
    val schemaVersion: Int = SCHEMA_VERSION,
    val stats: UsageStats = UsageStats(),
)

@Serializable
data class SettingsStore(
    val schemaVersion: Int = SCHEMA_VERSION,
    val settings: AppSettings = AppSettings(),
)

@Serializable
data class WeatherCacheStore(
    val schemaVersion: Int = SCHEMA_VERSION,
    val snapshot: WeatherSnapshot? = null,
)

const val SCHEMA_VERSION: Int = 1
