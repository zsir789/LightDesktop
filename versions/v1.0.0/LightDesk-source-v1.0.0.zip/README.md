# 轻桌面 LightDesk

> 一款模块化、纯本地的移动端桌面小工具（Android · Kotlin · Jetpack Compose）。
> 备忘录 · 课表 · 天气 · 待办倒计时 · 桌面悬浮球 · 使用统计，全部数据保存在本机。

---

## 一、项目简介

轻桌面把日常高频使用的小功能收进一个 App：随手记备忘录、导入 WakeUp 课表、查看天气、给待办设倒计时，
再打开一个可拖动的桌面悬浮球随时唤起主程序。所有数据本地持久化，不联网也能查看备忘录、课表、待办与天气缓存。

工程按「核心层 + 功能层 + 组装层」拆分，功能模块之间零耦合，新增功能只需加一个 `:feature:xxx` 模块并在
`:app` 注册，已为后续迭代预留扩展点（见文末）。

---

## 二、功能清单

| 模块 | 功能 | 说明 |
| --- | --- | --- |
| 备忘录 | 增删改查、完成标记、置顶、搜索、筛选 | 数据保存在 `memos.json` |
| 课表 | 导入 WakeUp 导出的 `.ics` 文件、周视图展示、课程详情、清空重导 | 支持 TZID/UTC/浮动时间、RRULE、EXDATE |
| 天气 | Open-Meteo 联网获取实时与 7 天预报 | 断网/超时/解析失败自动降级为本地缓存并标注更新时间 |
| 待办倒计时 | 添加待办、设置截止时间、实时倒计时、临近截止高亮 | 阈值可在设置中调整（默认 24 小时） |
| 桌面悬浮球 | 可拖动的系统悬浮按钮，点击唤起主程序，支持开关与开机恢复 | 需要“显示在其他应用上层”权限 |
| 使用统计 | 统计备忘录/课表/天气/悬浮球/待办的使用次数与最近使用时间 | 本地保存，可一键重置 |
| 设置 | 悬浮球开关、天气城市、倒计时提醒阈值、主题模式 | 深浅色主题跟随/手动切换 |

---

## 三、安装包

| 产物 | 路径 | 大小 |
| --- | --- | --- |
| Release APK（推荐安装） | `release/LightDesk-v1.0.0.apk` | 约 11.2 MB |
| Debug APK（调试用） | `app/build/outputs/apk/debug/app-debug.apk` | 约 17 MB |
| 源码包 | `release/LightDesk-source-v1.0.0.zip` | 约 0.2 MB |
| 校验值 | `release/SHA256SUMS.txt` | — |

APK SHA-256：

```text
69798c11178176c87e008d95f107b5612447356805cee90358da207047abe979  LightDesk-v1.0.0.apk
```

安装步骤：

1. 将 `release/LightDesk-v1.0.0.apk` 传到手机（数据线 / 网盘均可）；
2. 点击安装，若系统提示“未知来源应用”，在弹窗中允许当前文件管理器安装；
3. 首次打开按引导授予悬浮窗权限（仅在使用悬浮球时需要）。

**系统要求**：Android 8.0（API 26）及以上。
**签名**：仓库内附自签名证书 `keystore/lightdesk-release.jks`（仅供本项目使用，口令见 `keystore.properties`）。
**架构**：通用 APK，支持 arm64-v8a / armeabi-v7a / x86 / x86_64。

---

## 四、权限说明

| 权限 | 用途 |
| --- | --- |
| `INTERNET` / `ACCESS_NETWORK_STATE` | 获取天气数据、判断网络是否可用 |
| `SYSTEM_ALERT_WINDOW` | 悬浮球显示在其它应用上层（需用户手动授权，可随时关闭） |
| `FOREGROUND_SERVICE` / `FOREGROUND_SERVICE_SPECIAL_USE` | 悬浮球以前台服务运行，避免被系统回收 |
| `POST_NOTIFICATIONS` | 显示悬浮球前台通知（Android 13+ 可拒绝，不影响悬浮球使用） |
| `RECEIVE_BOOT_COMPLETED` | 开机后按用户设置自动恢复悬浮球 |

> 应用不申请读取通讯录、位置、存储等敏感权限；天气定位使用设置中的城市（内置常用城市坐标，无需定位权限）。

---

## 五、使用说明

### 备忘录
- 右下角 `+` 新建；点击卡片编辑，左滑/卡片菜单删除；
- 卡片左侧圆点或勾选框可标记完成，长按/置顶按钮可置顶；
- 顶部支持关键字搜索与“全部 / 未完成 / 已完成”筛选。

### 课表
1. 打开 WakeUp，进入「课表 → 导出/分享 → 导出为 ics 日历文件」；
2. 回到轻桌面「课表」页，点击「导入课表」，选择刚导出的 `.ics` 文件；
3. 解析成功后按周视图展示课程（时间轴 + 周一至周日），今日列高亮；点击课程查看教师/地点/时间；
4. 可随时重新导入或清空课表。

> 没有 WakeUp 导出的文件时，可先用仓库内示例 `samples/wakeup-course-sample.ics` 验证导入流程
> （示例包含 TZID、UTC、浮动时间、RRULE、EXDATE 等常见写法）。

### 天气
- 自动读取设置中的城市并拉取实时天气与未来 7 天预报；
- 无网络时展示最近一次缓存，并提示缓存更新时间；点击「重试」可重新拉取；
- 城市在「设置 → 天气城市」中切换（内置 10 个常用城市）。

### 待办倒计时
- 点击 `+` 添加待办：填写标题、备注，选择截止时间（支持“今天 18:00 / 明天 09:00 / 自定义 / 无截止时间”）；
- 列表中的待办按截止时间实时倒计时，进入设置阈值后变为警告色，超时后显示“已超时”；
- 完成后自动沉底，可再次点击恢复。

### 悬浮球
1. 进入「设置 → 桌面悬浮球」，打开开关；
2. 首次开启会跳转系统“显示在其他应用上层”权限页，授权后返回即可看到悬浮球；
3. 悬浮球可拖动，松手自动吸附到屏幕左右边缘；轻点即唤起主程序；
4. 关闭开关会立即停止悬浮球；开启状态下重启手机后会自动恢复。

### 使用统计
- 每次进入备忘录、课表、天气、待办，或通过悬浮球唤起应用，都会累计一次使用次数；
- 「统计」页展示总量、各功能次数与最近使用时间，可一键重置。

---

## 六、技术栈

| 类别 | 选型 |
| --- | --- |
| 语言 | Kotlin 2.0.21 |
| UI | Jetpack Compose + Material 3 |
| 架构 | 单 Activity + Navigation Compose，MVVM，仓储模式 |
| 异步 | Kotlin Coroutines + Flow/StateFlow |
| 持久化 | 自研 `JsonFileStore`（原子写入、损坏备份回退），kotlinx.serialization |
| 网络 | OkHttp + kotlinx.serialization（Open-Meteo，无需 API Key） |
| 构建 | Gradle 8.11.1 + AGP 8.7.2，多模块 |
| 最低版本 | Android 8.0（API 26），targetSdk 35 |

---

## 七、工程结构

```
dsh_desktop_master/
├─ app/                         # 壳工程：MainActivity、导航、设置页、开机自启、依赖组装
├─ core/
│  ├─ common/                   # AppResult/错误码/日志/时间格式化/调度器/ViewModel 工厂
│  ├─ model/                    # 数据模型（Memo/Todo/Course/Weather/UsageStats/AppSettings）
│  ├─ data/                     # JSON 持久化、仓储接口与实现、UsageTracker
│  └─ designsystem/             # 主题（色板/字体/圆角）+ 通用组件
├─ feature/
│  ├─ memo/                     # 备忘录
│  ├─ timetable/                # 课表（ICS 解析 + 周视图）
│  ├─ weather/                  # 天气（Open-Meteo + 离线降级）
│  ├─ todo/                     # 待办倒计时
│  ├─ stats/                    # 使用统计
│  └─ floatingball/             # 悬浮球（前台服务 + 系统悬浮窗）
├─ docs/                        # 架构说明与开发契约
├─ keystore/                    # 发布签名（仅本项目使用）
├─ release/                     # 交付产物（APK / 校验值）
├─ gradle/libs.versions.toml    # 版本目录（统一依赖版本）
└─ README.md
```

### 架构与数据流

```
Compose UI (feature)
      │ 只依赖接口
      ▼
ViewModel / UiState
      ▼
Repository 接口（core:data）
      ▼
JsonFileStore（原子写 + 异常兜底）
      ▼
filesDir/lightdesk/*.json
```

- 功能模块之间互不依赖；共享能力下沉到 `core`，由 `:app` 的 `AppContainer` 统一组装注入；
- 写入失败返回 `AppResult.Failure`，UI 提示，不会崩溃；读取损坏文件会自动备份为 `.corrupt` 并回退默认值；
- 悬浮球服务不依赖业务数据层，点击通过 Intent 携带来源标记交给应用层记录统计，实现解耦。

详见 [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md)。

---

## 八、本地数据

所有数据位于应用私有目录下，卸载应用即删除：

```
/data/data/com.lightdesk.app/files/lightdesk/
├─ settings.json       # 悬浮球开关、天气城市、提醒阈值、主题
├─ memos.json          # 备忘录
├─ todos.json          # 待办
├─ courses.json        # 课表
├─ usage_stats.json    # 使用统计
└─ weather_cache.json  # 天气缓存（离线降级）
```

每个文件带 `schemaVersion` 字段，为后续版本数据迁移预留。

---

## 九、构建与测试

### 环境

- JDK 17+（本项目使用 JDK 21）
- Android SDK Platform 35 + Build-Tools 35.0.0
- Gradle Wrapper（已随仓库提供，无需单独安装）

`local.properties` 中配置 SDK 路径（已被 `.gitignore` 忽略，按本机实际路径修改）：

```properties
sdk.dir=D:/path/to/android-sdk
```

### 构建

```powershell
$env:JAVA_HOME='D:\path\to\jdk21'
$env:ANDROID_HOME='D:\path\to\android-sdk'
$env:Path="$env:JAVA_HOME\bin;$env:Path"

# 调试包
.\gradlew.bat :app:assembleDebug

# 发布包（使用 keystore.properties 中的签名）
.\gradlew.bat :app:assembleRelease
```

依赖仓库已在 `settings.gradle.kts` 中配置阿里云镜像（Google / Central / Gradle Plugin），
Gradle 发行版使用腾讯云镜像；如需官方源可自行替换。

### 测试

当前工程共 **98 个 JVM 单元测试，全部通过（0 失败 0 错误）**，覆盖：

- 通用层：时间格式化 / 倒计时文案、JSON 存储的读写与损坏回退；
- 仓储层：备忘录、待办、设置、使用统计的持久化与跨实例读取；
- 课表：折叠行、BOM/CRLF、TZID/UTC/浮动时间/全天事件、RRULE（BYDAY/INTERVAL/UNTIL/COUNT）、EXDATE、多事件合并、坏数据；
- 天气：WMO 天气码映射、请求 URL 构建、DTO → 模型映射、缓存降级决策；
- 功能逻辑：备忘录搜索/筛选/排序、待办紧急度与排序、统计展示计算、悬浮球边缘吸附几何。

```powershell
# 核心层
.\gradlew.bat :core:common:testDebugUnitTest :core:data:testDebugUnitTest

# 功能模块纯逻辑单测（ICS 解析、天气映射、排序/倒计时等）
.\gradlew.bat :feature:timetable:testDebugUnitTest :feature:weather:testDebugUnitTest `
               :feature:memo:testDebugUnitTest :feature:todo:testDebugUnitTest `
               :feature:stats:testDebugUnitTest :feature:floatingball:testDebugUnitTest
```

---

## 十、扩展点（预留迭代接口）

| 扩展方向 | 接入方式 |
| --- | --- |
| 新增功能模块 | 新建 `:feature:xxx`，在 `:app` 的 `TopLevelDestination` / `NavHost` 注册；`FeatureKey` 追加枚举值即可自动出现在统计页 |
| 更换存储引擎 | 实现 `core:data` 中对应 Repository 接口（如 Room 版），在 `AppContainer` 替换实现，功能模块零改动 |
| 更换天气服务 | 实现 `feature:weather` 的 `WeatherDataSource` 接口并替换注入 |
| 更多课表来源 | 新增 `TimetableImporter` 实现（CSV、教务系统等），UI 选择导入方式 |
| 系统通知提醒 | `Todo.remindBeforeMinutes` 字段已预留，接入 WorkManager/AlarmManager 即可 |
| 换肤 / 多语言 | 主题集中在 `core:designsystem`；文案可迁移 `strings.xml` |
| 云端同步 | 在 Repository 之上叠加同步层，或实现远程数据源 |
| 悬浮球自定义 | `AppSettings.floatingBallSizeDp` 已预留尺寸配置，可继续扩展位置记忆、图标样式 |

---

## 十一、已知限制

- 悬浮球依赖系统“显示在其他应用上层”权限，部分厂商 ROM（MIUI/EMUI 等）还需在系统设置中允许“后台弹出界面 /
  自启动”，否则悬浮球可能在后台被清理；
- 天气数据来自 Open-Meteo（海外服务），弱网环境可能较慢，已做超时与缓存降级；
- 课表解析遵循标准 iCalendar 规范，若 WakeUp 导出使用了非标准字段，部分信息（如教师）可能为空；
- 安装包为自签名发布包，未上架应用商店；升级安装需使用同一签名（本仓库内 `keystore/`）。
