package com.lightdesk.feature.floatingball

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.lightdesk.core.common.AppLogger
import com.lightdesk.core.common.AppResult
import com.lightdesk.core.data.repository.SettingsRepository
import com.lightdesk.core.designsystem.component.InfoBanner
import com.lightdesk.core.designsystem.component.SectionCard
import com.lightdesk.core.designsystem.component.SettingSwitchRow
import com.lightdesk.core.designsystem.component.SettingValueRow
import com.lightdesk.core.designsystem.component.TagPill
import com.lightdesk.core.designsystem.theme.LocalStatusColors
import com.lightdesk.core.model.AppSettings
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

private const val TAG = "FloatingBallSettingsCard"

/**
 * 悬浮球设置卡片：开关、权限引导、运行状态。
 *
 * 一致性约定：
 * - 开关状态唯一来源是 [SettingsRepository]（持久化），不额外维护本地开关副本；
 * - 先写入设置成功、再改变服务状态；写入失败时回滚服务状态并提示，
 *   保证“设置值 = 实际运行状态”；
 * - 服务运行状态由 [FloatingBallService.isRunning] 驱动，页面只负责展示与触发。
 */
@Composable
fun FloatingBallSettingsCard(
    settingsRepository: SettingsRepository,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val statusColors = LocalStatusColors.current
    val lifecycleOwner = LocalLifecycleOwner.current

    // initialValue 用 null 区分“尚未读到真实设置”，避免用默认值误关正在运行的服务
    val settingsState by settingsRepository.observeSettings()
        .collectAsStateWithLifecycle<AppSettings?>(initialValue = null)
    val settings = settingsState ?: AppSettings()
    val running by FloatingBallService.isRunning.collectAsStateWithLifecycle()

    var permissionGranted by remember { mutableStateOf(FloatingBallController.canDrawOverlays(context)) }
    var pendingEnable by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var hint by remember { mutableStateOf<String?>(null) }

    /** 启动服务并持久化开关；先起服务再保存，保存失败则回滚（停止服务）。 */
    fun startFloatingBall() {
        if (busy) return
        val started = FloatingBallController.start(context, settings.floatingBallSizeDp)
        if (!started) {
            hint = "悬浮球启动失败，请检查悬浮窗权限或系统设置后重试"
            return
        }
        busy = true
        scope.launch {
            val error = persistFloatingBallEnabled(settingsRepository, enabled = true)
            busy = false
            if (error == null) {
                hint = null
            } else {
                FloatingBallController.stop(context)
                hint = "悬浮球开关保存失败：$error"
            }
        }
    }

    /** 关闭悬浮球：先持久化关闭，成功后再停止服务，保证重启后不会自动恢复。 */
    fun stopFloatingBall() {
        if (busy) return
        busy = true
        scope.launch {
            val error = persistFloatingBallEnabled(settingsRepository, enabled = false)
            busy = false
            if (error != null) {
                hint = "悬浮球开关保存失败：$error"
            } else {
                FloatingBallController.stop(context)
                pendingEnable = false
                hint = null
            }
        }
    }

    val notificationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted ->
        // 通知权限只影响前台通知是否可见，拒绝不影响悬浮球使用
        if (!granted) {
            hint = "未授予通知权限，前台通知可能不会显示，但不影响悬浮球使用"
        }
    }

    // 从系统权限页返回：刷新授权状态；若用户此前希望开启，则继续完成开启流程
    val overlayLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) {
        permissionGranted = FloatingBallController.canDrawOverlays(context)
        if (pendingEnable) {
            pendingEnable = false
            if (permissionGranted) {
                requestNotificationPermissionIfNeeded(context, notificationLauncher)
                startFloatingBall()
            } else {
                hint = "未授予“显示在其他应用上层”权限，无法显示悬浮球"
            }
        }
    }

    // 从系统设置页返回后实时刷新授权状态
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                permissionGranted = FloatingBallController.canDrawOverlays(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // 持久化开关与真实状态的自动修复：
    // 1) 开关为开且已授权但服务未运行（如进程被回收）→ 自动恢复服务；
    // 2) 权限被系统回收 → 关闭服务并把开关同步为关，避免“开关打开却没有悬浮球”。
    LaunchedEffect(settingsState, permissionGranted, pendingEnable, busy) {
        if (settingsState == null || pendingEnable || busy) return@LaunchedEffect
        if (!settings.floatingBallEnabled) {
            if (FloatingBallController.isRunning()) {
                FloatingBallController.stop(context)
            }
            return@LaunchedEffect
        }
        if (!permissionGranted) {
            FloatingBallController.stop(context)
            val error = persistFloatingBallEnabled(settingsRepository, enabled = false)
            hint = if (error == null) {
                "悬浮窗权限已失效，悬浮球已关闭；重新授权后可再次开启"
            } else {
                "悬浮窗权限已失效且开关保存失败：$error"
            }
            return@LaunchedEffect
        }
        if (!FloatingBallController.isRunning()) {
            FloatingBallController.start(context, settings.floatingBallSizeDp)
        }
    }

    /** 申请悬浮窗权限；记下“授权后自动开启”的意图。 */
    fun launchOverlayPermission() {
        pendingEnable = true
        runCatching {
            overlayLauncher.launch(FloatingBallController.overlayPermissionIntent(context))
        }.onFailure { throwable ->
            pendingEnable = false
            AppLogger.w(TAG, "打开悬浮窗权限设置页失败", throwable)
            hint = "无法打开悬浮窗权限设置页，请手动前往系统设置授权"
        }
    }

    /** 开关点击入口：关闭直接停；开启前先走权限流程。 */
    fun applyEnabled(enabled: Boolean) {
        if (busy) return
        if (!enabled) {
            stopFloatingBall()
            return
        }
        if (!FloatingBallController.canDrawOverlays(context)) {
            launchOverlayPermission()
            return
        }
        pendingEnable = false
        requestNotificationPermissionIfNeeded(context, notificationLauncher)
        startFloatingBall()
    }

    SectionCard(modifier = modifier) {
        SettingSwitchRow(
            title = "桌面悬浮球",
            checked = settings.floatingBallEnabled,
            onCheckedChange = ::applyEnabled,
            enabled = !busy,
            description = "在任意界面显示可拖动的圆形按钮，轻点即可唤起轻桌面",
        )

        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

        SettingValueRow(
            label = "悬浮窗权限",
            value = if (permissionGranted) "已授权" else "去授权",
            onClick = { if (!permissionGranted) launchOverlayPermission() },
        )

        if (settings.floatingBallEnabled && !running) {
            SettingValueRow(
                label = "运行状态",
                value = if (busy) "处理中…" else "未运行，点击重新启动",
                onClick = {
                    if (!busy) {
                        requestNotificationPermissionIfNeeded(context, notificationLauncher)
                        startFloatingBall()
                    }
                },
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            TagPill(
                text = when {
                    !settings.floatingBallEnabled -> "已关闭"
                    running -> "运行中"
                    else -> "未运行"
                },
                color = when {
                    !settings.floatingBallEnabled -> statusColors.muted
                    running -> statusColors.success
                    else -> statusColors.warning
                },
            )
            if (settings.floatingBallEnabled) {
                TagPill(text = "拖到屏幕边缘自动吸附", color = statusColors.info)
            }
        }

        hint?.let { message ->
            Spacer(modifier = Modifier.height(10.dp))
            InfoBanner(message = message)
        }
    }
}

/**
 * 持久化悬浮球开关。
 *
 * @return null 表示成功；否则返回可展示的错误文案。
 */
private suspend fun persistFloatingBallEnabled(
    repository: SettingsRepository,
    enabled: Boolean,
): String? {
    return try {
        when (val result = repository.update { it.copy(floatingBallEnabled = enabled) }) {
            is AppResult.Success -> null
            is AppResult.Failure -> result.error.message
        }
    } catch (cancellation: CancellationException) {
        throw cancellation
    } catch (throwable: Throwable) {
        AppLogger.e(TAG, "保存悬浮球开关失败", throwable)
        "本地设置读写失败，请稍后重试"
    }
}

private fun requestNotificationPermissionIfNeeded(
    context: Context,
    launcher: ActivityResultLauncher<String>,
) {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
    val granted = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.POST_NOTIFICATIONS,
    ) == PackageManager.PERMISSION_GRANTED
    if (!granted) {
        runCatching { launcher.launch(Manifest.permission.POST_NOTIFICATIONS) }
            .onFailure { AppLogger.w(TAG, "请求通知权限失败", it) }
    }
}
