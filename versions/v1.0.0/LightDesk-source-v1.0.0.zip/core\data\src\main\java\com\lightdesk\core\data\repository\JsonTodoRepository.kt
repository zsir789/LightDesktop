package com.lightdesk.core.data.repository

import com.lightdesk.core.common.AppResult
import com.lightdesk.core.common.map
import com.lightdesk.core.data.store.JsonFileStore
import com.lightdesk.core.data.store.TodoStore
import com.lightdesk.core.model.Todo
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class JsonTodoRepository(
    private val store: JsonFileStore<TodoStore>,
) : TodoRepository {

    private val state = MutableStateFlow<List<Todo>>(emptyList())
    private val loadMutex = Mutex()
    private val writeMutex = Mutex()

    @Volatile
    private var loaded = false

    override fun observeTodos(): Flow<List<Todo>> = state.onStart { ensureLoaded() }

    override suspend fun upsert(todo: Todo): AppResult<Unit> = writeMutex.withLock {
        ensureLoaded()
        val items = state.value.toMutableList()
        val index = items.indexOfFirst { it.id == todo.id }
        if (index >= 0) items[index] = todo else items.add(todo)
        persist(items.toList())
    }

    override suspend fun delete(id: String): AppResult<Unit> = writeMutex.withLock {
        ensureLoaded()
        persist(state.value.filterNot { it.id == id })
    }

    override suspend fun get(id: String): Todo? {
        ensureLoaded()
        return state.value.firstOrNull { it.id == id }
    }

    private suspend fun persist(items: List<Todo>): AppResult<Unit> =
        store.write(TodoStore(items = items)).map { state.value = items }

    private suspend fun ensureLoaded() {
        if (loaded) return
        loadMutex.withLock {
            if (!loaded) {
                state.value = store.read().items
                loaded = true
            }
        }
    }
}
