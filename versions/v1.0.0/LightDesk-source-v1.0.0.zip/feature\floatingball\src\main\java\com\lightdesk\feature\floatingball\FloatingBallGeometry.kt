package com.lightdesk.feature.floatingball

/**
 * 悬浮球窗口几何计算。
 *
 * 全部为纯函数（不依赖 Android Framework），便于 JVM 单元测试；
 * Service 只负责把计算结果应用到 WindowManager。
 */
object FloatingBallGeometry {

    /** 悬浮球直径（dp）允许范围，避免脏设置导致窗口不可见或过大。 */
    const val MIN_SIZE_DP = 40
    const val MAX_SIZE_DP = 80

    /** 把设置中的直径限制在合理范围。 */
    fun clampSizeDp(sizeDp: Int): Int = sizeDp.coerceIn(MIN_SIZE_DP, MAX_SIZE_DP)

    /** 某一轴可移动的最大坐标；屏幕比悬浮球还小时固定为 0。 */
    fun maxCoordinate(screenLength: Int, ballSize: Int): Int =
        (screenLength - ballSize).coerceAtLeast(0)

    /** 拖动时把 x 限制在屏幕内。 */
    fun clampX(x: Int, screenWidth: Int, ballSize: Int): Int =
        x.coerceIn(0, maxCoordinate(screenWidth, ballSize))

    /** 拖动时把 y 限制在屏幕内。 */
    fun clampY(y: Int, screenHeight: Int, ballSize: Int): Int =
        y.coerceIn(0, maxCoordinate(screenHeight, ballSize))

    /**
     * 松手后吸附到最近的左/右边缘的目标 x 坐标。
     *
     * @param currentX 当前窗口 x
     * @param margin 距离屏幕边缘的留白（px）；屏幕过窄时会自动收缩，避免两个目标点重叠
     */
    fun edgeSnapTargetX(
        currentX: Int,
        screenWidth: Int,
        ballSize: Int,
        margin: Int,
    ): Int {
        val max = maxCoordinate(screenWidth, ballSize)
        val safeMargin = margin.coerceIn(0, max / 2)
        val centerX = currentX + ballSize / 2
        val target = if (centerX < screenWidth / 2) {
            safeMargin
        } else {
            max - safeMargin
        }
        return target.coerceIn(0, max)
    }

    /** 初始位置：屏幕右侧、纵向偏下，和拖动逻辑使用同一套夹取规则。 */
    fun initialX(screenWidth: Int, ballSize: Int, margin: Int): Int =
        clampX(screenWidth - ballSize - margin, screenWidth, ballSize)

    /** 初始位置：屏幕高度的 55%。 */
    fun initialY(screenHeight: Int, ballSize: Int): Int =
        clampY((screenHeight * 0.55f).toInt(), screenHeight, ballSize)
}
