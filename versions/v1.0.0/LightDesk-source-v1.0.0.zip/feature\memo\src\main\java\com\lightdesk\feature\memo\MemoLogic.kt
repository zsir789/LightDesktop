package com.lightdesk.feature.memo

import com.lightdesk.core.model.Memo
import java.util.UUID

/** 备忘录列表筛选维度。 */
enum class MemoFilter(val label: String) {
    ALL("全部"),
    ACTIVE("未完成"),
    DONE("已完成"),
}

/** 标题长度上限，与编辑弹窗的输入校验保持一致。 */
const val MEMO_TITLE_MAX_LENGTH: Int = 60

/** 搜索匹配：标题或正文包含关键字（忽略大小写与首尾空白）。 */
fun matchesMemoQuery(memo: Memo, query: String): Boolean {
    val keyword = query.trim()
    if (keyword.isEmpty()) return true
    return memo.title.contains(keyword, ignoreCase = true) ||
        memo.content.contains(keyword, ignoreCase = true)
}

/** 按关键字与完成状态筛选，不改变顺序。 */
fun filterMemos(memos: List<Memo>, query: String, filter: MemoFilter): List<Memo> =
    memos.filter { memo ->
        matchesMemoQuery(memo, query) && when (filter) {
            MemoFilter.ALL -> true
            MemoFilter.ACTIVE -> !memo.done
            MemoFilter.DONE -> memo.done
        }
    }

/** 排序：置顶优先，其次按更新时间倒序；id 作为兜底保证顺序稳定。 */
fun sortMemos(memos: List<Memo>): List<Memo> = memos.sortedWith(
    compareByDescending<Memo> { it.pinned }
        .thenByDescending { it.updatedAt }
        .thenBy { it.id },
)

/** 列表最终展示顺序：先筛选再排序。 */
fun visibleMemos(memos: List<Memo>, query: String, filter: MemoFilter): List<Memo> =
    sortMemos(filterMemos(memos, query, filter))

/** 标题校验；返回 null 表示通过，否则返回可直接展示的错误文案。 */
fun validateMemoTitle(title: String): String? {
    val trimmed = title.trim()
    return when {
        trimmed.isEmpty() -> "标题不能为空"
        trimmed.length > MEMO_TITLE_MAX_LENGTH -> "标题不能超过 $MEMO_TITLE_MAX_LENGTH 个字符"
        else -> null
    }
}

/**
 * 根据编辑框内容构建实体：新增时生成 id 与创建时间，编辑时保留原 id / 创建时间 / 完成状态。
 * 抽出为纯函数，便于单元测试。
 */
fun buildMemo(
    existing: Memo?,
    editingId: String?,
    title: String,
    content: String,
    pinned: Boolean,
    now: Long,
    idGenerator: () -> String = { UUID.randomUUID().toString() },
): Memo {
    val id = editingId ?: existing?.id ?: idGenerator()
    return Memo(
        id = id,
        title = title.trim(),
        content = content.trimEnd(),
        done = existing?.done ?: false,
        pinned = pinned,
        createdAt = existing?.createdAt ?: now,
        updatedAt = now,
    )
}
