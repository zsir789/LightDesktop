package com.lightdesk.feature.floatingball

import org.junit.Assert.assertEquals
import org.junit.Test

/** 悬浮球几何计算纯函数的 JVM 单元测试。 */
class FloatingBallGeometryTest {

    @Test
    fun `clampSizeDp keeps valid size and limits invalid ones`() {
        assertEquals(56, FloatingBallGeometry.clampSizeDp(56))
        assertEquals(FloatingBallGeometry.MIN_SIZE_DP, FloatingBallGeometry.clampSizeDp(10))
        assertEquals(FloatingBallGeometry.MAX_SIZE_DP, FloatingBallGeometry.clampSizeDp(500))
        assertEquals(FloatingBallGeometry.MIN_SIZE_DP, FloatingBallGeometry.clampSizeDp(Int.MIN_VALUE))
    }

    @Test
    fun `maxCoordinate is zero when screen smaller than ball`() {
        assertEquals(0, FloatingBallGeometry.maxCoordinate(40, 56))
        assertEquals(944, FloatingBallGeometry.maxCoordinate(1000, 56))
        assertEquals(0, FloatingBallGeometry.maxCoordinate(56, 56))
    }

    @Test
    fun `clampX keeps ball inside screen`() {
        assertEquals(0, FloatingBallGeometry.clampX(-30, 1000, 56))
        assertEquals(944, FloatingBallGeometry.clampX(2000, 1000, 56))
        assertEquals(500, FloatingBallGeometry.clampX(500, 1000, 56))
        // 屏幕比悬浮球还窄时固定在 0，避免出现负坐标
        assertEquals(0, FloatingBallGeometry.clampX(10, 40, 56))
    }

    @Test
    fun `clampY keeps ball inside screen`() {
        assertEquals(0, FloatingBallGeometry.clampY(-1, 2000, 56))
        assertEquals(1944, FloatingBallGeometry.clampY(5000, 2000, 56))
        assertEquals(800, FloatingBallGeometry.clampY(800, 2000, 56))
    }

    @Test
    fun `edgeSnapTargetX snaps to left for ball in left half`() {
        // 无留白：最左侧就是 0
        assertEquals(
            0,
            FloatingBallGeometry.edgeSnapTargetX(
                currentX = 0,
                screenWidth = 1000,
                ballSize = 56,
                margin = 0,
            ),
        )
        // 有留白：吸附到 12px
        assertEquals(
            12,
            FloatingBallGeometry.edgeSnapTargetX(
                currentX = 100,
                screenWidth = 1000,
                ballSize = 56,
                margin = 12,
            ),
        )
    }

    @Test
    fun `edgeSnapTargetX snaps to right for ball in right half`() {
        assertEquals(
            944,
            FloatingBallGeometry.edgeSnapTargetX(
                currentX = 900,
                screenWidth = 1000,
                ballSize = 56,
                margin = 0,
            ),
        )
        assertEquals(
            932,
            FloatingBallGeometry.edgeSnapTargetX(
                currentX = 900,
                screenWidth = 1000,
                ballSize = 56,
                margin = 12,
            ),
        )
    }

    @Test
    fun `edgeSnapTargetX uses left edge when ball center is exactly at middle`() {
        // center = 500，不小于 screenWidth / 2（500），按“右侧”处理
        assertEquals(
            932,
            FloatingBallGeometry.edgeSnapTargetX(
                currentX = 472,
                screenWidth = 1000,
                ballSize = 56,
                margin = 12,
            ),
        )
    }

    @Test
    fun `edgeSnapTargetX handles narrow screen so left and right targets do not overlap`() {
        // max = 100 - 56 = 44；margin 100 收缩到 max/2 = 22，左右目标重合为 22
        assertEquals(
            22,
            FloatingBallGeometry.edgeSnapTargetX(
                currentX = 0,
                screenWidth = 100,
                ballSize = 56,
                margin = 100,
            ),
        )
        assertEquals(
            22,
            FloatingBallGeometry.edgeSnapTargetX(
                currentX = 44,
                screenWidth = 100,
                ballSize = 56,
                margin = 100,
            ),
        )
    }

    @Test
    fun `edgeSnapTargetX returns zero when ball does not fit on screen`() {
        assertEquals(
            0,
            FloatingBallGeometry.edgeSnapTargetX(
                currentX = 10,
                screenWidth = 40,
                ballSize = 56,
                margin = 12,
            ),
        )
    }

    @Test
    fun `initialX places ball near right edge without overflow`() {
        assertEquals(
            932,
            FloatingBallGeometry.initialX(screenWidth = 1000, ballSize = 56, margin = 12),
        )
        assertEquals(0, FloatingBallGeometry.initialX(screenWidth = 40, ballSize = 56, margin = 12))
    }

    @Test
    fun `initialY uses 55 percent of screen height and stays inside`() {
        assertEquals(1100, FloatingBallGeometry.initialY(screenHeight = 2000, ballSize = 56))
        assertEquals(0, FloatingBallGeometry.initialY(screenHeight = 0, ballSize = 56))
    }
}
