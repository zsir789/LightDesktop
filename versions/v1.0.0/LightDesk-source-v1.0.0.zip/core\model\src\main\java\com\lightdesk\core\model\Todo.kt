package com.lightdesk.core.model

import kotlinx.serialization.Serializable

/**
 * 待办：deadline 为 null 表示无截止时间。
 * remindBeforeMinutes 为后续接入系统通知预留的字段，当前仅做数据持久化。
 */
@Serializable
data class Todo(
    val id: String,
    val title: String,
    val note: String = "",
    val deadline: Long? = null,
    val done: Boolean = false,
    val completedAt: Long? = null,
    val remindBeforeMinutes: Int? = null,
    val createdAt: Long = 0L,
) {
    fun isOverdue(now: Long): Boolean = !done && deadline != null && deadline < now
}
