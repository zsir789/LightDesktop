package com.lightdesk.feature.timetable

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.FileOpen
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.lightdesk.core.common.TimeFormat
import com.lightdesk.core.designsystem.component.ConfirmDialog
import com.lightdesk.core.designsystem.component.EmptyState
import com.lightdesk.core.designsystem.component.ErrorBanner
import com.lightdesk.core.designsystem.component.InfoBanner
import com.lightdesk.core.designsystem.component.LoadingView
import com.lightdesk.core.designsystem.component.PageHorizontalPadding
import com.lightdesk.core.designsystem.component.ScreenHeader
import com.lightdesk.core.designsystem.component.SectionCard
import com.lightdesk.core.designsystem.component.SectionTitle
import com.lightdesk.core.designsystem.component.TagPill
import com.lightdesk.core.designsystem.component.TextAction
import com.lightdesk.core.model.Course
import com.lightdesk.feature.timetable.data.WeekText

private val DayColumnWidth = 96.dp
private val TimeAxisWidth = 48.dp
private const val MinutesPerHour = 60

/**
 * 课表主界面：空状态引导、导入/清空、周视图网格、课程详情。
 * 所有颜色来自主题，时间使用 TimeFormat 统一格式化。
 */
@Composable
fun TimetableScreen(
    state: TimetableUiState,
    onImportClick: () -> Unit,
    onClearClick: () -> Unit,
    onConfirmClear: () -> Unit,
    onDismissClear: () -> Unit,
    onDismissInfo: () -> Unit,
    onCourseClick: (Course) -> Unit,
    onDismissCourse: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier = modifier.fillMaxSize()) {
        ScreenHeader(
            title = "课表",
            subtitle = state.table?.let { table ->
                "${table.name} · ${table.courseCount} 门课程"
            } ?: "从 WakeUp 导出的 .ics 文件导入",
            actions = {
                if (state.importing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                }
                IconButton(onClick = onImportClick, enabled = !state.importing) {
                    Icon(
                        imageVector = Icons.Outlined.FileOpen,
                        contentDescription = "导入课表",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (state.table != null) {
                    IconButton(onClick = onClearClick, enabled = !state.importing) {
                        Icon(
                            imageVector = Icons.Outlined.DeleteOutline,
                            contentDescription = "清空课表",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            },
        )

        MessageBanners(
            errorMessage = state.errorMessage,
            infoMessage = state.infoMessage,
            onImportClick = onImportClick,
            onDismissInfo = onDismissInfo,
        )

        val table = state.table
        when {
            state.isLoading -> {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center,
                ) {
                    LoadingView(text = "正在读取课表…")
                }
            }

            table == null || table.courses.isEmpty() -> {
                EmptyTimetableContent(
                    modifier = Modifier.weight(1f),
                    onImportClick = onImportClick,
                )
            }

            else -> {
                TimetableContent(
                    courses = table.courses,
                    todayWeekday = state.todayWeekday,
                    onCourseClick = onCourseClick,
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }

    if (state.clearConfirmVisible) {
        ConfirmDialog(
            title = "清空课表",
            message = "清空后需要重新导入 .ics 文件才能恢复，确定要清空吗？",
            onConfirm = onConfirmClear,
            onDismiss = onDismissClear,
            confirmText = "清空",
            destructive = true,
        )
    }

    state.selectedCourse?.let { course ->
        CourseDetailDialog(course = course, onDismiss = onDismissCourse)
    }
}

@Composable
private fun MessageBanners(
    errorMessage: String?,
    infoMessage: String?,
    onImportClick: () -> Unit,
    onDismissInfo: () -> Unit,
) {
    if (errorMessage == null && infoMessage == null) return
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = PageHorizontalPadding, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        if (errorMessage != null) {
            ErrorBanner(
                message = errorMessage,
                actionLabel = "重新导入",
                onAction = onImportClick,
            )
        }
        if (infoMessage != null) {
            InfoBanner(
                message = infoMessage,
                actionLabel = "知道了",
                onAction = onDismissInfo,
            )
        }
    }
}

@Composable
private fun EmptyTimetableContent(
    onImportClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = PageHorizontalPadding),
    ) {
        EmptyState(
            title = "还没有导入课表",
            description = "从 WakeUp 导出 .ics 文件后导入，就能按周查看每天的课程。",
            icon = Icons.Outlined.CalendarMonth,
            actionLabel = "导入 .ics 课表",
            onAction = onImportClick,
        )
        ImportGuideCard()
        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun ImportGuideCard() {
    SectionCard {
        SectionTitle(text = "从 WakeUp 导出课表")
        Spacer(modifier = Modifier.height(10.dp))
        val steps = listOf(
            "打开 WakeUp，进入底部「课程表」页面。",
            "点击右上角菜单，选择「导出课表」或「分享课表」。",
            "在导出格式中选择「.ics 文件」，保存到手机。",
            "回到本页点击「导入 .ics 课表」，选中刚导出的文件。",
        )
        steps.forEachIndexed { index, step ->
            Row(modifier = Modifier.padding(vertical = 3.dp)) {
                Text(
                    text = "${index + 1}.",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.width(20.dp),
                )
                Text(
                    text = step,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f),
                )
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "导入后课表只保存在本地，不会上传到网络。",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun TimetableContent(
    courses: List<Course>,
    todayWeekday: Int,
    onCourseClick: (Course) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier = modifier.fillMaxWidth()) {
        TodaySummary(
            courses = courses,
            todayWeekday = todayWeekday,
            modifier = Modifier.padding(horizontal = PageHorizontalPadding, vertical = 4.dp),
        )
        WeeklyGrid(
            courses = courses,
            todayWeekday = todayWeekday,
            onCourseClick = onCourseClick,
            modifier = Modifier.weight(1f),
        )
    }
}

@Composable
private fun TodaySummary(
    courses: List<Course>,
    todayWeekday: Int,
    modifier: Modifier = Modifier,
) {
    val todayCourses = remember(courses, todayWeekday) {
        courses.filter { it.weekday == todayWeekday }.sortedBy { it.startMinutes }
    }
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        TagPill(
            text = "今天 ${TimeFormat.weekdayLabel(todayWeekday)}",
            color = MaterialTheme.colorScheme.primary,
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = if (todayCourses.isEmpty()) {
                "今天没有课"
            } else {
                "共 ${todayCourses.size} 节 · 首节 ${TimeFormat.minutesToClock(todayCourses.first().startMinutes)}"
            },
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun WeeklyGrid(
    courses: List<Course>,
    todayWeekday: Int,
    onCourseClick: (Course) -> Unit,
    modifier: Modifier = Modifier,
) {
    val horizontalScroll = rememberScrollState()
    val verticalScroll = rememberScrollState()
    val gridStart = remember(courses) { computeGridStart(courses) }
    val gridEnd = remember(courses, gridStart) { computeGridEnd(courses, gridStart) }
    val gridHeight = (gridEnd - gridStart).dp
    val coursesByWeekday = remember(courses) { courses.groupBy { it.weekday } }

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(horizontalScroll),
        ) {
            Spacer(modifier = Modifier.width(TimeAxisWidth))
            for (weekday in 1..7) {
                DayHeader(weekday = weekday, isToday = weekday == todayWeekday)
            }
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
        ) {
            Row(
                modifier = Modifier
                    .verticalScroll(verticalScroll)
                    .horizontalScroll(horizontalScroll),
            ) {
                TimeAxis(gridStart = gridStart, gridEnd = gridEnd)
                for (weekday in 1..7) {
                    DayColumn(
                        weekday = weekday,
                        courses = coursesByWeekday[weekday].orEmpty(),
                        gridStart = gridStart,
                        gridEnd = gridEnd,
                        isToday = weekday == todayWeekday,
                        onCourseClick = onCourseClick,
                    )
                }
            }
        }
    }
}

@Composable
private fun DayHeader(weekday: Int, isToday: Boolean) {
    val primary = MaterialTheme.colorScheme.primary
    Column(
        modifier = Modifier
            .width(DayColumnWidth)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = TimeFormat.weekdayLabel(weekday),
            style = MaterialTheme.typography.labelLarge,
            fontWeight = if (isToday) FontWeight.SemiBold else FontWeight.Normal,
            color = if (isToday) primary else MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(modifier = Modifier.height(3.dp))
        Box(
            modifier = Modifier
                .size(5.dp)
                .clip(CircleShape)
                .background(if (isToday) primary else Color.Transparent),
        )
    }
}

@Composable
private fun TimeAxis(gridStart: Int, gridEnd: Int) {
    Box(
        modifier = Modifier
            .width(TimeAxisWidth)
            .height((gridEnd - gridStart).dp),
    ) {
        var minute = gridStart
        while (minute <= gridEnd) {
            Text(
                text = TimeFormat.minutesToClock(minute),
                modifier = Modifier
                    .offset(y = ((minute - gridStart) - 7).coerceAtLeast(0).dp)
                    .fillMaxWidth()
                    .padding(end = 6.dp),
                textAlign = TextAlign.End,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            minute += MinutesPerHour
        }
    }
}

@Composable
private fun DayColumn(
    weekday: Int,
    courses: List<Course>,
    gridStart: Int,
    gridEnd: Int,
    isToday: Boolean,
    onCourseClick: (Course) -> Unit,
) {
    val lineColor = MaterialTheme.colorScheme.outlineVariant
    val todayTint = MaterialTheme.colorScheme.primary.copy(alpha = 0.04f)
    val columnHeight = (gridEnd - gridStart).dp

    Box(
        modifier = Modifier
            .width(DayColumnWidth)
            .height(columnHeight)
            .background(if (isToday) todayTint else Color.Transparent),
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val density = this.density
            var minute = gridStart
            while (minute <= gridEnd) {
                val y = (minute - gridStart) * density
                drawLine(
                    color = lineColor,
                    start = Offset(0f, y),
                    end = Offset(size.width, y),
                    strokeWidth = 1f,
                )
                minute += MinutesPerHour
            }
            drawLine(
                color = lineColor,
                start = Offset(size.width - 1f, 0f),
                end = Offset(size.width - 1f, size.height),
                strokeWidth = 1f,
            )
        }

        courses.forEach { course ->
            val top = course.startMinutes.coerceIn(gridStart, gridEnd)
            val bottom = course.endMinutes.coerceIn(top, gridEnd)
            val cardHeight = (bottom - top).coerceAtLeast(20)
            CourseCard(
                course = course,
                modifier = Modifier
                    .offset(y = (top - gridStart).dp)
                    .padding(horizontal = 3.dp)
                    .height(cardHeight.dp),
                onClick = { onCourseClick(course) },
            )
        }
    }
}

@Composable
private fun CourseCard(
    course: Course,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val accent = rememberCourseAccent(course.colorSeed)
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = MaterialTheme.shapes.small,
        color = accent.copy(alpha = 0.14f),
    ) {
        Row(modifier = Modifier.fillMaxSize()) {
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .fillMaxHeight()
                    .background(accent),
            )
            Column(
                modifier = Modifier.padding(horizontal = 5.dp, vertical = 4.dp),
            ) {
                Text(
                    text = course.title,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                if (course.location.isNotBlank()) {
                    Text(
                        text = course.location,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
    }
}

@Composable
private fun rememberCourseAccent(colorSeed: Int): Color {
    val scheme = MaterialTheme.colorScheme
    val palette = remember(scheme) {
        listOf(
            scheme.primary,
            scheme.secondary,
            scheme.tertiary,
            scheme.primary.copy(alpha = 0.82f),
            scheme.secondary.copy(alpha = 0.82f),
        )
    }
    return palette[Math.floorMod(colorSeed, palette.size)]
}

@Composable
private fun CourseDetailDialog(course: Course, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = course.title,
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurface,
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                DetailRow(
                    label = "时间",
                    value = buildString {
                        append(TimeFormat.weekdayLabel(course.weekday))
                        append(" ")
                        if (course.startMinutes == 0 && course.endMinutes >= 24 * 60) {
                            append("全天")
                        } else {
                            append(TimeFormat.minutesToClock(course.startMinutes))
                            append(" - ")
                            append(TimeFormat.minutesToClock(course.endMinutes))
                        }
                    },
                )
                if (course.teacher.isNotBlank()) {
                    DetailRow(label = "教师", value = course.teacher)
                }
                if (course.location.isNotBlank()) {
                    DetailRow(label = "地点", value = course.location)
                }
                DetailRow(label = "周次", value = WeekText.format(course.weeks))
                if (course.note.isNotBlank()) {
                    DetailRow(label = "备注", value = course.note)
                }
            }
        },
        confirmButton = {
            TextAction(text = "关闭", onClick = onDismiss)
        },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = MaterialTheme.shapes.large,
    )
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.width(44.dp),
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f),
        )
    }
}

/** 网格起始时间：最早课程所在整点，至少从 6:00 开始，避免全天事件把网格拉得过长。 */
private fun computeGridStart(courses: List<Course>): Int {
    val earliest = courses.minOfOrNull { it.startMinutes } ?: DEFAULT_GRID_START
    val roundedHour = (earliest / MinutesPerHour) * MinutesPerHour
    return roundedHour.coerceIn(MIN_HOUR * MinutesPerHour, MAX_GRID_START)
}

/** 网格结束时间：最晚课程所在整点，至少显示 4 小时，最晚到 23:00。 */
private fun computeGridEnd(courses: List<Course>, gridStart: Int): Int {
    val latest = courses.maxOfOrNull { it.endMinutes } ?: DEFAULT_GRID_END
    val roundedHour = ((latest + MinutesPerHour - 1) / MinutesPerHour) * MinutesPerHour
    return roundedHour.coerceIn(gridStart + 4 * MinutesPerHour, MAX_GRID_END)
}

private const val DEFAULT_GRID_START = 8 * 60
private const val DEFAULT_GRID_END = 20 * 60
private const val MIN_HOUR = 6
private const val MAX_GRID_START = 14 * 60
private const val MAX_GRID_END = 23 * 60
