package com.lightdesk.app.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.lightdesk.app.BuildConfig
import com.lightdesk.app.di.AppContainer
import com.lightdesk.core.common.AppLogger
import com.lightdesk.core.common.onFailure
import com.lightdesk.core.designsystem.component.PageHorizontalPadding
import com.lightdesk.core.designsystem.component.SectionCard
import com.lightdesk.core.designsystem.component.SectionTitle
import com.lightdesk.core.designsystem.component.SettingValueRow
import com.lightdesk.core.designsystem.component.TextAction
import com.lightdesk.core.model.AppSettings
import com.lightdesk.core.model.ThemeMode
import com.lightdesk.feature.floatingball.FloatingBallSettingsCard
import kotlinx.coroutines.launch

/** 预置城市（名称 + 经纬度）；后续可扩展为联网搜索城市。 */
private data class CityOption(val name: String, val latitude: Double, val longitude: Double)

private val cityOptions = listOf(
    CityOption("北京", 39.9042, 116.4074),
    CityOption("上海", 31.2304, 121.4737),
    CityOption("广州", 23.1291, 113.2644),
    CityOption("深圳", 22.5431, 114.0579),
    CityOption("杭州", 30.2741, 120.1551),
    CityOption("成都", 30.5728, 104.0668),
    CityOption("武汉", 30.5928, 114.3055),
    CityOption("西安", 34.3416, 108.9398),
    CityOption("南京", 32.0603, 118.7969),
    CityOption("重庆", 29.5630, 106.5516),
)

private data class ThresholdOption(val minutes: Int, val label: String)

private val thresholdOptions = listOf(
    ThresholdOption(15, "15 分钟"),
    ThresholdOption(60, "1 小时"),
    ThresholdOption(360, "6 小时"),
    ThresholdOption(720, "12 小时"),
    ThresholdOption(1440, "24 小时"),
    ThresholdOption(2880, "48 小时"),
)

/**
 * 设置页（应用组装层所有，非独立 feature）：管理悬浮球、天气城市、
 * 倒计时提醒阈值、主题等全局配置。
 */
@Composable
fun SettingsScreen(
    container: AppContainer,
    onBack: () -> Unit,
) {
    val settings by container.settingsRepository.observeSettings()
        .collectAsStateWithLifecycle(initialValue = AppSettings())
    val scope = rememberCoroutineScope()

    var showCityDialog by remember { mutableStateOf(false) }
    var showThresholdDialog by remember { mutableStateOf(false) }
    var showThemeDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = PageHorizontalPadding),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
                    contentDescription = "返回",
                    tint = MaterialTheme.colorScheme.onBackground,
                )
            }
            Spacer(modifier = Modifier.padding(start = 4.dp))
            Text(
                text = "设置",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground,
            )
        }

        Spacer(modifier = Modifier.height(18.dp))
        SectionTitle(text = "悬浮球")
        Spacer(modifier = Modifier.height(10.dp))
        FloatingBallSettingsCard(settingsRepository = container.settingsRepository)

        Spacer(modifier = Modifier.height(24.dp))
        SectionTitle(text = "偏好设置")
        Spacer(modifier = Modifier.height(10.dp))
        SectionCard {
            SettingValueRow(
                label = "天气城市",
                value = settings.weatherCity,
                onClick = { showCityDialog = true },
            )
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            SettingValueRow(
                label = "临近截止提醒",
                value = thresholdLabel(settings.countdownWarningMinutes),
                onClick = { showThresholdDialog = true },
            )
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            SettingValueRow(
                label = "主题模式",
                value = themeLabel(settings.themeMode),
                onClick = { showThemeDialog = true },
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
        SectionTitle(text = "关于")
        Spacer(modifier = Modifier.height(10.dp))
        SectionCard {
            SettingValueRow(label = "版本", value = BuildConfig.VERSION_NAME)
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            SettingValueRow(label = "数据存储", value = "仅本机")
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Text(
                text = "轻桌面是一款模块化的移动端桌面小工具，包含备忘录、课表、天气、" +
                    "待办倒计时、桌面悬浮球与使用统计。所有数据仅保存在设备本地，卸载后即清除。",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 12.dp),
            )
        }

        Spacer(modifier = Modifier.height(36.dp))
    }

    if (showCityDialog) {
        OptionPickerDialog(
            title = "选择天气城市",
            options = cityOptions.map { it.name },
            selectedIndex = cityOptions.indexOfFirst { it.name == settings.weatherCity },
            onSelect = { index ->
                val city = cityOptions[index]
                scope.launch {
                    container.settingsRepository.update {
                        it.copy(
                            weatherCity = city.name,
                            weatherLatitude = city.latitude,
                            weatherLongitude = city.longitude,
                        )
                    }.onFailure { AppLogger.w("Settings", "保存天气城市失败") }
                }
                showCityDialog = false
            },
            onDismiss = { showCityDialog = false },
        )
    }

    if (showThresholdDialog) {
        OptionPickerDialog(
            title = "临近截止提醒阈值",
            options = thresholdOptions.map { it.label },
            selectedIndex = thresholdOptions.indexOfFirst {
                it.minutes == settings.countdownWarningMinutes
            },
            onSelect = { index ->
                val option = thresholdOptions[index]
                scope.launch {
                    container.settingsRepository.update {
                        it.copy(countdownWarningMinutes = option.minutes)
                    }.onFailure { AppLogger.w("Settings", "保存提醒阈值失败") }
                }
                showThresholdDialog = false
            },
            onDismiss = { showThresholdDialog = false },
        )
    }

    if (showThemeDialog) {
        val modes = ThemeMode.entries
        OptionPickerDialog(
            title = "主题模式",
            options = modes.map { themeLabel(it) },
            selectedIndex = modes.indexOf(settings.themeMode),
            onSelect = { index ->
                scope.launch {
                    container.settingsRepository.update {
                        it.copy(themeMode = modes[index])
                    }.onFailure { AppLogger.w("Settings", "保存主题设置失败") }
                }
                showThemeDialog = false
            },
            onDismiss = { showThemeDialog = false },
        )
    }
}

private fun thresholdLabel(minutes: Int): String {
    return when {
        minutes < 60 -> "$minutes 分钟"
        minutes % 60 == 0 -> "${minutes / 60} 小时"
        else -> "$minutes 分钟"
    }
}

private fun themeLabel(mode: ThemeMode): String = when (mode) {
    ThemeMode.SYSTEM -> "跟随系统"
    ThemeMode.LIGHT -> "浅色"
    ThemeMode.DARK -> "深色"
}

@Composable
private fun OptionPickerDialog(
    title: String,
    options: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(text = title, style = MaterialTheme.typography.titleLarge) },
        text = {
            Column {
                options.forEachIndexed { index, label ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(index) }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                        if (index == selectedIndex) {
                            Icon(
                                imageVector = Icons.Outlined.Check,
                                contentDescription = "已选择",
                                tint = MaterialTheme.colorScheme.primary,
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextAction(text = "取消", onClick = onDismiss)
        },
        containerColor = MaterialTheme.colorScheme.surface,
        shape = MaterialTheme.shapes.large,
    )
}
