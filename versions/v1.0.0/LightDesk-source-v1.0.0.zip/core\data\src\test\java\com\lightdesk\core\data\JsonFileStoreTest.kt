package com.lightdesk.core.data

import com.lightdesk.core.common.NoOpLogger
import com.lightdesk.core.common.isSuccess
import com.lightdesk.core.data.store.JsonFileStore
import com.lightdesk.core.data.store.MemoStore
import com.lightdesk.core.model.Memo
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.File
import java.nio.file.Files

@OptIn(ExperimentalCoroutinesApi::class)
class JsonFileStoreTest {

    private lateinit var dir: File
    private lateinit var file: File
    private val dispatcher = UnconfinedTestDispatcher()

    @Before
    fun setUp() {
        dir = Files.createTempDirectory("lightdesk-store-test").toFile()
        file = File(dir, "memos.json")
    }

    @After
    fun tearDown() {
        dir.deleteRecursively()
    }

    private fun newStore() = JsonFileStore(
        file = file,
        serializer = MemoStore.serializer(),
        defaultValue = { MemoStore() },
        logger = NoOpLogger,
        ioDispatcher = dispatcher,
    )

    @Test
    fun `文件不存在时返回默认值`() = runTest {
        val store = newStore()
        assertEquals(emptyList<Memo>(), store.read().items)
    }

    @Test
    fun `写入后可以从磁盘重新读取`() = runTest {
        val store = newStore()
        val memo = Memo(id = "1", title = "买牛奶", content = "两盒", createdAt = 1L, updatedAt = 2L)
        assertTrue(store.write(MemoStore(items = listOf(memo))).isSuccess)

        // 新实例模拟进程重启：必须从磁盘读取而不是内存缓存
        val reloaded = newStore().read()
        assertEquals(1, reloaded.items.size)
        assertEquals("买牛奶", reloaded.items.first().title)
        assertEquals("两盒", reloaded.items.first().content)
    }

    @Test
    fun `损坏文件会备份并回退默认值`() = runTest {
        file.writeText("{ 这不是合法 JSON ", Charsets.UTF_8)
        val store = newStore()

        val result = store.read()

        assertEquals(emptyList<Memo>(), result.items)
        val backup = File(dir, "memos.json.corrupt")
        assertTrue("损坏文件应被备份", backup.exists())
        assertTrue("读取后应回到默认值", store.read().items.isEmpty())
    }
}
