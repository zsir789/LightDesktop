package com.lightdesk.feature.todo

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lightdesk.core.common.TimeProvider
import com.lightdesk.core.common.simpleViewModelFactory
import com.lightdesk.core.data.UsageTracker
import com.lightdesk.core.data.repository.SettingsRepository
import com.lightdesk.core.data.repository.TodoRepository
import com.lightdesk.core.model.AppSettings
import com.lightdesk.core.model.FeatureKey
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.catch

/**
 * 待办倒计时功能入口。
 *
 * 除了组装 ViewModel 与使用统计，这里还负责两件与时间相关的事：
 * 1. 从设置中读取“临近截止”的提醒阈值（[AppSettings.countdownWarningMinutes]）；
 * 2. 页面处于 RESUMED 时每秒通过 [TimeProvider] 刷新当前时间，页面不可见时自动停止刷新。
 */
@Composable
fun TodoRoute(
    repository: TodoRepository,
    settingsRepository: SettingsRepository,
    usageTracker: UsageTracker,
    timeProvider: TimeProvider,
    modifier: Modifier = Modifier,
) {
    val factory = remember(repository, timeProvider) {
        simpleViewModelFactory { TodoViewModel(repository, timeProvider) }
    }
    val viewModel: TodoViewModel = viewModel(factory = factory)
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    val settingsFlow = remember(settingsRepository) {
        settingsRepository.observeSettings().catch { cause ->
            if (cause is CancellationException) throw cause
            emit(AppSettings())
        }
    }
    val settings by settingsFlow.collectAsStateWithLifecycle(initialValue = AppSettings())

    var now by remember { mutableStateOf(timeProvider.now()) }
    val lifecycleOwner = LocalLifecycleOwner.current
    LaunchedEffect(lifecycleOwner, timeProvider) {
        lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) {
            while (true) {
                now = timeProvider.now()
                delay(1_000L)
            }
        }
    }

    LaunchedEffect(Unit) {
        usageTracker.track(FeatureKey.TODO)
    }

    val actions = remember(viewModel) {
        TodoActions(
            onCreate = viewModel::startCreate,
            onEdit = viewModel::startEdit,
            onToggleDone = viewModel::toggleDone,
            onRequestDelete = viewModel::requestDelete,
            onDismissDelete = viewModel::dismissDelete,
            onConfirmDelete = viewModel::confirmDelete,
            onDismissEditor = viewModel::dismissEditor,
            onEditorTitleChange = viewModel::onEditorTitleChange,
            onEditorNoteChange = viewModel::onEditorNoteChange,
            onEditorSetNoDeadline = viewModel::onEditorSetNoDeadline,
            onEditorQuickDate = viewModel::onEditorQuickDate,
            onEditorDateSelected = viewModel::onEditorDateSelected,
            onEditorTimeSelected = viewModel::onEditorTimeSelected,
            onSave = viewModel::save,
            onMessageShown = viewModel::consumeMessage,
            onRetry = viewModel::retryLoad,
        )
    }

    TodoScreen(
        state = state,
        now = now,
        warningMinutes = settings.countdownWarningMinutes,
        actions = actions,
        modifier = modifier,
    )
}
