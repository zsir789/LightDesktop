package com.lightdesk.feature.todo

import com.lightdesk.core.model.Todo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

class TodoLogicTest {

    private val zoneId: ZoneId = ZoneId.of("Asia/Shanghai")

    private fun todo(
        id: String,
        title: String = "待办",
        deadline: Long? = null,
        done: Boolean = false,
        completedAt: Long? = null,
        createdAt: Long = 0L,
        note: String = "",
        remindBeforeMinutes: Int? = null,
    ) = Todo(
        id = id,
        title = title,
        note = note,
        deadline = deadline,
        done = done,
        completedAt = completedAt,
        remindBeforeMinutes = remindBeforeMinutes,
        createdAt = createdAt,
    )

    @Test
    fun `紧急度判定覆盖已完成 无截止 已超时 临近与正常`() {
        val now = 1_000_000L
        val warningMinutes = 30

        assertEquals(
            TodoUrgency.DONE,
            urgencyOf(todo(id = "1", deadline = now - 10_000L, done = true), now, warningMinutes),
        )
        assertEquals(
            TodoUrgency.NO_DEADLINE,
            urgencyOf(todo(id = "2", deadline = null), now, warningMinutes),
        )
        assertEquals(
            TodoUrgency.OVERDUE,
            urgencyOf(todo(id = "3", deadline = now - 1L), now, warningMinutes),
        )
        assertEquals(
            TodoUrgency.WARNING,
            urgencyOf(todo(id = "4", deadline = now + 29 * 60_000L), now, warningMinutes),
        )
        assertEquals(
            TodoUrgency.NORMAL,
            urgencyOf(todo(id = "5", deadline = now + 31 * 60_000L), now, warningMinutes),
        )
    }

    @Test
    fun `紧急度阈值边界与非法阈值处理`() {
        val now = 1_000_000L
        // 恰好等于阈值 -> 警告
        assertEquals(
            TodoUrgency.WARNING,
            urgencyOf(todo(id = "a", deadline = now + 30 * 60_000L), now, 30),
        )
        // 阈值为 0 时，剩余 0 毫秒仍算警告，超过才算正常
        assertEquals(
            TodoUrgency.WARNING,
            urgencyOf(todo(id = "b", deadline = now), now, 0),
        )
        assertEquals(
            TodoUrgency.NORMAL,
            urgencyOf(todo(id = "c", deadline = now + 1L), now, 0),
        )
        // 负数阈值按 0 处理，不会把“未来 1 毫秒”判成警告
        assertEquals(
            TodoUrgency.NORMAL,
            urgencyOf(todo(id = "d", deadline = now + 1L), now, -10),
        )
    }

    @Test
    fun `排序为未完成按截止升序 无截止靠后 已完成最后`() {
        val todos = listOf(
            todo(id = "done-old", deadline = 1_000L, done = true, completedAt = 5_000L),
            todo(id = "no-deadline-2", deadline = null),
            todo(id = "late", deadline = 9_000L),
            todo(id = "no-deadline-1", deadline = null),
            todo(id = "done-new", deadline = 2_000L, done = true, completedAt = 9_000L),
            todo(id = "early", deadline = 3_000L),
        )
        val ordered = sortTodos(todos).map { it.id }
        assertEquals("early", ordered[0])
        assertEquals("late", ordered[1])
        // 无截止时间的两个排在后面（同截止键时按 id 兜底）
        assertEquals(listOf("no-deadline-1", "no-deadline-2"), ordered.subList(2, 4))
        // 已完成最后，且最近完成的靠前
        assertEquals(listOf("done-new", "done-old"), ordered.subList(4, 6))
    }

    @Test
    fun `排序对空列表与单元素安全`() {
        assertTrue(sortTodos(emptyList()).isEmpty())
        assertEquals(listOf("only"), sortTodos(listOf(todo(id = "only"))).map { it.id })
    }

    @Test
    fun `日期时分组合为时间戳并可按指定时区还原`() {
        val dateEpochDay = LocalDate.of(2026, 10, 19).toEpochDay()
        val millis = combineDateAndTime(dateEpochDay, 18, 30, zoneId)
        assertEquals(Instant.parse("2026-10-19T10:30:00Z").toEpochMilli(), millis)

        assertEquals(dateEpochDay, deadlineDateEpochDay(millis, zoneId))
        assertEquals(18, deadlineHour(millis, zoneId))
        assertEquals(30, deadlineMinute(millis, zoneId))
        assertEquals("10月19日", formatDateLabel(dateEpochDay))
    }

    @Test
    fun `按时区计算当天日期`() {
        // UTC 2026-10-19 20:00 = 上海 2026-10-20 04:00
        val instant = Instant.parse("2026-10-19T20:00:00Z").toEpochMilli()
        assertEquals(LocalDate.of(2026, 10, 20).toEpochDay(), todayEpochDay(instant, zoneId))
        assertEquals(LocalDate.of(2026, 10, 19).toEpochDay(), todayEpochDay(instant, ZoneId.of("UTC")))
    }

    @Test
    fun `标题校验拒绝空标题与超长标题`() {
        assertEquals("标题不能为空", validateTodoTitle(""))
        assertEquals("标题不能为空", validateTodoTitle("   "))
        assertNull(validateTodoTitle("交报告"))
        assertNull(validateTodoTitle("a".repeat(TODO_TITLE_MAX_LENGTH)))
        assertEquals(
            "标题不能超过 $TODO_TITLE_MAX_LENGTH 个字符",
            validateTodoTitle("a".repeat(TODO_TITLE_MAX_LENGTH + 1)),
        )
    }

    @Test
    fun `从待办构造编辑状态时还原截止日期与时分`() {
        val deadline = combineDateAndTime(LocalDate.of(2026, 12, 1).toEpochDay(), 9, 5, zoneId)
        val editor = todoEditorState(
            todo(id = "t1", title = "交报告", deadline = deadline, note = "附上附件"),
            zoneId,
        )
        assertEquals("t1", editor.editingId)
        assertEquals("交报告", editor.title)
        assertEquals("附上附件", editor.note)
        assertEquals(LocalDate.of(2026, 12, 1).toEpochDay(), editor.dateEpochDay)
        assertEquals(9, editor.hour)
        assertEquals(5, editor.minute)
        assertEquals(deadline, editor.deadlineMillis(zoneId))
    }

    @Test
    fun `新增模式默认无截止时间并使用默认时刻`() {
        val editor = todoEditorState(null, zoneId)
        assertNull(editor.editingId)
        assertNull(editor.dateEpochDay)
        assertEquals(DEFAULT_DEADLINE_HOUR, editor.hour)
        assertEquals(0, editor.minute)
        assertNull(editor.deadlineMillis(zoneId))
    }

    @Test
    fun `新增待办生成 id 与创建时间`() {
        val deadline = 123_456L
        val todo = buildTodo(
            existing = null,
            editingId = null,
            title = "  交报告  ",
            note = "备注\n",
            deadline = deadline,
            now = 1_000L,
            idGenerator = { "generated-id" },
        )
        assertEquals("generated-id", todo.id)
        assertEquals("交报告", todo.title)
        assertEquals("备注", todo.note)
        assertEquals(deadline, todo.deadline)
        assertEquals(1_000L, todo.createdAt)
        assertEquals(false, todo.done)
    }

    @Test
    fun `编辑待办保留原 id 创建时间与完成信息`() {
        val existing = todo(
            id = "keep-id",
            title = "旧标题",
            deadline = 500L,
            done = true,
            completedAt = 800L,
            createdAt = 300L,
            remindBeforeMinutes = 15,
        )
        val updated = buildTodo(
            existing = existing,
            editingId = existing.id,
            title = "新标题",
            note = "新备注",
            deadline = 900L,
            now = 2_000L,
            idGenerator = { "should-not-be-used" },
        )
        assertEquals("keep-id", updated.id)
        assertEquals(300L, updated.createdAt)
        assertEquals(900L, updated.deadline)
        assertTrue(updated.done)
        assertEquals(800L, updated.completedAt)
        assertEquals(15, updated.remindBeforeMinutes)
    }

    @Test
    fun `编辑目标已被删除时仍按编辑 id 保存`() {
        val updated = buildTodo(
            existing = null,
            editingId = "editing-id",
            title = "标题",
            note = "",
            deadline = null,
            now = 700L,
            idGenerator = { "unused" },
        )
        assertEquals("editing-id", updated.id)
        assertEquals(700L, updated.createdAt)
        assertNull(updated.deadline)
    }
}
