# 轻桌面 · 架构说明

> 移动端桌面小工具（Android / Kotlin / Jetpack Compose），功能模块化拆分，数据全部本地持久化。

## 1. 模块划分

```
:app                        应用壳：MainActivity、导航、设置页、开机自启、依赖组装
├─ :core:common             通用能力：结果类型、错误码、日志、时间/格式化、调度器、ViewModel 工厂
├─ :core:model              纯数据模型（kotlinx.serialization），无 Android 依赖逻辑
├─ :core:data               本地持久化与仓储接口/实现：JSON 文件存储、使用统计入口
├─ :core:designsystem       设计系统：主题、配色、字体、圆角、通用组件
├─ :feature:memo            备忘录：增删改查、完成标记
├─ :feature:timetable       课表：WakeUp 导出 ICS 解析、周视图展示、导入管理
├─ :feature:weather         天气：Open-Meteo 联网获取、缓存降级、异常提示
├─ :feature:todo            待办倒计时：截止时间、实时倒计时、临近提醒
├─ :feature:stats           使用统计：各功能使用次数、最近使用时间、重置
└─ :feature:floatingball    悬浮球：前台服务 + 系统悬浮窗，可拖动、点击唤起主程序
```

依赖方向：`feature:* → core:data / core:designsystem → core:model / core:common`；`:app` 依赖所有模块并负责组装。
**功能模块之间互不依赖**，通过 `core:data` 中的接口与 `app` 注入的回调协作。

## 2. 分层与数据流

```
Compose UI (feature)
    ↓ 只依赖接口
ViewModel / UiState（feature 内部，可选）
    ↓
Repository 接口（core:data）
    ↓
JsonFileStore（core:data，原子写 + 异常兜底）
    ↓
filesDir/lightdesk/*.json
```

- 读：仓储内部持有 `StateFlow`，首次收集时懒加载；文件损坏会备份为 `.corrupt` 并回退默认值。
- 写：先写 `.tmp` 再原子替换；失败返回 `AppResult.Failure`，UI 负责提示，不会崩溃。
- 使用统计：任何功能调用 `UsageTracker.track(FeatureKey.XXX)`，异步落盘，失败不影响主流程。

## 3. 本地数据文件

| 文件 | 内容 |
| --- | --- |
| `settings.json` | 悬浮球开关、天气城市/经纬度、倒计时提醒阈值、主题模式等 |
| `memos.json` | 备忘录列表 |
| `todos.json` | 待办列表 |
| `courses.json` | 导入的课表（课程列表 + 来源信息） |
| `usage_stats.json` | 各功能使用次数、最近使用时间 |
| `weather_cache.json` | 最近一次天气快照（离线降级展示） |

所有文件均带 `schemaVersion`，便于后续做数据迁移。

## 4. 关键设计决策

1. **JSON 文件而非数据库**：数据量小、零原生依赖、易备份；接口抽象保证后续可平滑迁移 Room。
2. **手动依赖注入**：`AppContainer` 单点组装，避免引入注解处理器拖慢构建；后续可替换 Hilt。
3. **悬浮球解耦**：服务只负责窗口与点击手势，点击通过 `Intent` 携带来源标记唤起 `MainActivity`，
   由应用层记录“悬浮球”使用次数，服务不依赖业务数据层。
4. **天气降级**：网络失败时读取 `weather_cache.json` 展示缓存并标注更新时间，同时给出重试入口。
5. **不硬编码**：城市、提醒阈值、主题、悬浮球尺寸等均来自 `AppSettings`；颜色/圆角/字体来自设计系统；
   天气接口地址集中在 `OpenMeteoService`，课表解析规则独立成 `IcsParser`，均可单独替换。

## 5. 扩展点（预留迭代接口）

| 扩展方向 | 接入方式 |
| --- | --- |
| 新增功能模块 | 新建 `:feature:xxx`，在 `:app` 的 `TopLevelDestination`/`NavHost` 注册；统计枚举追加 `FeatureKey` |
| 更换存储 | 实现 `core:data` 中对应 Repository 接口，在 `AppContainer` 替换实现 |
| 更换天气服务 | 实现 `feature:weather` 的 `WeatherDataSource` 接口，注入 `OpenMeteoRepository` 的位置替换 |
| 课表来源扩展 | 新增 `TimetableImporter` 实现（如 CSV/学校教务系统），UI 选择导入方式 |
| 系统通知提醒 | `Todo.remindBeforeMinutes` 字段已预留，配合 WorkManager/AlarmManager 即可 |
| 换肤 | `core:designsystem` 的 `LightDeskTheme` 单点控制，支持深浅色与主题扩展 |
| 使用统计上报 | `UsageTracker` 为单点入口，可追加远程上报实现 |
