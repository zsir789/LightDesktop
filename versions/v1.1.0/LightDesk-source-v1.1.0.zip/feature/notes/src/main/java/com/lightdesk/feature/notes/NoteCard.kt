package com.lightdesk.feature.notes

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.lightdesk.core.designsystem.component.TagPill
import com.lightdesk.core.designsystem.theme.LocalStatusColors
import com.lightdesk.core.model.NoteItem

/**
 * 单条事项卡片。
 *
 * 视觉状态全部由 [item] 派生：完成态用删除线 + 弱化颜色 + 卡片底色渐变，
 * 勾选动作通过 [CompletionCheckbox] 的弹性缩放与对勾渐显反馈。
 */
@Composable
internal fun NoteCard(
    item: NoteItem,
    now: Long,
    onToggleDone: () -> Unit,
    onEdit: () -> Unit,
    onTogglePinned: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val status = LocalStatusColors.current
    var menuExpanded by remember { mutableStateOf(false) }

    val containerColor by animateColorAsState(
        targetValue = if (item.done) {
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
        } else {
            MaterialTheme.colorScheme.surface
        },
        animationSpec = tween(durationMillis = 240),
        label = "noteCardContainer",
    )
    val contentAlpha by animateFloatAsState(
        targetValue = if (item.done) 0.55f else 1f,
        animationSpec = tween(durationMillis = 240),
        label = "noteCardContentAlpha",
    )
    val titleColor = MaterialTheme.colorScheme.onSurface.copy(alpha = contentAlpha)
    val bodyColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = contentAlpha)

    val deadline = item.deadline
    val deadlineColor = when {
        item.done -> status.success
        deadline != null && item.isOverdue(now) -> status.danger
        deadline != null -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = contentAlpha)
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    val deadlineText = when {
        item.done -> "已完成"
        deadline != null -> NotesFormat.countdownText(deadline, now)
        else -> ""
    }

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        color = containerColor,
        border = BorderStroke(
            width = 1.dp,
            color = MaterialTheme.colorScheme.outlineVariant.copy(
                alpha = if (item.done) 0.5f else 1f,
            ),
        ),
    ) {
        Row(
            modifier = Modifier.padding(start = 4.dp, end = 2.dp, top = 6.dp, bottom = 12.dp),
            verticalAlignment = Alignment.Top,
        ) {
            CompletionCheckbox(
                checked = item.done,
                onClick = onToggleDone,
            )
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(top = 8.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (item.pinned) {
                        Icon(
                            imageVector = Icons.Rounded.PushPin,
                            contentDescription = "已置顶",
                            tint = status.warning,
                            modifier = Modifier.size(14.dp),
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                    Text(
                        text = item.title,
                        style = MaterialTheme.typography.titleMedium,
                        color = titleColor,
                        textDecoration = if (item.done) {
                            TextDecoration.LineThrough
                        } else {
                            TextDecoration.None
                        },
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                val preview = item.preview
                if (preview.isNotBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = preview,
                        style = MaterialTheme.typography.bodyMedium,
                        color = bodyColor,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    TagPill(
                        text = if (item.isTodo) "待办" else "备忘",
                        color = if (item.isTodo) {
                            MaterialTheme.colorScheme.primary.copy(alpha = contentAlpha)
                        } else {
                            MaterialTheme.colorScheme.tertiary.copy(alpha = contentAlpha)
                        },
                    )
                    if (deadline != null) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Outlined.Schedule,
                                contentDescription = null,
                                tint = deadlineColor,
                                modifier = Modifier.size(13.dp),
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "${NotesFormat.deadlineDateTimeText(deadline)} · $deadlineText",
                                style = MaterialTheme.typography.labelMedium,
                                color = deadlineColor,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }
            }
            Box {
                IconButton(onClick = { menuExpanded = true }) {
                    Icon(
                        imageVector = Icons.Outlined.MoreVert,
                        contentDescription = "更多操作",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = contentAlpha),
                    )
                }
                DropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false },
                ) {
                    DropdownMenuItem(
                        text = { Text("编辑") },
                        onClick = {
                            menuExpanded = false
                            onEdit()
                        },
                    )
                    DropdownMenuItem(
                        text = { Text(if (item.pinned) "取消置顶" else "置顶") },
                        onClick = {
                            menuExpanded = false
                            onTogglePinned()
                        },
                    )
                    DropdownMenuItem(
                        text = { Text("删除", color = status.danger) },
                        onClick = {
                            menuExpanded = false
                            onDelete()
                        },
                    )
                }
            }
        }
    }
}

/**
 * 完成勾选控件：填充色渐变 + 对勾弹性缩放渐显。
 *
 * 备忘与待办都可以勾选完成，因此不做类型限制。
 */
@Composable
private fun CompletionCheckbox(
    checked: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val status = LocalStatusColors.current
    val fillColor by animateColorAsState(
        targetValue = if (checked) status.success else Color.Transparent,
        animationSpec = tween(durationMillis = 180),
        label = "checkFill",
    )
    val borderColor by animateColorAsState(
        targetValue = if (checked) status.success else MaterialTheme.colorScheme.outline,
        animationSpec = tween(durationMillis = 180),
        label = "checkBorder",
    )
    val checkScale by animateFloatAsState(
        targetValue = if (checked) 1f else 0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow,
        ),
        label = "checkScale",
    )
    val checkAlpha by animateFloatAsState(
        targetValue = if (checked) 1f else 0f,
        animationSpec = tween(durationMillis = 160),
        label = "checkAlpha",
    )

    Box(
        modifier = modifier
            .size(40.dp)
            .clip(CircleShape)
            .clickable(role = Role.Checkbox, onClick = onClick)
            .semantics {
                contentDescription = if (checked) "取消完成" else "标记完成"
            },
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(fillColor)
                .border(width = 1.5.dp, color = borderColor, shape = CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = Icons.Rounded.Check,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier
                    .size(16.dp)
                    .scale(checkScale)
                    .alpha(checkAlpha),
            )
        }
    }
}
