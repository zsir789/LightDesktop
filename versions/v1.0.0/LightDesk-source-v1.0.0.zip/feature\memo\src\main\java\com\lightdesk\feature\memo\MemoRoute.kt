package com.lightdesk.feature.memo

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lightdesk.core.common.TimeProvider
import com.lightdesk.core.common.simpleViewModelFactory
import com.lightdesk.core.data.UsageTracker
import com.lightdesk.core.data.repository.MemoRepository
import com.lightdesk.core.model.FeatureKey

/**
 * 备忘录功能入口：组装 ViewModel、记录使用统计，并把状态与动作交给 [MemoScreen]。
 *
 * 依赖只通过构造函数注入，功能模块内部不感知仓储实现。
 */
@Composable
fun MemoRoute(
    repository: MemoRepository,
    usageTracker: UsageTracker,
    timeProvider: TimeProvider,
    modifier: Modifier = Modifier,
) {
    val factory = remember(repository, timeProvider) {
        simpleViewModelFactory { MemoViewModel(repository, timeProvider) }
    }
    val viewModel: MemoViewModel = viewModel(factory = factory)
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        usageTracker.track(FeatureKey.MEMO)
    }

    val actions = remember(viewModel) {
        MemoActions(
            onQueryChange = viewModel::onQueryChange,
            onFilterChange = viewModel::onFilterChange,
            onClearFilters = viewModel::clearFilters,
            onCreate = viewModel::startCreate,
            onEdit = viewModel::startEdit,
            onToggleDone = viewModel::toggleDone,
            onTogglePinned = viewModel::togglePinned,
            onRequestDelete = viewModel::requestDelete,
            onDismissDelete = viewModel::dismissDelete,
            onConfirmDelete = viewModel::confirmDelete,
            onDismissEditor = viewModel::dismissEditor,
            onEditorTitleChange = viewModel::onEditorTitleChange,
            onEditorContentChange = viewModel::onEditorContentChange,
            onEditorPinnedChange = viewModel::onEditorPinnedChange,
            onSave = viewModel::save,
            onMessageShown = viewModel::consumeMessage,
            onRetry = viewModel::retryLoad,
        )
    }

    MemoScreen(state = state, actions = actions, modifier = modifier)
}
