@file:OptIn(ExperimentalMaterial3Api::class)

package com.lightdesk.feature.memo

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.EditNote
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.SearchOff
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.lightdesk.core.common.TimeFormat
import com.lightdesk.core.designsystem.component.ConfirmDialog
import com.lightdesk.core.designsystem.component.EmptyState
import com.lightdesk.core.designsystem.component.ErrorBanner
import com.lightdesk.core.designsystem.component.LoadingView
import com.lightdesk.core.designsystem.component.PageHorizontalPadding
import com.lightdesk.core.designsystem.component.PrimaryButton
import com.lightdesk.core.designsystem.component.ScreenHeader
import com.lightdesk.core.designsystem.component.SecondaryButton
import com.lightdesk.core.designsystem.component.SectionCard
import com.lightdesk.core.designsystem.component.TextAction
import com.lightdesk.core.designsystem.theme.LocalStatusColors
import com.lightdesk.core.model.Memo

/** 备忘录页面的用户动作集合，由 Route 从 ViewModel 绑定。 */
data class MemoActions(
    val onQueryChange: (String) -> Unit = {},
    val onFilterChange: (MemoFilter) -> Unit = {},
    val onClearFilters: () -> Unit = {},
    val onCreate: () -> Unit = {},
    val onEdit: (Memo) -> Unit = {},
    val onToggleDone: (Memo) -> Unit = {},
    val onTogglePinned: (Memo) -> Unit = {},
    val onRequestDelete: (Memo) -> Unit = {},
    val onDismissDelete: () -> Unit = {},
    val onConfirmDelete: () -> Unit = {},
    val onDismissEditor: () -> Unit = {},
    val onEditorTitleChange: (String) -> Unit = {},
    val onEditorContentChange: (String) -> Unit = {},
    val onEditorPinnedChange: (Boolean) -> Unit = {},
    val onSave: () -> Unit = {},
    val onMessageShown: (Long) -> Unit = {},
    val onRetry: () -> Unit = {},
)

/**
 * 备忘录主界面：搜索 + 筛选 + 卡片列表 + 编辑弹窗 + 删除确认。
 * 只消费 [MemoUiState] 并通过 [MemoActions] 回调，不直接持有 ViewModel。
 */
@Composable
fun MemoScreen(
    state: MemoUiState,
    actions: MemoActions,
    modifier: Modifier = Modifier,
) {
    val snackbarHostState = remember { SnackbarHostState() }
    val message = state.message
    LaunchedEffect(message) {
        if (message != null) {
            snackbarHostState.showSnackbar(message.text)
            actions.onMessageShown(message.id)
        }
    }

    val shownMemos = remember(state.memos, state.query, state.filter) {
        visibleMemos(state.memos, state.query, state.filter)
    }
    val loadError = state.loadError
    val showLoadFailedPlaceholder = loadError != null && state.memos.isEmpty()
    val subtitle = when {
        state.loading -> "正在加载…"
        showLoadFailedPlaceholder -> "加载失败"
        else -> "共 ${state.memos.size} 条 · 未完成 ${state.memos.count { !it.done }} 条"
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            ScreenHeader(
                title = "备忘录",
                subtitle = subtitle,
                actions = {
                    TextAction(text = "新建", onClick = actions.onCreate)
                },
            )

            Column(modifier = Modifier.padding(horizontal = PageHorizontalPadding)) {
                OutlinedTextField(
                    value = state.query,
                    onValueChange = actions.onQueryChange,
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text(text = "搜索标题或内容") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Outlined.Search,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp),
                        )
                    },
                    trailingIcon = if (state.query.isNotBlank()) {
                        {
                            IconButton(onClick = { actions.onQueryChange("") }) {
                                Icon(
                                    imageVector = Icons.Outlined.Close,
                                    contentDescription = "清空搜索",
                                    modifier = Modifier.size(18.dp),
                                )
                            }
                        }
                    } else {
                        null
                    },
                    shape = MaterialTheme.shapes.medium,
                )

                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MemoFilter.entries.forEach { filter ->
                        FilterChip(
                            selected = state.filter == filter,
                            onClick = { actions.onFilterChange(filter) },
                            label = { Text(text = filter.label) },
                        )
                    }
                }

                val bannerMessage = loadError
                if (bannerMessage != null && state.memos.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    ErrorBanner(message = bannerMessage, onAction = actions.onRetry)
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            Box(modifier = Modifier.weight(1f)) {
                when {
                    state.loading -> LoadingView(modifier = Modifier.align(Alignment.TopCenter))
                    showLoadFailedPlaceholder -> EmptyState(
                        title = "备忘录加载失败",
                        description = loadError,
                        icon = Icons.Outlined.ErrorOutline,
                        actionLabel = "重试",
                        onAction = actions.onRetry,
                    )

                    state.memos.isEmpty() -> EmptyState(
                        title = "还没有备忘录",
                        description = "把想法、清单和灵感记在这里",
                        icon = Icons.Outlined.EditNote,
                        actionLabel = "新建备忘录",
                        onAction = actions.onCreate,
                    )

                    shownMemos.isEmpty() -> EmptyState(
                        title = "没有匹配的备忘录",
                        description = "试试换个关键字，或清空筛选条件",
                        icon = Icons.Outlined.SearchOff,
                        actionLabel = "清空筛选",
                        onAction = actions.onClearFilters,
                    )

                    else -> LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(
                            start = PageHorizontalPadding,
                            end = PageHorizontalPadding,
                            top = 4.dp,
                            bottom = 24.dp,
                        ),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        items(items = shownMemos, key = { it.id }) { memo ->
                            MemoCard(
                                memo = memo,
                                onEdit = { actions.onEdit(memo) },
                                onToggleDone = { actions.onToggleDone(memo) },
                                onTogglePinned = { actions.onTogglePinned(memo) },
                                onDelete = { actions.onRequestDelete(memo) },
                            )
                        }
                    }
                }
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(horizontal = PageHorizontalPadding, vertical = 12.dp),
        )

        state.editor?.let { editor ->
            MemoEditorDialog(
                editor = editor,
                saving = state.saving,
                onTitleChange = actions.onEditorTitleChange,
                onContentChange = actions.onEditorContentChange,
                onPinnedChange = actions.onEditorPinnedChange,
                onSave = actions.onSave,
                onDismiss = actions.onDismissEditor,
            )
        }

        state.pendingDelete?.let { memo ->
            ConfirmDialog(
                title = "删除备忘录",
                message = "确定要删除「${memo.title}」吗？删除后无法恢复。",
                onConfirm = actions.onConfirmDelete,
                onDismiss = actions.onDismissDelete,
                confirmText = "删除",
                destructive = true,
            )
        }
    }
}

@Composable
private fun MemoCard(
    memo: Memo,
    onEdit: () -> Unit,
    onToggleDone: () -> Unit,
    onTogglePinned: () -> Unit,
    onDelete: () -> Unit,
) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val status = LocalStatusColors.current
    SectionCard(
        modifier = Modifier.clickable(onClick = onEdit),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = memo.done, onCheckedChange = { onToggleDone() })
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (memo.pinned) {
                        Icon(
                            imageVector = Icons.Outlined.PushPin,
                            contentDescription = "已置顶",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(14.dp),
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                    Text(
                        text = memo.title.ifBlank { "无标题" },
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textDecoration = if (memo.done) TextDecoration.LineThrough else null,
                    )
                }
                val preview = memo.preview
                if (preview.isNotBlank()) {
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = preview,
                        style = MaterialTheme.typography.bodyMedium,
                        color = muted,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Spacer(modifier = Modifier.height(5.dp))
                Text(
                    text = TimeFormat.timestampToDateTimeText(memo.updatedAt),
                    style = MaterialTheme.typography.labelSmall,
                    color = muted,
                )
            }
            IconButton(onClick = onTogglePinned) {
                Icon(
                    imageVector = Icons.Outlined.PushPin,
                    contentDescription = if (memo.pinned) "取消置顶" else "置顶",
                    tint = if (memo.pinned) MaterialTheme.colorScheme.primary else muted,
                    modifier = Modifier.size(18.dp),
                )
            }
            IconButton(onClick = onDelete) {
                Icon(
                    imageVector = Icons.Outlined.DeleteOutline,
                    contentDescription = "删除",
                    tint = status.danger,
                    modifier = Modifier.size(18.dp),
                )
            }
        }
    }
}

@Composable
private fun MemoEditorDialog(
    editor: MemoEditorState,
    saving: Boolean,
    onTitleChange: (String) -> Unit,
    onContentChange: (String) -> Unit,
    onPinnedChange: (Boolean) -> Unit,
    onSave: () -> Unit,
    onDismiss: () -> Unit,
) {
    Dialog(
        onDismissRequest = { if (!saving) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background,
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .systemBarsPadding()
                    .imePadding()
                    .padding(horizontal = PageHorizontalPadding),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = if (editor.isEditing) "编辑备忘录" else "新建备忘录",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier.weight(1f),
                    )
                    IconButton(onClick = onDismiss, enabled = !saving) {
                        Icon(
                            imageVector = Icons.Outlined.Close,
                            contentDescription = "关闭",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                val titleError = editor.titleError
                OutlinedTextField(
                    value = editor.title,
                    onValueChange = onTitleChange,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text(text = "标题") },
                    placeholder = { Text(text = "请输入标题") },
                    singleLine = true,
                    isError = titleError != null,
                    supportingText = if (titleError != null) {
                        { Text(text = titleError) }
                    } else {
                        null
                    },
                    shape = MaterialTheme.shapes.medium,
                )

                OutlinedTextField(
                    value = editor.content,
                    onValueChange = onContentChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(top = 4.dp),
                    label = { Text(text = "正文") },
                    placeholder = { Text(text = "记录此刻的想法…") },
                    shape = MaterialTheme.shapes.medium,
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        imageVector = Icons.Outlined.PushPin,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "置顶显示",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f),
                    )
                    Switch(checked = editor.pinned, onCheckedChange = onPinnedChange)
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp, bottom = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    SecondaryButton(
                        text = "取消",
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        enabled = !saving,
                    )
                    PrimaryButton(
                        text = "保存",
                        onClick = onSave,
                        modifier = Modifier.weight(1f),
                        loading = saving,
                    )
                }
            }
        }
    }
}
