package com.lightdesk.core.data.repository

import com.lightdesk.core.common.AppResult
import com.lightdesk.core.common.map
import com.lightdesk.core.data.store.JsonFileStore
import com.lightdesk.core.data.store.UsageStatsStore
import com.lightdesk.core.model.FeatureKey
import com.lightdesk.core.model.UsageStat
import com.lightdesk.core.model.UsageStats
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class JsonUsageRepository(
    private val store: JsonFileStore<UsageStatsStore>,
) : UsageRepository {

    private val state = MutableStateFlow(UsageStats())
    private val loadMutex = Mutex()
    private val writeMutex = Mutex()

    @Volatile
    private var loaded = false

    override fun observeStats(): Flow<UsageStats> = state.onStart { ensureLoaded() }

    override suspend fun record(feature: FeatureKey, at: Long): AppResult<Unit> = writeMutex.withLock {
        ensureLoaded()
        val items = state.value.items.toMutableList()
        val index = items.indexOfFirst { it.feature == feature }
        if (index >= 0) {
            val old = items[index]
            items[index] = old.copy(count = old.count + 1, lastUsedAt = at)
        } else {
            items.add(UsageStat(feature = feature, count = 1, lastUsedAt = at))
        }
        persist(UsageStats(items = items.toList()))
    }

    override suspend fun reset(): AppResult<Unit> = writeMutex.withLock {
        persist(UsageStats())
    }

    private suspend fun persist(stats: UsageStats): AppResult<Unit> =
        store.write(UsageStatsStore(stats = stats)).map { state.value = stats }

    private suspend fun ensureLoaded() {
        if (loaded) return
        loadMutex.withLock {
            if (!loaded) {
                state.value = store.read().stats
                loaded = true
            }
        }
    }
}
